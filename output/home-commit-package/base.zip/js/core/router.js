const routes={home:"home","team-stats":"teams","player-stats":"teams",readings:"readings",betting:"betting",cup:"cup",champions:"champions"};
export async function loadPage(page,release){
  const moduleName=routes[page];
  if(!moduleName)throw new Error(`Pagina non supportata: ${page}`);
  return import(`../pages/${moduleName}.js?v=${release}`);
}
