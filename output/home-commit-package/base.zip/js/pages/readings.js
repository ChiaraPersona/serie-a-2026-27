import {renderLineupField} from "../components/lineup-field.mjs?v=20261022-assets-v1";
import {setReadingArtifacts} from './reading-detail/projected-artifacts.mjs?v=20261022-assets-v1';
import {isReadingPilot} from './reading-detail/view-model.mjs?v=20261022-assets-v1';
import {cardType} from './disciplinary.mjs?v=20261022-assets-v1';
import {sharedForecastsForMatch} from './shared-forecast-contract.mjs?v=20261102-champions-no-draw';
import {compactForecastMarkup,publishedReadingForecasts,installForecasts} from './reading-detail/forecasts.mjs?v=20261031-team-event-dedup';
import {createPersonalBetslipStore} from './personal-betslip-store.mjs?v=20261102-champions-no-draw';
const isFiniteNumber=value=>typeof value==="number"&&Number.isFinite(value);
const decimal=(value,digits=1)=>isFiniteNumber(value)?value.toLocaleString("it-IT",{minimumFractionDigits:digits,maximumFractionDigits:digits}):"N/D";
const probability=value=>isFiniteNumber(value)?`${(value*100).toLocaleString("it-IT",{minimumFractionDigits:0,maximumFractionDigits:1})}%`:"N/D";
const riskLabel=value=>value==="low"?"basso":value==="medium"?"medio":value==="high"?"alto":null;
const tierLabel=value=>value==="primary"?"PRIMARY":value==="co-primary"?"CO-PRIMARY":value==="secondary"?"SECONDARY":null;
const confidenceLabel=value=>value==="high"?"alta":value==="medium"?"media":value==="low"?"bassa":value||null;
const signalQuality=value=>!isFiniteNumber(value)?"Dati insufficienti":value>=.75?"Segnale forte":value>=.55?"Segnale medio":"Segnale debole";
const playerKey=player=>`${player?.playerId||player?.name||""}|${player?.teamId||player?.team||""}`;

export function fixtureLineupForMatch(match,team,teamDirectory){
  const official=teamDirectory?.officialLineups?.[`${match?.id}:${team?.id}`];
  if(official)return official;
  const lineup=team?.probableLineup;
  if(lineup?.status==="official"&&lineup.matchId!==match?.id)return team.projectedLineup||{...lineup,status:"reference"};
  if(lineup?.matchday&&lineup.matchday!==match?.matchday)return {...lineup,status:"reference",context:`Riferimento dalla ${lineup.matchday}ª giornata`};
  return lineup;
}

export function formationPresentation(match,teamDirectory){
  const teams=teamDirectory?.teams||[],meta=id=>teams.find(team=>team.id===id);
  const fixtureLineup=team=>fixtureLineupForMatch(match,team,teamDirectory);
  const lineups=[fixtureLineup(meta(match?.homeTeam)),fixtureLineup(meta(match?.awayTeam))];
  const official=lineups.length===2&&lineups.every(lineup=>lineup?.status==="official");
  const probable=lineups.some(lineup=>lineup?.status==="probable");
  return official?{status:"official",label:"FORMAZIONI UFFICIALI",note:"Le proiezioni individuali utilizzano le distinte ufficiali disponibili."}:probable?{status:"probable",label:"FORMAZIONI PROBABILI",note:"Le proiezioni individuali possono cambiare dopo le formazioni ufficiali."}:{status:"unconfirmed",label:"FORMAZIONI DA CONFERMARE",note:"Le probabilità individuali saranno aggiornate dopo le formazioni ufficiali."};
}

export function renderPredictionV2Sections({prediction,teams=[],esc=value=>String(value),teamLogo=()=>""}={}){
  const teamFor=id=>teams.find(team=>team.id===id)||{id,name:id||"N/D"};
  const metric=(value,digits=1)=>decimal(value,digits);
  const interval=source=>{
    if(!source||![source.min,source.central,source.max].every(isFiniteNumber))return '<span class="prediction-v2-missing">N/D</span>';
    const span=source.max-source.min,position=span>0?Math.max(0,Math.min(100,(source.central-source.min)/span*100)):50;
    const label=`${metric(source.central)}; intervallo ${metric(source.min)} - ${metric(source.max)}`;
    return `<span class="prediction-v2-value">${metric(source.central)}</span><span class="prediction-v2-range-text">${metric(source.min)} — ${metric(source.max)}</span><span class="prediction-v2-range" role="img" aria-label="${esc(label)}"><i aria-hidden="true" style="--range-position:${position.toFixed(1)}%"></i></span>`;
  };
  const projectionCard=projection=>{const team=teamFor(projection.teamId),channels=projection.attackChannels,channelLabel=channel=>channel==="left"?"Fascia sinistra":channel==="right"?"Fascia destra":"Zona centrale";const attackChannels=channels?`<details class="prediction-v2-channels"><summary>Direzioni d'attacco</summary><div class="prediction-channels"><span>Lati d'attacco</span>${[["left","Sinistra"],["central","Centro"],["right","Destra"]].map(([key,label])=>`<div><small>${label}</small><i aria-hidden="true"><b style="width:${isFiniteNumber(channels[key])?channels[key]:0}%"></b></i><strong>${isFiniteNumber(channels[key])?metric(channels[key]):"N/D"}%</strong></div>`).join("")}<em>Canale prevalente: ${channelLabel(channels.dominant)}</em></div></details>`:"";return `<article class="prediction-v2-team-card">${teamLogo(team)}<div class="prediction-v2-team-metrics"><div><span>Gol attesi</span><strong>${metric(projection.expectedGoals)}</strong></div><div><span>Tiri</span>${interval(projection.shotsTotal)}</div><div><span>SOT</span>${interval(projection.shotsOnTarget)}</div><div><span>Corner</span>${interval(projection.corners)}</div></div>${attackChannels}</article>`};
  const projections=Array.isArray(prediction?.teamProjections)?prediction.teamProjections:[];
  const numbers=`<section class="section prediction-v2-numbers" aria-labelledby="prediction-v2-numbers-title"><header class="section-heading"><div><p class="eyebrow">Previsione centrale</p><h2 id="prediction-v2-numbers-title">La partita in numeri</h2></div><p>Valore centrale e intervallo storico/model-based p20–p80. La barra colloca il valore nel range, senza rappresentare una distribuzione continua.</p></header>${projections.length?`<div class="prediction-v2-team-grid">${projections.map(projectionCard).join("")}</div>`:'<p class="prediction-v2-empty">Proiezioni squadra N/D</p>'}</section>`;

  const directionFor=evidence=>evidence?.status!=="active"?{className:"unknown",symbol:"?",label:"Segnale non sufficiente"}:evidence.level==="elevated"?{className:"favourable",symbol:"↑",label:"favorevole"}:evidence.level==="suppressed"?{className:"unfavourable",symbol:"↓",label:"sfavorevole"}:{className:"neutral",symbol:"→",label:"neutro"};
  const reasonFor=(metricName,evidence,direction)=>direction.className==="unknown"?"L'evidenza disponibile non basta per descrivere il matchup.":direction.className==="favourable"?`Il profilo avversario mostra un segnale elevato specifico per ${metricName}.`:direction.className==="unfavourable"?`Il profilo avversario mostra una soppressione specifica per ${metricName}.`:`Il segnale avversario specifico per ${metricName} resta nella norma.`;
  const matchupCard=projection=>{const team=teamFor(projection.teamId),interaction=projection.opponentMatchupInteraction||{},evidence=interaction.metricEvidence||{},own=projection.ownOffensiveInteraction||{};const rows=[["Volume tiri","il volume tiri",evidence.shots,interaction.signalStability?.shots],["Tiri nello specchio","i tiri nello specchio",evidence.shotsOnTarget,interaction.signalStability?.shotsOnTarget]];const ownText=isFiniteNumber(own.shotsAdjustmentPct)&&own.shotsAdjustmentPct>0?"La produzione offensiva corrente sostiene il volume centrale.":"Spinta offensiva aggiuntiva non disponibile.";return `<article class="prediction-v2-matchup-card">${teamLogo(team)}<p class="prediction-v2-own-signal">${esc(ownText)}</p><div>${rows.map(([label,name,item,stability])=>{const direction=directionFor(item);return `<section><span>${label}</span><strong class="signal-${direction.className}">${direction.symbol} ${direction.label}</strong><p>${esc(reasonFor(name,item,direction))}</p><small>${signalQuality(stability)} · stabilità del segnale, non confidenza del pronostico</small></section>`}).join("")}</div></article>`};
  const why=`<section class="section prediction-v2-why" aria-labelledby="prediction-v2-why-title"><header class="section-heading"><div><p class="eyebrow">Matchup V2</p><h2 id="prediction-v2-why-title">Perché il modello vede la partita così</h2></div><p>Tiri e SOT restano segnali distinti. Gli stati descrivono l'effetto del matchup sulla metrica, non un giudizio generale sulla squadra.</p></header>${projections.length?`<div class="prediction-v2-matchup-grid">${projections.map(matchupCard).join("")}</div>`:'<p class="prediction-v2-empty">Segnale non sufficiente</p>'}</section>`;

  const shooters=prediction?.shooters;
  const ranked=[...(shooters?.totalShots||[]),...(shooters?.shotsOnTarget||[])],seen=new Set(),players=ranked.map(item=>(shooters?.allPlayers||[]).find(player=>playerKey(player)===playerKey(item))||item).filter(item=>{const key=playerKey(item);if(seen.has(key))return false;seen.add(key);return true});
  const individualAvailable=player=>Boolean(player?.playerId)&&player?.dataStatus!=="role-baseline";
  const playerMeta=player=>`${esc(player.team||teamFor(player.teamId).name)} · ${esc(player.role||"Ruolo N/D")}${player.detailedRole?` · ${esc(player.detailedRole)}`:""}`;
  const individualMetric=(player,value,digits=2)=>individualAvailable(player)?metric(value,digits):"N/D";
  const individualProbability=(player,value)=>individualAvailable(player)?probability(value):"N/D";
  const expectedMinutes=player=>individualAvailable(player)&&isFiniteNumber(player.expectedMinutes)?`${Math.round(player.expectedMinutes)}' attesi`:"Minuti attesi N/D";
  const tier=player=>individualAvailable(player)&&tierLabel(player.allocationClass)?`<span class="prediction-v2-tier">Tiri: ${tierLabel(player.allocationClass)}</span>`:"";
  const substitution=player=>individualAvailable(player)&&riskLabel(player.substitutionRisk)?`<small>Rischio sostituzione: ${riskLabel(player.substitutionRisk)}</small>`:"";
  const tableRows=players.map(player=>`<tr><th scope="row"><strong>${esc(player.name||"N/D")}</strong><small>${playerMeta(player)}</small>${tier(player)}</th><td>${expectedMinutes(player)}</td><td class="is-key">${individualMetric(player,player.projectedShots)}</td><td class="is-key">${individualProbability(player,player.shotProbabilities?.over15)}</td><td>${individualProbability(player,player.shotProbabilities?.over25)}</td><td class="is-key">${individualMetric(player,player.projectedShotsOnTarget)}</td><td>${individualProbability(player,player.shotOnTargetProbabilities?.over05)}</td><td class="is-key">${individualProbability(player,player.shotOnTargetProbabilities?.over15)}</td></tr>`).join("");
  const playerCards=players.map(player=>`<article class="prediction-v2-player-card"><header><div><strong>${esc(player.name||"N/D")}</strong><small>${playerMeta(player)}</small></div>${tier(player)}</header><p>${expectedMinutes(player)}</p>${substitution(player)}<div class="prediction-v2-player-markets"><section><h3>Tiri <strong>${individualMetric(player,player.projectedShots)}</strong></h3><dl><div><dt>1+</dt><dd>${individualProbability(player,player.shotProbabilities?.over05)}</dd></div><div><dt>2+</dt><dd>${individualProbability(player,player.shotProbabilities?.over15)}</dd></div><div><dt>3+</dt><dd>${individualProbability(player,player.shotProbabilities?.over25)}</dd></div></dl></section><section><h3>SOT <strong>${individualMetric(player,player.projectedShotsOnTarget)}</strong></h3><dl><div><dt>1+</dt><dd>${individualProbability(player,player.shotOnTargetProbabilities?.over05)}</dd></div><div><dt>2+</dt><dd>${individualProbability(player,player.shotOnTargetProbabilities?.over15)}</dd></div></dl></section></div></article>`).join("");
  const shooterPanel=`<section class="section serie-a-shooters prediction-v2-shooters" aria-labelledby="serie-a-shooters-title"><header class="section-heading"><div><p class="eyebrow">Prediction Engine V2</p><h2 id="serie-a-shooters-title">Possibili migliori tiratori</h2></div><p>Proiezioni e probabilità del modello; non sono quote né raccomandazioni.</p></header>${players.length?`<div class="prediction-v2-shooter-table"><table><thead><tr><th>Giocatore</th><th>Min</th><th>Tiri</th><th>2+</th><th>3+</th><th>SOT</th><th>1+ SOT</th><th>2+ SOT</th></tr></thead><tbody>${tableRows}</tbody></table></div><div class="prediction-v2-player-cards">${playerCards}</div>`:'<p class="prediction-v2-empty">Proiezioni individuali N/D</p>'}<p class="objective-method">Le soglie sono lette dall'output V2; il frontend non ricalcola Poisson, minuti, matchup o allocazione. Per le identità non risolte il residuo di ruolo resta nel totale squadra, mentre i valori individuali sono N/D.</p></section>`;

  const outsiderGroup=(kind,label,items,available)=>{if(!available)return `<article><h3>${label}</h3><p class="prediction-v2-empty">Classificazione outsider N/D</p></article>`;const qualified=(items||[]).filter(player=>kind==="shots"?player.qualifiedOutsider===true:player.qualifiedSotOutsider===true);if(!qualified.length)return `<article><h3>${label}</h3><div class="prediction-v2-zero"><strong>Nessun outsider qualificato</strong><p>Nessun giocatore supera contemporaneamente i criteri minimi di volume, minuti ed evidenza del modello.</p></div></article>`;return `<article><h3>${label}</h3><div class="prediction-v2-outsider-list">${qualified.map(player=>{const confidence=kind==="shots"?player.outsiderConfidence:player.sotOutsiderConfidence;return `<section><header><div><strong>${esc(player.name||"N/D")}</strong><small>${playerMeta(player)}</small></div><span>${confidence?`Evidenza ${esc(confidenceLabel(confidence))}`:"Evidenza N/D"}</span></header><dl><div><dt>${kind==="shots"?"Tiri previsti":"SOT previsti"}</dt><dd>${metric(kind==="shots"?player.projectedShots:player.projectedShotsOnTarget,2)}</dd></div><div><dt>${kind==="shots"?"2+ tiri":"1+ SOT"}</dt><dd>${probability(kind==="shots"?player.shotProbabilities?.over15:player.shotOnTargetProbabilities?.over05)}</dd></div>${kind==="sot"?`<div><dt>2+ SOT</dt><dd>${probability(player.shotOnTargetProbabilities?.over15)}</dd></div>`:""}<div><dt>Minuti</dt><dd>${expectedMinutes(player)}</dd></div></dl><p>${esc(player.playerBaselineStability?.evidence?.[0]||"Evidenza individuale qualificata dal modello.")}</p></section>`}).join("")}</div></article>`};
  const hasShots=!!shooters&&Object.prototype.hasOwnProperty.call(shooters,"outsiders"),hasSot=!!shooters&&Object.prototype.hasOwnProperty.call(shooters,"sotOutsiders");
  const outsiderPanel=`<section class="section prediction-v2-outsiders" aria-labelledby="prediction-v2-outsiders-title"><header class="section-heading"><div><p class="eyebrow">Classificazione statistica</p><h2 id="prediction-v2-outsiders-title">Outsider del modello</h2></div><p>Zero outsider e un risultato valido: la pagina visualizza soltanto le qualificazioni prodotte dal detector V2.</p></header><div class="prediction-v2-outsider-grid">${outsiderGroup("shots","Outsider tiri",shooters?.outsiders,hasShots)}${outsiderGroup("sot","Outsider SOT",shooters?.sotOutsiders,hasSot)}</div></section>`;

  const booked=Array.isArray(prediction?.likelyBooked)?prediction.likelyBooked:[];
  const bookingRows=booked.map(candidate=>{
    const evidence=Array.isArray(candidate.evidence)?candidate.evidence:[];
    const foulEvidence=evidence.find(item=>typeof item==='string'&&/^\d+(?:[.,]\d+)? falli\/90(?: stimati)?$/.test(item));
    const fouls=foulEvidence?Number(foulEvidence.match(/^[\d.,]+/)[0].replace(',','.')):null;
    const own=isFiniteNumber(fouls)?'Commette '+metric(fouls)+' falli/90'+(foulEvidence.endsWith('stimati')?' stimati':'')+'.':'Falli commessi/90 N/D.';
    const duels=Array.isArray(candidate.readingDuels)&&candidate.readingDuels.length?candidate.readingDuels:candidate.role!=='Difensore'&&candidate.directOpponent?[{name:candidate.directOpponent,foulsWonPer90:candidate.opponentFoulsWonPer90}]:[];
    const duel=duels.length?(duels.length>1?'Possibili duelli con ':'Possibile duello con ')+duels.map(d=>d.name).join(', '):'Duello diretto N/D';
    const refereeMissing=candidate.refereeFactorSource==='INSUFFICIENT_REFEREE_EVIDENCE'||candidate.refereeEvidence?.some(item=>/N\/D|non disponibile/i.test(item));
    const referee=candidate.refereeFactorSource==='NO_DESIGNATION_AVAILABLE'?'arbitro non designato':refereeMissing?'influenza arbitrale N/D':isFiniteNumber(candidate.refereeFactor)?candidate.refereeFactor>1?'arbitro severo':candidate.refereeFactor<1?'arbitro permissivo':'arbitro nella media':'influenza arbitrale N/D';
    return `<li class="${candidate.possibleFirstBooked?"possible-first-booked":""}"><span>${candidate.rank??"—"}</span><div><strong>${esc(candidate.name||"N/D")}</strong><small>${esc(teamFor(candidate.teamId).name)} · ${esc(candidate.role||"Ruolo N/D")}${candidate.possibleFirstBooked?" · possibile primo ammonito (euristica)":""}</small><em>${esc(own+" "+duel+"; "+referee+".")}</em></div><b>${isFiniteNumber(candidate.riskScore)?`${metric(candidate.riskScore,0)}/100`:"N/D"}</b></li>`;
  }).join('');
  const discipline=`<section class="prediction-booked-panel"><header><div><h3>Probabili ammoniti</h3></div></header>${booked.length?`<ol>${bookingRows}</ol>`:'<p class="prediction-v2-empty">Candidati ammonizione N/D</p>'}</section>`;
  return {numbers,why,shooters:shooterPanel,outsiders:outsiderPanel,discipline};
}

export function renderSharedForecasts({marketCatalog,match}={}){
 const forecasts=publishedReadingForecasts(marketCatalog,match?.id,match);
 if(!forecasts.length)return '';
 return `<section class="section reading-shared-forecasts" aria-labelledby="reading-shared-forecasts-title"><header class="section-heading"><h2 id="reading-shared-forecasts-title">Pronostici</h2></header><div data-reading-forecast-content>${compactForecastMarkup({competition:'serie-a',fixture:match,forecasts})}</div></section>`;
}

export function createPage(deps){
  const {esc,contrastInk,dateOnly,scheduleLabel,scheduleChronology,teamLogo,empty,hero,competitionLabel,loadGenerated,loadReading,loadReadingCatalog}=deps;
const readingModules=[
  ["context","01","Contesto e posta in gioco","Classifica, obiettivi stagionali, momento e peso della partita."],
  ["form","02","Forma e numeri","Rendimento recente, casa/trasferta e indicatori con campione dichiarato."],
  ["availability","03","Disponibilita e probabili scelte","Assenze, rientri, rotazioni e formazioni soltanto se verificati."],
  ["tactics","04","Chiavi tattiche","Strutture, duelli, spazi e possibili adattamenti delle due squadre."],
  ["referee","05","Arbitro e disciplina","Designazione, profilo disciplinare e compatibilita con il tipo di gara."],
  ["market","06","Mercato e quote","Movimenti delle quote e mercati utili, sempre con orario e fonte."],
  ["synthesis","07","Sintesi e scenari","Segnali favorevoli, contrari e condizioni che possono cambiare la lettura."]
];
const readingField=section=>section?.content?`<div class="reading-content"><p>${esc(section.content)}</p>${section.signals?.length?`<ul>${section.signals.map(signal=>`<li>${esc(signal)}</li>`).join("")}</ul>`:""}</div>`:`<div class="reading-missing"><strong>N/D</strong><span>Sezione da compilare con dati verificati.</span></div>`;
function readingFixtureLink(match,teams,reading,prediction,history){
  const home=teams.find(team=>team.id===match.homeTeam),away=teams.find(team=>team.id===match.awayTeam);
  const finished=match.status==="finished"&&match.score;
  const likelyScore=prediction?.scoreForecast?.primary?.score||prediction?.exactScores?.[0]?.score;
  const [homeColor1="#174fa5",homeColor2="#081d48"]=home.colors||[],[awayColor1="#174fa5",awayColor2="#081d48"]=away.colors||[];
  const teamColorStyle=`--home-color-1:${homeColor1};--home-color-2:${homeColor2};--away-color-1:${awayColor1};--away-color-2:${awayColor2}`;
  const preview=finished?`<span class="reading-fixture-preview" aria-label="Dati della partita"><span><small>Pronostico esatto</small><strong>${esc(likelyScore||"N/D")}</strong></span><span><small>Intervallo</small><strong>${match.halfTimeScore?`${match.halfTimeScore.home} - ${match.halfTimeScore.away}`:"N/D"}</strong></span><span><small>Dati calciatori</small><strong>${(match.playerStats?.home?.length||0)+(match.playerStats?.away?.length||0)}</strong></span></span>`:prediction?`<span class="reading-fixture-preview" aria-label="Anteprima della lettura"><span><small>Verdetto</small><strong>${esc(prediction.verdict.label)}</strong></span><span><small>Risultato esatto</small><strong>${esc(likelyScore||"N/D")}</strong></span><span><small>Confidenza</small><strong>${prediction.confidence.value}/100</strong></span></span>`:reading?.summary?`<span class="reading-fixture-preview reading-fixture-preview-text"><span><small>Anteprima</small><strong>${esc(reading.summary)}</strong></span></span>`:"";
  const roundLabel=match.competition==="coppa-italia"?"Coppa Italia · Sedicesimi":`Giornata ${match.matchday}`;
  return `<a class="reading-fixture match fixture-card fixture-card-link${finished?" is-finished":""}" href="lettura.html?match=${esc(match.id)}" aria-label="Apri la lettura di ${esc(home.name)} - ${esc(away.name)}" style="${teamColorStyle}"><header class="match-head"><div class="match-badges"><span class="matchday-chip">${roundLabel}</span>${finished?'<span class="status finished">Conclusa</span>':""}</div><span class="match-date">${scheduleLabel(match)}</span></header><span class="reading-fixture-teams">${teamLogo(home)}<b class="${finished?"reading-final-score":""}">${finished?`${match.score.home} - ${match.score.away}`:"VS"}</b>${teamLogo(away)}</span>${preview}</a>`;
}
function readingIndex(readings,matches,teams,predictions=[]){
  const chronological=(a,b)=>scheduleChronology(a,b)||a.id.localeCompare(b.id);
  const league=matches.filter(m=>m.competition==="serie-a");
  const days=[...new Set(league.map(m=>m.matchday))].sort((a,b)=>a-b);
  const current=days.find(day=>league.some(m=>m.matchday===day&&m.status!=="finished"));
  const rows=day=>league.filter(m=>m.matchday===day).sort(chronological);
  const archive=days.filter(day=>day!==current&&rows(day).every(m=>m.status==="finished")).reverse();
  const future=days.filter(day=>day!==current&&!archive.includes(day));
  const range=day=>{const dates=rows(day).map(m=>m.date||m.matchdayDate).filter(Boolean).sort();return dates.length?`${dateOnly(dates[0])}${dates[0]!==dates.at(-1)?` – ${dateOnly(dates.at(-1))}`:""}`:"Date da definire"};
  const card=(match,compact=false)=>{
    const home=teams.find(t=>t.id===match.homeTeam),away=teams.find(t=>t.id===match.awayTeam);
    const finished=match.status==="finished";
    const score=finished&&Number.isFinite(match.score?.home)&&Number.isFinite(match.score?.away)?`${match.score.home} - ${match.score.away}`:finished?"N/D":"VS";
    const style=[['home',home],['away',away]].flatMap(([side,team])=>(team.colors||[]).slice(0,2).map((color,i)=>`--${side}-color-${i+1}:${color}`)).join(';');
    return `<a class="ri-match ${compact?"ri-compact":"ri-glass"}${finished?" ri-finished":""}" style="${esc(style)}" data-fixture-id="${esc(match.id)}" href="lettura.html?match=${esc(match.id)}" aria-label="Apri analisi: ${esc(home.name)} - ${esc(away.name)}">${compact?"":`<span class="ri-date">${scheduleLabel(match)}</span>`}<span class="ri-teams">${teamLogo(home)}<b aria-label="${finished?"Risultato finale":"Contro"}">${score}</b>${teamLogo(away)}</span></a>`;
  };
  const grid=(day,compact=false)=>`<div class="ri-matches${compact?" ri-results":""}">${rows(day).map(m=>card(m,compact)).join("")}</div>`;
  return `<div class="readings-index"><header class="ri-title page-heading"><h1>Letture</h1></header><section class="ri-current" aria-labelledby="ri-current-title"><header class="ri-heading"><div><div class="ri-heading-line"><h2 id="ri-current-title" class="eyebrow">${current?`Giornata ${current}`:"Campionato concluso"}</h2></div></div>${current?`<span class="ri-range">${range(current)}</span>`:""}</header>${current?grid(current):""}</section><section class="ri-archive" aria-labelledby="ri-archive-title"><h2 id="ri-archive-title" class="ri-section-title">Archivio risultati</h2>${archive.length?`<div class="ri-calendar">${archive.map(day=>`<button type="button" class="ri-archive-day" id="ri-archive-day-${day}" data-archive-day="${day}" aria-expanded="false" aria-controls="ri-archive-panel"><span>Giornata</span><strong>${day}</strong><small>Conclusa</small></button>`).join("")}</div><div id="ri-archive-panel" class="ri-future-panel" role="region" hidden></div>${archive.map(day=>`<template id="ri-archive-content-${day}"><header class="ri-heading"><h3>Giornata ${day}</h3><span class="ri-range">${range(day)}</span></header>${grid(day,true)}</template>`).join("")}`:"<p>Nessuna giornata conclusa.</p>"}</section><section class="ri-future" aria-labelledby="ri-future-title"><h2 id="ri-future-title" class="ri-section-title">Giornate future</h2><div class="ri-calendar">${future.map(day=>`<details class="ri-calendar-day"><summary><span>Giornata</span><strong>${day}</strong><small>${rows(day).length} partite</small></summary><div class="ri-future-panel"><header class="ri-heading"><h3>Giornata ${day}</h3><span class="ri-range">${range(day)}</span></header>${grid(day)}</div></details>`).join("")}</div>${future.length?"":"<p>Nessuna giornata futura in calendario.</p>"}</section></div>`;
}
function readingDetail(match,reading,teams){
  const home=teams.find(team=>team.id===match.homeTeam),away=teams.find(team=>team.id===match.awayTeam),sections=reading?.sections||{},completed=readingModules.filter(([key])=>sections[key]?.content).length;
  const title=reading?.title||`${home.name} - ${away.name}`;
  const isCup=match.competition==="coppa-italia",competition=isCup?"Coppa Italia · Sedicesimi":`Serie A · Giornata ${match.matchday}`,fixtureLabel=isCup?"Sedicesimi":`Giornata ${match.matchday}`,fixtureNav=isCup?`<a href="coppa-italia.html#coppa-round-16">${fixtureLabel}</a>`:`<span>${fixtureLabel}</span>`;
  return `<nav class="reading-back"><a href="lettura.html">← Tutte le letture</a>${fixtureNav}</nav><section class="reading-match-hero"><div><p class="eyebrow">${competition}</p><h1>${esc(title)}</h1><p>${scheduleLabel(match)}</p><span class="reading-progress">${completed}/7 sezioni compilate</span></div><div class="reading-matchup">${teamLogo(home)}<b>VS</b>${teamLogo(away)}</div></section>${reading?.summary?`<aside class="reading-summary"><span>Sintesi editoriale</span><p>${esc(reading.summary)}</p></aside>`:""}<section class="section reading-detail"><header class="section-heading"><div><p class="eyebrow">Scheda di lavoro</p><h2>Struttura della lettura</h2></div><p>I campi non ancora verificati restano N/D.</p></header><div class="reading-module-grid">${readingModules.map(([key,number,moduleTitle,description])=>`<article class="reading-module" id="lettura-${key}"><header><span>${number}</span><div><h3>${moduleTitle}</h3><p>${description}</p></div></header>${readingField(sections[key])}${sections[key]?.sources?.length?`<footer>${sections[key].sources.map(source=>`<a href="${esc(source.url)}" target="_blank" rel="noreferrer">${esc(source.label||"Fonte")}</a>`).join(" · ")}</footer>`:""}</article>`).join("")}</div></section>`;
}
function headToHeadPanel(history,prediction){
  if(!history)return `<section class="section reading-h2h-section"><aside class="data-warning"><strong>Precedenti N/D</strong><p>Nessun dataset storico collegato a questa partita.</p></aside></section>`;
  const meetings=history.previousMeetings||[],available=history.coverage?.available??meetings.length;
  const eventList=(items,emptyLabel)=>items?.length?`<ul>${items.map(item=>`<li><strong>${esc(item.player)}</strong><small>${esc(item.team)} · ${esc(item.minute||"minuto N/D")}${item.ownGoal?" · autogol":""}</small></li>`).join("")}</ul>`:`<p class="reading-h2h-empty">${emptyLabel}</p>`;
  const cards=meeting=>{const gap=meeting.coverage?.missingFields?.includes("bookingEvents");if(!meeting.bookings?.length)return `<p class="reading-h2h-empty">${gap?"Dettaglio ammoniti N/D":"Nessun ammonito registrato"}</p>`;return `${eventList(meeting.bookings,"Nessun ammonito registrato")}${gap?'<small class="reading-h2h-warning">Conteggio ESPN non riconciliato: sono mostrati soltanto gli eventi nominativi disponibili.</small>':""}`};
  const goals=meeting=>{const gap=meeting.coverage?.missingFields?.includes("goalEvents");if(!meeting.goals?.length)return `<p class="reading-h2h-empty">${gap?"Dettaglio marcatori N/D":"Nessun gol"}</p>`;return eventList(meeting.goals,"Nessun gol")};
  const rows=meetings.map((meeting,index)=>`<details class="reading-h2h-match"><summary><span>${dateOnly(meeting.date)} · ${esc(meeting.competition)}</span><strong>${esc(meeting.homeTeam.name)} ${meeting.score.home}-${meeting.score.away} ${esc(meeting.awayTeam.name)}</strong></summary><div class="reading-h2h-events"><section><h3>Marcatori</h3>${goals(meeting)}</section><section><h3>Ammoniti</h3>${cards(meeting)}</section></div><a href="${esc(meeting.source.url)}" target="_blank" rel="noreferrer">Fonte ESPN</a></details>`).join("");

  return `<section class="section reading-h2h-section"><header class="section-heading"><div><p class="eyebrow">Storico ufficiale · ESPN</p><h2>Ultimi ${available} scontri diretti disponibili</h2></div><p>${available}/5 precedenti · Serie A, Serie B e Coppa Italia</p></header>${available<5?`<aside class="data-warning"><strong>Campione storico limitato</strong><p>Il provider espone ${available} confronti per questa coppia; quelli mancanti non vengono ricostruiti.</p></aside>`:""}<div class="reading-h2h-list">${rows}</div></section>`;
}
const actualValue=value=>value===null||value===undefined?"N/D":esc(String(value));
function readingPostMatchReport(match,home,away){
  if(match.status!=="finished"||!match.score)return"";
  const teamFor=id=>id===home.id?home:away;
  const eventList=(items,renderer,emptyLabel)=>items?.length?`<ol>${items.map(renderer).join("")}</ol>`:`<p class="reading-post-match-empty">${emptyLabel}</p>`;
  const scorers=eventList(match.scorers,item=>`<li><span>${item.minute}'</span><div><strong>${esc(item.player)}</strong><small>${esc(teamFor(item.team).name)}${item.ownGoal?" · autogol":""}${item.assist?` · assist ${esc(item.assist)}`:""}</small></div></li>`,"Nessun gol");
  const bookings=eventList(match.bookings,item=>{const type=cardType(item.eventType||item.card),red=type==="redCard"||type==="yellowRedCard";return `<li><span class="reading-booking-card${red?" is-red":type==="unknown"?" is-unknown":""}" aria-label="${type==="unknown"?"Cartellino tipo N/D":red?"Cartellino rosso":"Cartellino giallo"}"></span><div><strong>${esc(item.player)}</strong><small>${item.minute==null?"Minuto N/D":`${esc(item.minute)}'`} · ${esc(teamFor(item.team).name)}${type==="yellowRedCard"?" · espulsione per secondo giallo":type==="redCard"?" · rosso diretto":type==="unknown"?" · tipo N/D":""}</small></div></li>`},match.resultCoverage?.bookings==="unavailable"?"Cartellini N/D":"Nessun cartellino");
  const substitutions=eventList(match.substitutions,item=>`<li><span>${item.minute}'</span><div><strong>${esc(item.playerIn)} <small>entra</small></strong><small>${esc(teamFor(item.team).name)} · esce ${esc(item.playerOut)}</small></div></li>`,match.resultCoverage?.substitutions==="unavailable"?"Sostituzioni N/D":"Nessuna sostituzione registrata");
  const statRows=[
    ["Possesso", "possessionPct", "%"],["xG", "expectedGoals", ""],["Tiri totali", "shots", ""],["Tiri in porta", "shotsOnTarget", ""],["Corner", "corners", ""],["Passaggi riusciti", "passesCompleted", ""],["Precisione passaggi", "passAccuracyPct", "%"],["Falli commessi", "fouls", ""],["Falli subiti", "fouls", "", true],["Ammonizioni", "yellowCards", ""],["Duelli vinti", "duelsWon", ""],["Parate", "goalkeeperSaves", ""]
  ];
  const statValue=(side,key,suffix)=>match.teamStats?.[side]?.[key]===null||match.teamStats?.[side]?.[key]===undefined?"N/D":`${actualValue(match.teamStats[side][key])}${suffix}`;
  const comparison=statRows.map(([label,key,suffix,fromOpponent=false])=>`<tr><td>${statValue(fromOpponent?"away":"home",key,suffix)}</td><th scope="row">${label}</th><td>${statValue(fromOpponent?"home":"away",key,suffix)}</td></tr>`).join("");
  const playerTable=(team,players=[])=>match.resultCoverage?.playerStats==="unavailable"?`<article class="reading-player-team"><h3>${esc(team.name)}</h3><p class="reading-post-match-empty">Statistiche individuali N/D</p></article>`:`<article class="reading-player-team"><header>${teamLogo(team,{showName:false})}<div><h3>${esc(team.name)}</h3><small>${players.length} calciatori impiegati</small></div></header><div class="reading-player-table-scroll"><table class="reading-player-table"><thead><tr><th>Calciatore</th><th>Impiego</th><th>Min</th><th>Voto</th><th>G</th><th>A</th><th>Tiri in porta</th><th>xG</th></tr></thead><tbody>${players.map(player=>`<tr><td><strong>${esc(player.player)}</strong></td><td>${player.starter?"Titolare":"Subentrato"}</td><td>${actualValue(player.minutes)}</td><td>${actualValue(player.rating)}</td><td>${actualValue(player.goals)}</td><td>${actualValue(player.assists)}</td><td>${actualValue(player.shotsOnTarget)}</td><td>${actualValue(player.expectedGoals)}</td></tr>`).join("")}</tbody></table></div></article>`;
  const sourceUrl=match.resultSource?.url||match.sources?.find(source=>source.sourceType==="match-report-stats")?.sourceUrl;
  const officialMvp=match.mvp?`<aside class="reading-official-mvp"><span>Panini Player of the Match</span><strong>${esc(match.mvp.player)}</strong><small>${esc(teamFor(match.mvp.team).name)} · MVP ufficiale</small><a href="${esc(match.mvp.sourceUrl)}" target="_blank" rel="noreferrer">Fonte Lega Serie A</a></aside>`:"";
  return `<section class="section reading-post-match" id="tabellino"><header class="section-heading"><div><p class="eyebrow">Dati reali · partita conclusa</p><h2>Tabellino e statistiche</h2></div><p>Intervallo ${match.halfTimeScore?`${match.halfTimeScore.home} - ${match.halfTimeScore.away}`:"N/D"} · moduli ${actualValue(match.formations?.home)} / ${actualValue(match.formations?.away)}</p></header>${officialMvp}<div class="reading-match-events-grid"><article><h3>Marcatori</h3>${scorers}</article><article><h3>Cartellini</h3>${bookings}</article><article><h3>Sostituzioni</h3>${substitutions}</article></div><div class="reading-team-comparison"><table><thead><tr><th>${esc(home.name)}</th><th>Statistiche squadra</th><th>${esc(away.name)}</th></tr></thead><tbody>${comparison}</tbody></table></div><div class="reading-player-stats-grid">${playerTable(home,match.playerStats?.home)}${playerTable(away,match.playerStats?.away)}</div>${sourceUrl?`<a class="reading-post-match-source" href="${esc(sourceUrl)}" target="_blank" rel="noreferrer">Fonte tabellino · ${esc(match.resultSource?.provider||"StatMuse")}</a>`:""}</section>`;
}
function readingPrototypeDetail(match,reading,teams,teamDirectory,objectiveProfiles,prediction,history,refereeProfiles,forecastCatalog){
  const home=teams.find(team=>team.id===match.homeTeam),away=teams.find(team=>team.id===match.awayTeam);
  const directoryTeams=teamDirectory?.teams||[],homeMeta=directoryTeams.find(team=>team.id===home.id)||{},awayMeta=directoryTeams.find(team=>team.id===away.id)||{};
  const isCup=match.competition==="coppa-italia",competition=isCup?"Coppa Italia · Sedicesimi":`Serie A · Giornata ${match.matchday}`,fixtureLabel=isCup?"Sedicesimi":`Giornata ${match.matchday}`,fixtureNav=isCup?`<a href="coppa-italia.html#coppa-round-16">${fixtureLabel}</a>`:`<span>${fixtureLabel}</span>`;
  const unavailable=(label,note)=>`<div class="reading-unavailable"><span>${label}</span><strong>N/D</strong><small>${note}</small></div>`;
  const duplicatePanels=new Set(["Campo","Dati disponibili"]);
  const dataPanel=(label,body,className="")=>duplicatePanels.has(label)?"":`<section class="reading-data-panel ${className}"><span>${label}</span>${body}</section>`;
  const finished=match.status==="finished"&&match.score,formation=formationPresentation(match,teamDirectory);
  const scoreForecasts=prediction?.scoreForecast?.display||prediction?.exactScores?.slice(0,3)||[];
  const scoreCards=scoreForecasts.length===3?scoreForecasts.map((item,index)=>`<div${index===0?' class="is-central"':""}><strong>${esc(item.score)}</strong><small>${index===0?"Risultato centrale":"Alternativa"}${item.probabilityPct!=null?` · ${item.probabilityPct}%`:""}</small></div>`).join(""):'<div class="is-central"><strong>N/D</strong><small>Risultato centrale</small></div><div><strong>N/D</strong><small>Alternativa</small></div><div><strong>N/D</strong><small>Alternativa</small></div>';
  const scoreCoverage=prediction?.scoreProfile?.topThreeCoveragePct;
  const surpriseValue=prediction?.surprise?.value;
  const summary=`<div class="reading-summary reading-summary-prototype reading-hero-summary reading-result-summary"><div class="reading-exact-scores"><span>Risultato esatto pronosticato</span><div class="reading-score-list">${scoreCards}</div><small class="reading-score-caveat">Centrale dai gol attesi arrotondati${scoreCoverage!=null?` · tre scenari coprono il ${scoreCoverage}%`:""}</small></div><div class="reading-hero-signal reading-hero-surprise reading-surprise-factor"><span>Fattore sorpresa</span><strong>${isFiniteNumber(surpriseValue)?`${surpriseValue}/100`:"N/D"}</strong><small>${prediction?.surprise?.level?esc(prediction.surprise.level):"Dato non disponibile"}</small>${isFiniteNumber(surpriseValue)?`<div class="reading-surprise-bar" role="progressbar" aria-label="Fattore sorpresa ${surpriseValue} su 100" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${surpriseValue}"><b style="width:${surpriseValue}%"></b></div>`:""}</div><div class="reading-hero-signal"><span>Confidenza</span><strong>${isFiniteNumber(prediction?.confidence?.value)?`${prediction.confidence.value}/100`:"N/D"}</strong><small>${prediction?.confidence?.level?esc(prediction.confidence.level):"Dato non disponibile"}</small></div><div class="reading-formation-status is-${formation.status}"><strong>${formation.label}</strong><small>${esc(formation.note)}</small></div></div>`;
  const assignment=match.refereeAssignment,refereeProfile=assignment?refereeProfiles?.profiles?.find(profile=>profile.refereeSlug===assignment.referee.slug):null;
  const refereeMetric=(label,value)=>`<article><span>${label}</span><strong>${value??"N/D"}</strong></article>`;
  const refereeStats=refereeProfile?`<div class="reading-referee-stats">${refereeMetric("Falli / gara",refereeProfile.perMatch.fouls?.toFixed(2)??"N/D")}${refereeMetric("Gialli / gara",refereeProfile.perMatch.yellowCards?.toFixed(2)??"N/D")}${refereeMetric("Rossi / gara",refereeProfile.perMatch.redCards?.toFixed(2)??"N/D")}${refereeMetric("Rigori / gara",refereeProfile.perMatch.penalties?.toFixed(2)??"N/D")}</div>`:`<div class="reading-referee-stats">${refereeMetric("Statistiche disciplinari","N/D")}</div>`;
  const officialName=value=>value?.name||value||"N/D";
  const refereePanel=assignment?`<section class="section reading-referee-assignment" id="lettura-referee"><header class="section-heading"><div><p class="eyebrow">Designazione ufficiale AIA</p><h2>Squadra arbitrale</h2></div><p>Incarichi ufficiali, separati dalle statistiche disciplinari.</p></header><div class="reading-referee-designation"><article class="is-main"><span>Arbitro</span><strong>${esc(officialName(assignment.referee))}</strong></article><article><span>Assistenti</span><strong>${esc((assignment.assistants||[]).map(officialName).join(" · ")||"N/D")}</strong></article><article><span>IV ufficiale</span><strong>${esc(officialName(assignment.fourthOfficial))}</strong></article><article><span>VAR</span><strong>${esc(officialName(assignment.var))}</strong></article><article><span>AVAR</span><strong>${esc(officialName(assignment.avar))}</strong></article></div>${refereeStats}<p class="reading-referee-method">La designazione non modifica automaticamente il pronostico.</p></section>`:`<section class="section reading-referee-assignment" id="lettura-referee"><header class="section-heading"><div><p class="eyebrow">Designazione ufficiale AIA</p><h2>N/D</h2></div><p>Arbitro non ancora disponibile.</p></header></section>`;
  const v2=renderPredictionV2Sections({prediction,teams,esc,teamLogo});
  const archiveBanner=finished?'<aside class="reading-prototype-banner reading-archive-banner"><strong>Analisi prepartita archiviata</strong><p>Le sezioni successive conservano il pronostico formulato prima della gara; il tabellino qui sopra contiene i dati reali conclusivi.</p></aside>':"";
  return `<nav class="reading-back"><a href="lettura.html">← Tutte le letture</a>${fixtureNav}</nav><section class="reading-match-hero${finished?" is-finished":""}"><div><p class="eyebrow">${competition} · ${finished?"conclusa":"prepartita"}</p><h1>${esc(home.name)} - ${esc(away.name)}</h1><p>${scheduleLabel(match)} · ${esc(homeMeta.stadium||"Stadio N/D")}</p></div><div class="reading-matchup" aria-label="${esc(home.name)} contro ${esc(away.name)}">${teamLogo(home,{showName:false})}<b>${finished?`${match.score.home} - ${match.score.away}`:"VS"}</b>${teamLogo(away,{showName:false})}</div>${summary}</section>${readingPostMatchReport(match,home,away)}${archiveBanner}${renderSharedForecasts({marketCatalog:forecastCatalog,match,esc})}${v2.numbers}${v2.why}${v2.shooters}${v2.outsiders}${v2.discipline}${refereePanel}<section class="section reading-info-grid"><article class="round16-info-box round16-formations"><span>1</span><h2>Sistemi di riferimento</h2><div class="reading-base-shape"><strong>${esc(home.name)} · ${esc(homeMeta.preferredFormation||"N/D")}</strong><p>Allenatore: ${esc(homeMeta.coach||"N/D")}</p></div><div class="reading-base-shape"><strong>${esc(away.name)} · ${esc(awayMeta.preferredFormation||"N/D")}</strong><p>Allenatore: ${esc(awayMeta.coach||"N/D")}</p></div></article></section>${headToHeadPanel(history,prediction)}`;
}
function renderProbableLineups(match,teamDirectory,prediction){
  if(!match||!teamDirectory)return;
  const meta=id=>teamDirectory.teams.find(team=>team.id===id),home=meta(match.homeTeam),away=meta(match.awayTeam);
  const fixtureLineup=team=>fixtureLineupForMatch(match,team,teamDirectory);
  const officialLineups=fixtureLineup(home)?.status==="official"&&fixtureLineup(away)?.status==="official";
  const target=document.querySelector(".round16-formations");
  if(target){const homeLineup=fixtureLineup(home),awayLineup=fixtureLineup(away),referenceLineups=homeLineup?.status==="reference"&&awayLineup?.status==="reference",source=homeLineup?.source||awayLineup?.source||{},updated=homeLineup?.updatedAt||awayLineup?.updatedAt||dateOnly(source.retrievedAt)||"N/D",sourceLabel=source.url?`<a href="${esc(source.url)}" target="_blank" rel="noreferrer">Fonte ${esc(source.provider||"editoriale")}</a>`:`Fonte ${esc(source.provider||"editoriale")}`,officialContext=match.competition==="coppa-italia"?"Distinte ufficiali della gara":"Distinte ufficiali della giornata "+match.matchday,projectionContext=match.competition==="coppa-italia"?"Proiezione editoriale per la gara di Coppa, non distinta ufficiale":"Proiezione editoriale della giornata, non distinta ufficiale";target.innerHTML=`<span>1</span><h2>${officialLineups?"Formazioni ufficiali":referenceLineups?"Formazioni di riferimento":"Probabili formazioni"}</h2>${renderLineupField([{team:home,lineup:homeLineup},{team:away,lineup:awayLineup}])}<small>${officialLineups?officialContext:referenceLineups?"Ultime distinte ufficiali disponibili usate come riferimento; non sono formazioni confermate":projectionContext}, aggiornate ${esc(updated)}. ${sourceLabel}</small>`;}
  const banner=document.querySelector(".reading-prototype-banner p");if(banner&&match.status==="finished")banner.textContent=`Le sezioni successive conservano l'analisi prepartita; risultato, formazioni, eventi e statistiche reali sono pubblicati nel tabellino.`;
}
function renderReadingPilotEvidence(reading,match){
  if(!reading)return;
  const available=[["form","Base storica 2025/26"]].filter(([key])=>reading.sections?.[key]?.content);
  if(!available.length)return;
  const cards=available.map(([key,title])=>{const section=reading.sections[key];return `<article class="reading-pilot-card"><header><span>${title}</span><strong>Dato disponibile</strong></header><p>${esc(section.content)}</p>${section.signals?.length?`<ul>${section.signals.map(signal=>`<li>${esc(signal)}</li>`).join("")}</ul>`:""}${section.sources?.length?`<footer>${section.sources.map(source=>`<a href="${esc(source.url)}" target="_blank" rel="noreferrer">${esc(source.label)}</a>`).join(" · ")}</footer>`:""}</article>`}).join("");
  document.querySelector(".reading-h2h-section")?.insertAdjacentHTML("beforebegin",`<section class="section reading-pilot-evidence"><header class="section-heading"><div><p class="eyebrow">Atalanta - Sassuolo · versione iniziale</p><h2>Evidenze già integrate</h2></div><p>Storico e contesto restano separati dai dati 2026/27.</p></header><div>${cards}</div></section>`);
}
function renderTacticalBaselines(match,dataset,teams){
  if(!match||!dataset?.profiles?.length)return;
  const profileFor=teamId=>dataset.profiles.find(profile=>profile.teamId===teamId),teamFor=teamId=>teams.find(team=>team.id===teamId);
  const card=teamId=>{const team=teamFor(teamId),profile=profileFor(teamId);if(!team||!profile)return"";const list=(label,items)=>`<div><strong>${label}</strong>${items?.length?`<ul>${items.slice(0,5).map(item=>`<li>${esc(item.label)}</li>`).join("")}</ul>`:'<p class="muted">N/D dal provider</p>'}</div>`;return `<article class="reading-tactical-card">${teamLogo(team)}<span class="sample-label sample-${profile.dataQuality==="complete"?"strong":"low"}">${profile.dataQuality==="complete"?"Profilo completo":profile.dataQuality==="limited-sample"?"Campione limitato":"Solo statistiche"}</span><dl><div><dt>Campione</dt><dd>${esc(profile.competition)} · ${profile.summary.appearances} gare</dd></div><div><dt>Modulo più usato</dt><dd>${esc(profile.formation.code||"N/D")}${profile.formation.appearances?` · ${profile.formation.appearances} gare`:""}</dd></div><div><dt>Possesso</dt><dd>${profile.summary.possessionPct===null?"N/D":`${profile.summary.possessionPct}%`}</dd></div><div><dt>Tiri / gara</dt><dd>${profile.summary.shotsPerGame??"N/D"}</dd></div><div><dt>Gol / gara</dt><dd>${profile.derived.goalsPerGame}</dd></div></dl><div class="reading-tactical-traits">${list("Punti di forza",profile.strengths)}${list("Vulnerabilità",profile.weaknesses)}${list("Stile",profile.playingStyle)}</div>${profile.notes?.length?`<p class="reading-tactical-note">${profile.notes.map(esc).join(" ")}</p>`:""}<a href="${esc(profile.source.url)}" target="_blank" rel="noreferrer">Fonte WhoScored</a></article>`};
  const target=document.querySelector(".reading-h2h-section");
  const currentTraits=[profileFor(match.homeTeam),profileFor(match.awayTeam)].some(profile=>profile?.characteristicsSeason==="2026-27");
  target?.insertAdjacentHTML("beforebegin",`<section class="section reading-tactical-baseline"><header class="section-heading"><div><p class="eyebrow">WhoScored · ${currentTraits?"baseline 2025/26 + tratti 2026/27":"stagione 2025/26"}</p><h2>Baseline tattica delle squadre</h2></div><p>${currentTraits?"I tratti correnti hanno ancora un campione iniziale; i numeri restano storici.":"Contesto storico, non previsione autonoma."}</p></header><div>${card(match.homeTeam)}${card(match.awayTeam)}</div><p class="objective-method">Il modello viene ricalcolato con forma 2026/27, assenze, formazioni disponibili e arbitro; le quote restano un confronto esterno.</p></section>`);
}
  async function render(){
    const page="readings",requestedMatchId=new URLSearchParams(location.search).get("match");
    const requestedMatchday=Number(requestedMatchId?.match(/-md-(\d{2})$/)?.[1]);
    // The directory never needs forecasts, rosters, events or historical archives.
    const index=await loadGenerated('readings/index.json');
    const payload=requestedMatchId&&index.fixtureIds.includes(requestedMatchId)?await loadReading(requestedMatchId):index;
    const {teams,matches,readings=[],objectiveProfiles=null,teamDirectory=null,teamStyleProfiles=null,predictionDataset=null,headToHeadData=null,refereeProfiles=null,forecastDataset=null}=payload;
    setReadingArtifacts(payload.artifacts||null);
    const league=matches.filter(m=>m.competition==="serie-a");
    const allTeams=teams;
    let html="",activeReading=null,activeReadingMatch=null,activePrediction=null;
  if(page==="readings")html=hero("Analisi prepartita","Lettura","Forma, assenze, tattica, arbitro e mercato: ogni segnale viene presentato come contesto, mai come certezza.")+`<section class="section">${readings.length?`<div class="grid">${readings.map(r=>`<article class="card"><h3>${esc(r.title)}</h3><p>${esc(r.summary)}</p></article>`).join("")}</div>`:`<div class="editorial-empty"><span class="editorial-empty-mark">L</span><div><p class="eyebrow">Prossimamente</p><h2>La prima lettura è in preparazione</h2><p>Le analisi appariranno qui quando saranno disponibili formazioni, quote e informazioni verificabili. Nessun dato verrà completato per supposizione.</p><a class="button button-primary" href="statistiche-squadre.html">Consulta le squadre</a></div><ol><li><strong>01</strong><span>Contesto e forma</span></li><li><strong>02</strong><span>Assenze e tattica</span></li><li><strong>03</strong><span>Arbitro e mercato</span></li></ol></div>`}</section>`;
  if(page==="readings"){
    const matchId=new URLSearchParams(location.search).get("match"),selectedMatch=league.find(match=>match.id===matchId),reading=readings.find(item=>item.matchId===matchId),prediction=predictionDataset?.predictions?.find(item=>item.matchId===matchId);
    activeReading=reading;
    activeReadingMatch=selectedMatch;
    activePrediction=prediction;
    const pairKey=selectedMatch?[selectedMatch.homeTeam,selectedMatch.awayTeam].sort().join("|"):null,history=headToHeadData?.fixtures?.find(fixture=>fixture.fixtureId===matchId||[fixture.homeTeamId,fixture.awayTeamId].sort().join("|")===pairKey);
    html=selectedMatch?readingPrototypeDetail(selectedMatch,reading,allTeams,teamDirectory,objectiveProfiles,prediction,history,refereeProfiles,forecastDataset?.marketCatalog):readingIndex(readings,league,allTeams,predictionDataset?.predictions||[],headToHeadData);
    if(matchId&&!selectedMatch)html=`<aside class="data-warning"><strong>Partita non trovata</strong><p>Il collegamento richiesto non corrisponde al calendario corrente.</p></aside>${html}`;
  }
    // Resolve presentation dependencies before exposing any match content.
    let finishReading=null;
  if(isReadingPilot('serie-a',activeReadingMatch?.id,location.search)&&typeof document.createElement==='function'){
    try{
      const [{adaptSerieAReading},{mountReadingShell,prepareReadingShell}]=await Promise.all([import('./reading-detail/serie-a-adapter.mjs?v=20261022-assets-v1'),import('./reading-detail/shell.mjs?v=20261106-current-tactics-v1')]);
      const analysis={match:activeReadingMatch,matches,teamDirectory,styles:teamStyleProfiles,referees:refereeProfiles,reading:activeReading,history:headToHeadData?.fixtures?.find(f=>f.fixtureId===activeReadingMatch.id),lineups:[activeReadingMatch.homeTeam,activeReadingMatch.awayTeam].map(id=>{const team=teamDirectory.teams.find(t=>t.id===id);return {team,lineup:fixtureLineupForMatch(activeReadingMatch,team,teamDirectory)}})};
      const model=adaptSerieAReading({match:activeReadingMatch,teams,teamDirectory,prediction:activePrediction,marketCatalog:forecastDataset?.marketCatalog,formation:formationPresentation(activeReadingMatch,teamDirectory),analysis});
      const prepared=await prepareReadingShell(model);
      finishReading=store=>mountReadingShell(model,undefined,{store,prepared});
    }catch(error){delete document.body.dataset.readingDetailTheme;console.warn('Lettura: vista precedente mantenuta.',error)}
  }
    document.querySelector("#app").innerHTML=html;
    const archivePanel=document.querySelector('#ri-archive-panel');
    for(const button of document.querySelectorAll('[data-archive-day]')){
      button.addEventListener('click',()=>{
        const opening=button.getAttribute('aria-expanded')!=='true';
        document.querySelectorAll('[data-archive-day]').forEach(item=>item.setAttribute('aria-expanded','false'));
        archivePanel.replaceChildren();
        archivePanel.hidden=!opening;
        if(opening){
          const template=document.getElementById(`ri-archive-content-${button.dataset.archiveDay}`);
          archivePanel.append(template.content.cloneNode(true));
          archivePanel.setAttribute('aria-labelledby',button.id);
          button.setAttribute('aria-expanded','true');
        }else archivePanel.removeAttribute('aria-labelledby');
      });
    }
    let personalReadingStore=null;
    if(activeReadingMatch&&publishedReadingForecasts(forecastDataset?.marketCatalog,activeReadingMatch.id,activeReadingMatch).length){
      const context={competition:'serie-a',season:'2026-27',matchday:requestedMatchday};
      const store=createPersonalBetslipStore();personalReadingStore=store;store.setContext(context);
      // Reconcile saved selections from other fixtures only when that bucket needs them.
      const savedIds=[...new Set(store.getSnapshot().selections.map(l=>l.matchId||l.betSelection?.identity?.matchId).filter(id=>id&&id!==activeReadingMatch.id&&index.fixtureIds.includes(id)))];
      const savedCatalogs=await Promise.all(savedIds.map(id=>loadReadingCatalog(id)));
      const latest=[forecastDataset,...savedCatalogs].flatMap(dataset=>(dataset?.marketCatalog?.matches||[]).flatMap(m=>sharedForecastsForMatch(dataset.marketCatalog,m.matchId,index.matches.find(f=>f.id===m.matchId)))).map(leg=>({...leg,context}));
      store.reconcile(latest);
      if(!finishReading){const content=document.querySelector('[data-reading-forecast-content]');if(content)installForecasts({competition:'serie-a',fixture:activeReadingMatch,forecasts:publishedReadingForecasts(forecastDataset.marketCatalog,activeReadingMatch.id,activeReadingMatch)},content,document.querySelector('#app'),store);}
    }

  if(page==="readings"&&activeReadingMatch){renderProbableLineups(activeReadingMatch,teamDirectory,activePrediction);if(activeReadingMatch.competition!=="coppa-italia")renderReadingPilotEvidence(activeReading,activeReadingMatch);renderTacticalBaselines(activeReadingMatch,teamStyleProfiles,teams)}
  if(finishReading){try{await finishReading(personalReadingStore)}catch(error){delete document.body.dataset.readingDetailTheme;console.warn('Lettura: vista precedente mantenuta.',error)}}

  }
  return {render};
}
