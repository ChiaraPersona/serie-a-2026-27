const release=new URL(import.meta.url).searchParams.get("v")||"development";
const {settleLeg:settleStrictLeg,settleArchivedLeg}=await import(`./betting-settlement.mjs?v=20261109-md11-results`);
const {createPersonalBetslipStore}=await import(`./personal-betslip-store.mjs?v=20261102-champions-no-draw`);
const {hasVerifiedPlayableQuote,isUnquotedIndividualForecast,sharedForecastsForMatch,isCanonicalModelForecast,uniqueForecastContracts,publicForecastLabel,meetsMinimumPublicOdds,isExcludedStraightDraw}=await import(`./shared-forecast-contract.mjs?v=20261102-champions-no-draw`);

const {loadChampionsWorkspaceMd3Derived}=await import(`./champions-workspace-catalog.mjs?v=20261104-champions-results`);
const {championsAuditDisplay}=await import(`./champions-audit-display.mjs?v=20261022-assets-v1`);
const {settleMd3Leg}=await import(`./champions-md3-results.mjs?v=20261022-assets-v1`);

const {archiveContractStats}=await import('./archive-contract-stats.mjs?v=20261102-champions-no-draw');

export function createPage(deps){
  const {esc,dateOnly,hero,load,loadGenerated}=deps;
  let compactForecasts=false;
  // Presentation only: keep the underlying family, semantics and IDs intact.
  const cardFamily=leg=>{
    const family=leg.betSelection?.market?.family||leg.marketFamily||leg.market||'Mercato';
    if(!compactForecasts)return family;
    if(['Tiri individuali','Tiri totali DUO'].includes(family))return 'Tiri totali';
    if(['Tiri in porta individuali','Tiri in porta DUO'].includes(family))return 'Tiri in porta';
    return family;
  };
  const presentationRank=leg=>{
    const scope=leg.betSelection?.market?.subject?.type||leg.betSelection?.forecastIdentity?.scope||leg.marketScope||'';
    const individual=/player/.test(scope)||leg.marketScope==='player'||Boolean(leg.playerId||leg.player);
    const base=individual?10:0;
    const text=[leg.suggestionAnalysis?.family,leg.marketFamily,leg.betSelection?.market?.name,leg.market].filter(Boolean).join(' ').toUpperCase();
    if(/\bSOT\b|TIRI IN PORTA|ON.TARGET/.test(text))return base+2;
    if(/\bTIRI\b|\bSHOTS\b/.test(text))return base+1;
    if(/\bRESULT\b|\b1X2\b|\bESITO\b|\bRISULTATO\b|DOPPIA CHANCE|DOUBLE.CHANCE/.test(text))return base;
    return base+3;
  };
  const visualOrder=(rows,getLeg=row=>row)=>compactForecasts?[...rows].sort((a,b)=>presentationRank(getLeg(a))-presentationRank(getLeg(b))):rows;
  const manualChampionsLegs=(legs,match)=>legs.filter(leg=>meetsMinimumPublicOdds(leg)&&!isExcludedStraightDraw(leg)&&!leg.suggestionAnalysis?.suggested&&(leg.context?.matchday!==3||Number.isFinite(leg.betSelection?.evaluation?.modelProbabilityPct)));
  let recordedOutcomes=[];
  const settleLeg=(leg,match)=>match?.id?.startsWith('ucl-2026-27-md03-')?settleMd3Leg(leg,match):settleArchivedLeg(leg,match,recordedOutcomes);
  const pct=value=>Number(value).toLocaleString("it-IT",Number(value)>0&&Number(value)<.01?{minimumFractionDigits:4,maximumFractionDigits:6}:{minimumFractionDigits:2,maximumFractionDigits:2});
  const odds=value=>Number(value).toLocaleString("it-IT",{minimumFractionDigits:2,maximumFractionDigits:2});
  const metric=(value,formatter,suffix="")=>Number.isFinite(value)?`${formatter(value)}${suffix}`:"N/D";
  let personalStore=null,currentContext=null,personalNotice="",personalUnsubscribe=null,personalDocumentClick=null,personalDocumentKeydown=null,personalMediaCleanup=null,personalNoticeTimer=null;
  const selectionRegistry=new Map(),slipRegistry=new Map();

  function registerSelection(leg,{fixture=leg.fixture,sourceSection="modello"}={}){
    const contract=leg?.betSelection;
    if(!meetsMinimumPublicOdds(leg)||isExcludedStraightDraw(leg)||!currentContext||!leg?.selectionId||contract?.selectionId!==leg.selectionId||(contract?.identity?.status!=="VERIFIED_PROVIDER_IDS"&&!isCanonicalModelForecast(leg)))return null;
    const selection={selectionId:leg.selectionId,context:{...currentContext},fixture:fixture||contract.identity.matchId,label:publicForecastLabel(leg)||contract.market?.selection||"Selezione",market:leg.market||contract.market?.name||"Mercato",sourceSection,scenarioAnalysis:leg.scenarioAnalysis||null,betSelection:contract};
    selectionRegistry.set(selection.selectionId,selection);
    return selection;
  }

  const personalPickButton=(selection,finished=false)=>selection?`<button type="button" class="betting-personal-pick" data-personal-pick="${esc(selection.selectionId)}" aria-pressed="false"${finished?" disabled":""}><span aria-hidden="true">＋</span><span>${finished?"Archiviata":"Aggiungi"}</span></button>`:"";

  function slipCard(slip,matchById){
    if(slip.legs.length&&!slip.legs.some(meetsMinimumPublicOdds))return "";
    if(slip.qualityStatus==="nd"&&!slip.legs.length)return `<article class="betting-nd-compact"><strong>${esc(slip.name)} · N/D</strong><span>${esc(slip.filterNote||"Dati insufficienti per una proposta prudenziale.")}</span></article>`;
    const selectable=[];
    const legs=visualOrder(slip.legs.filter(meetsMinimumPublicOdds)).map(leg=>{
      const settlement=settleLeg(leg,matchById.get(leg.matchId));
      const settled=["won","lost","void"].includes(settlement.status);
      const symbol=settlement.status==="won"?"✓":settlement.status==="lost"?"×":"—";
      const badge=settled?`<span class="betting-leg-result" aria-label="Esito ${esc(settlement.label.toLowerCase())}"><span aria-hidden="true">${symbol}</span> ${esc(settlement.label)}${settlement.reviewRequired?" · archiviato, target da verificare":""}</span>`:"";
      const selection=registerSelection(leg,{sourceSection:"schedina-modello"});
      if(selection&&!settled)selectable.push(selection);
      return `<li${settled?` class="betting-leg--${settlement.status}" data-settlement="${settlement.status}"`:""}><div><strong>${esc(leg.fixture)}</strong><span>${esc(publicForecastLabel(leg))} <small>· ${esc(leg.evidenceLabel)}</small></span>${badge}</div><b>${odds(leg.odds)}</b>${personalPickButton(selection,settled)}</li>`;
    }).join("");
    const slipKey=`model:${slip.id}`;
    if(selectable.length)slipRegistry.set(slipKey,selectable);
    const cardHeuristic=slip.legs.some(leg=>leg.marketFamily==="Ammoniti"||/PUNTI CARTELLINI/.test(leg.market||""));
    const duoIncompatible=slip.legs.some(leg=>leg.compatibility==="INCOMPATIBILE_DUO"||String(leg.probabilitySemantics||"").includes("INDIVIDUAL_V2_VS"));
    const families=slip.marketFamilies.map(esc).join(" · ");
    const weak=slip.weakestLeg&&meetsMinimumPublicOdds(slip.weakestLeg)?`<p class="betting-weakest">Gamba più fragile: <strong>${esc(slip.weakestLeg.label)}</strong> · ${cardHeuristic?"EV euristico non validato":"EV"} ${slip.weakestLeg.expectedValuePct>0?"+":""}${pct(slip.weakestLeg.expectedValuePct)}%${slip.filterNote?`<small>${esc(slip.filterNote)}</small>`:""}</p>`:"";
    const validation=slip.validationStatus?`<p class="betting-coverage"><strong>${esc(slip.validationStatus)}</strong> · ${esc(slip.risk||"rischio N/D")}</p>`:"";
    const semanticWarning=cardHeuristic?'<p class="betting-weakest">Cartellini: valori euristici non calibrati; probabilità DUO non modellata. Le quote derivate e l’EV non dimostrano un vantaggio statistico.</p>':duoIncompatible?'<p class="betting-weakest">Mercati giocatore DUO: la quota include il sostituto; sui SOT include anche pali/traverse. P V2 individuale, probabilità congiunta ed EV non calcolabili.</p>':"";
    const addAll=selectable.length?`<button type="button" class="betting-personal-add-slip" data-personal-add-slip="${esc(slipKey)}"><span aria-hidden="true">＋</span> Aggiungi tutte le ${selectable.length} selezioni</button>`:"";
    return `<article class="betting-slip betting-slip--${esc(slip.id)}" data-quality="${esc(slip.qualityStatus)}"><header><div><p>${esc(slip.eyebrow)}</p><h2>${esc(slip.name)}</h2><small>${families}</small></div></header>${validation}<div class="betting-slip-metrics"><div class="betting-slip-total"><span>Quota totale</span><strong>${metric(slip.combinedOdds,odds)}</strong><small>${slip.legs.length} giocate</small></div><div><span>${cardHeuristic?"Indice euristico non calibrato":duoIncompatible?"Probabilità congiunta":"Probabilità"}</span><strong>${metric(slip.jointModelProbabilityPct,pct,"%")}</strong></div><div><span>${cardHeuristic?"Quota derivata euristica":"Quota equa"}</span><strong>${metric(slip.fairOdds,odds)}</strong></div><div><span>${cardHeuristic?"EV euristico non validato":duoIncompatible?"EV non calcolabile":"EV stimato"}</span><strong>${metric(slip.expectedValuePct,pct,"%")}</strong></div></div>${addAll}<ol>${legs}</ol>${semanticWarning}${weak}</article>`;
  }

  function modelSections(data,matchById,{showLegend=false}={}){
    const model=data.slips.filter(slip=>!["laboratorio","nd"].includes(slip.qualityStatus)),laboratory=data.slips.filter(slip=>["laboratorio","nd"].includes(slip.qualityStatus));
    const selected=model.length?`<div class="betting-slip-grid betting-slip-grid-qualified">${model.map(slip=>slipCard(slip,matchById)).join("")}</div>`:`<div class="betting-nd-compact"><strong>Nessuna schedina del modello</strong><span>Non sono state forzate combinazioni per questa giornata.</span></div>`;
    const legend=showLegend?`<div class="betting-result-legend" aria-label="Legenda esiti"><span class="betting-result-legend--won"><b aria-hidden="true">✓</b> Esatto</span><span class="betting-result-legend--lost"><b aria-hidden="true">×</b> Sbagliato</span><span class="betting-result-legend--void"><b aria-hidden="true">—</b> Annullata</span><small>Se il calciatore non parte titolare, la selezione è esclusa dalle giocate e dal rendimento.</small></div>`:"";
    const coverage=data.coverage?`<p class="betting-coverage"><strong>${data.coverage.qualifiedProfiles} proposte qualificate</strong> su ${data.coverage.profilesEvaluated} profili valutati · ${data.coverage.unavailableProfiles} profili N/D.</p>`:"";
    const main=`<section class="betting-stage betting-model-section" aria-labelledby="betting-model-title"><header class="betting-section-heading"><h3 id="betting-model-title">Schedine del modello</h3></header>${legend}${selected}</section>`;
    const lab=laboratory.length?`<section class="betting-stage betting-lab-section" aria-labelledby="betting-lab-title"><header class="betting-section-heading"><h3 id="betting-lab-title">Analisi e laboratorio</h3></header><div class="betting-slip-grid">${laboratory.map(slip=>slipCard(slip,matchById)).join("")}</div><footer class="betting-method"><strong>Metodo</strong><p>${esc(data.methodology)}</p><p>Quote ${esc(data.provider)} aggiornate al ${esc(dateOnly(data.oddsRetrievedAt))}. <a href="${esc(data.sourceUrl)}" target="_blank" rel="noreferrer">Fonte quote</a>.</p></footer></section>`:"";
    const summary=`<section class="betting-essential" aria-labelledby="betting-essential-title"><h3 id="betting-essential-title">In sintesi</h3>${coverage}<p>${esc(data.selectionRule||"Nessuna selezione viene forzata.")}</p><p>Under, falli individuali, corner per tempo e doppia chance 12 non sono proposte giocabili dalla MD6; i corner dell'intera partita restano eleggibili. Quote: ${esc(data.provider)}, snapshot ${esc(dateOnly(data.oddsRetrievedAt))}.</p></section>`;
    return {summary,main,lab};
  }

  const hasValidEvaluation=leg=>{
    const evaluation=leg?.betSelection?.evaluation;
    return evaluation?.status!=="NOT_MODELLED"&&[evaluation?.modelProbabilityPct,evaluation?.fairOdds,evaluation?.expectedValuePct].every(Number.isFinite);
  };

  const isPlayableSelection=leg=>leg?.betSelection?.operational?.playability?.status!=="NOT_PLAYABLE"&&leg?.betSelection?.operational?.classification!=="ESCLUSO";

  const hasVisiblePreferred=leg=>leg?.context?.competition!=="champions"&&leg?.isPreferred===true;

  const editorialBadges=leg=>{
    const badges=[];
    if(leg?.isOutsider===true)badges.push('<b class="betting-outsider-badge">OUTSIDER</b>');
    if(hasVisiblePreferred(leg))badges.push('<b class="betting-preferred-badge"><span aria-hidden="true">★</span> PREFERITO</b>');
    return badges.length?`<span class="betting-editorial-badges">${badges.join("")}</span>`:"";
  };

  function selectableMarketRow({leg,sourceSection,showContractNote=true},index,fixture,match){
    if(!meetsMinimumPublicOdds(leg)||isExcludedStraightDraw(leg))return "";
    const evaluation=leg.betSelection.evaluation,market=leg.betSelection.market||{},semantics=market.bookmakerSemantics||{},selection=leg.auditDisplayOnly?null:registerSelection(leg,{fixture,sourceSection}),quote=leg.betSelection.quote.decimal==null?NaN:Number(leg.betSelection.quote.decimal),probability=evaluation.modelProbabilityPct==null?NaN:Number(evaluation.modelProbabilityPct),ev=evaluation.expectedValuePct==null?NaN:Number(evaluation.expectedValuePct),individualProbability=evaluation.individualReference?.modelProbabilityPct==null?NaN:Number(evaluation.individualReference.modelProbabilityPct),duo=semantics.duo===true;
    const metricText=(value,formatter,suffix="")=>Number.isFinite(value)?`${formatter(value)}${suffix}`:"—";
    const result=leg.context?.competition==="champions"&&leg.auditDisplayOnly&&leg.settlement?leg.settlement: settleLeg(leg,match),finished=match?.status==="finished",settled=["won","lost","void"].includes(result.status);
    const badge=finished&&(!settled||result.nonStarter)?`<span class="betting-leg-result" title="${esc(result.reason||"")}">${esc([!settled?"DA VERIFICARE":null,result.nonStarter?"NON TITOLARE":null].filter(Boolean).join(" · "))}</span>`:"";
    const contractNote=duo&&showContractNote?`<span class="betting-market-contract">Contratto Sisal DUO · giocatore + sostituto${semantics.postsAndCrossbarIncluded?" · pali/traverse inclusi":""}${Number.isFinite(individualProbability)?` · ${leg.context?.competition==="champions"?"Singolo":"V2 singolo"} ${pct(individualProbability)}% non applicata al DUO`:""}</span>`:"";
    return `<li class="betting-market-row betting-selection-row${leg.isOutsider===true?" is-outsider":""}${hasVisiblePreferred(leg)?" is-preferred":""}${settled||leg.auditDisplayOnly?` betting-leg--${result.status}`:""}"${finished?` data-settlement="${result.status}" aria-disabled="true"`:' role="button" tabindex="0"'} data-selection-row${leg.auditDisplayOnly?` data-selection-id="${esc(leg.selectionId)}"`:""}${leg.isOutsider===true?' data-outsider="true"':""}${hasVisiblePreferred(leg)?' data-preferred="true"':""}${finished?"":` data-personal-pick="${esc(selection.selectionId)}"`} data-selection-label="${esc(publicForecastLabel(leg))}" data-source-section="${esc(sourceSection)}" data-market-family="${esc(leg.marketFamily||market.family||"")}" data-bookmaker-contract="${duo?"duo":"standard"}" data-selected-forecast="${leg.context?.competition==="champions"&&leg.suggestionAnalysis?.suggested===false?"false":"true"}" data-order="${index}" data-ev="${Number.isFinite(ev)?ev:""}" data-probability="${Number.isFinite(probability)?probability:""}" data-odds="${Number.isFinite(quote)?quote:""}" aria-pressed="false" aria-label="${finished&&leg.auditDisplayOnly?`Esito ${esc(result.label||"da verificare")}: ${esc(publicForecastLabel(leg))}`:`Aggiungi alla schedina: ${esc(publicForecastLabel(leg))}`}"><div class="betting-market-copy"><small>${esc(cardFamily(leg))}</small>${editorialBadges(leg)}<strong>${esc(publicForecastLabel(leg))}</strong>${leg.publication?`<span class="betting-market-contract" data-publication-status="${esc(leg.publication.status)}">${leg.publication.status==='APPROVED'?'Approvata':leg.betSelection?.evaluation?.kind==='SHARED_DISCRETE_COUNT_PRELIMINARY'?'Probabilità preliminare':'Preliminare'}</span>`:leg.approvedPreliminary?'<span class="betting-market-contract">Singola preliminare approvata</span>':""}${badge}${contractNote}</div><span class="betting-market-metric"><small>${duo?"Probabilità DUO":"Probabilità"}</small><b>${metricText(probability,pct,"%")}</b></span><span class="betting-market-metric"><small>Quota Sisal</small><b>${metricText(quote,odds)}</b></span><span class="betting-market-metric betting-market-ev ${Number.isFinite(ev)?ev>=0?"is-positive":"is-negative":""}"><small>${duo?"EV DUO":leg.publication?.status==='PRELIMINARY'?(leg.publication?.selectionGate==='MD7_PORTFOLIO_CENTRAL_PROVISIONAL_PILOT'?"EV provvisorio":"EV teorico"):"EV"}</small><b>${Number.isFinite(ev)&&ev>0?"+":""}${metricText(ev,pct,"%")}</b></span><span class="betting-selection-check" aria-hidden="true">✓</span></li>`;
  }


  function unquotedForecastRow({leg,sourceSection},index){
    if(!meetsMinimumPublicOdds(leg)||isExcludedStraightDraw(leg))return "";
    const evaluation=leg.betSelection.evaluation,market=leg.betSelection.market||{},probability=Number(evaluation.modelProbabilityPct);
    return `<li class="betting-market-row betting-selection-row is-unquoted${leg.isOutsider===true?" is-outsider":""}${hasVisiblePreferred(leg)?" is-preferred":""}" data-selection-row${leg.isOutsider===true?' data-outsider="true"':""}${hasVisiblePreferred(leg)?' data-preferred="true"':""} data-selection-label="${esc(publicForecastLabel(leg))}" data-source-section="${esc(sourceSection)}" data-selected-forecast="${leg.context?.competition==='champions'&&leg.suggestionAnalysis?.suggested===false?'false':'true'}" data-order="${index}" data-quote-availability="unavailable" data-probability="${probability}" aria-disabled="true"><div class="betting-market-copy"><small>${esc(cardFamily(leg))}</small>${editorialBadges(leg)}<strong>${esc(publicForecastLabel(leg))}</strong></div><span class="betting-market-metric"><small>Probabilità</small><b>${Number.isFinite(probability)?`${pct(probability)}%`:"—"}</b></span><span class="betting-market-metric betting-market-quote-unavailable"><small>Quota Sisal</small><b>${leg.linkedSisalQuote?Number(leg.linkedSisalQuote.decimal).toLocaleString("it-IT",{minimumFractionDigits:2,maximumFractionDigits:2}):"Quota non disponibile"}</b>${leg.linkedSisalQuote?`<small>EV ${leg.linkedSisalQuote.expectedValuePct.toLocaleString("it-IT",{maximumFractionDigits:1})}% · quota verificata</small>`:""}</span></li>`;
  }

  function matchScenarioSummary(scenario){
    if(!scenario)return "";
    const probabilities=scenario.probabilities||{},prevalent=scenario.prevalentOutcome||scenario.prevalentOutcomes?.join("/")||"N/D",modal=scenario.modalExactScore,band=scenario.goalDistribution?.dominantBand;
    return `<section class="betting-scenario-summary" aria-label="Scenario predittivo V2"><div class="betting-scenario-main"><small>Scenario prevalente</small><strong>${esc(prevalent)}</strong><span>Non è una certezza</span></div><div class="betting-scenario-probabilities" aria-label="Probabilità uno X due"><span><b>1</b>${metric(probabilities["1"],pct,"%")}</span><span><b>X</b>${metric(probabilities.X,pct,"%")}</span><span><b>2</b>${metric(probabilities["2"],pct,"%")}</span></div><p>${esc(scenario.description||"")}${modal?` <span>Moda esatta: <strong>${esc(modal.score)}</strong>${Number.isFinite(modal.probabilityPct)?` (${pct(modal.probabilityPct)}%)`:""}.</span>`:""}${band?` <span>Banda gol prevalente: <strong>${esc(band.label)}</strong> (${pct(band.probabilityPct)}%).</span>`:""}</p><div class="betting-scenario-legend" aria-label="Legenda relazione mercati"><span><i class="betting-scenario-dot betting-scenario-dot--coherent"></i>Coerente</span><span><i class="betting-scenario-dot betting-scenario-dot--alternative"></i>Alternativa</span><span><i class="betting-scenario-dot betting-scenario-dot--multi"></i>Multi-scenario</span><span><i class="betting-scenario-dot betting-scenario-dot--undetermined"></i>N/D</span></div></section>`;
  }

  function matchdayWorkspaceContent(data,predictions,matchById,teamById,matchday){
    const code=String(matchday).padStart(2,"0"),modelByMatch=new Map(),catalogByMatch=new Map((data.marketCatalog?.matches||[]).map(match=>[match.matchId,match]));
    data.slips.flatMap(slip=>slip.legs.map(leg=>({leg,sourceSection:slip.qualityStatus==="laboratorio"?"laboratorio":"schedina-modello"}))).filter(({leg})=>hasValidEvaluation(leg)&&hasVerifiedPlayableQuote(leg)).forEach(entry=>{
      const rows=modelByMatch.get(entry.leg.matchId)||[];rows.push(entry);modelByMatch.set(entry.leg.matchId,rows);
    });
    const predictionsByMatch=new Map(predictions.filter(prediction=>prediction.matchId.endsWith(`-md-${code}`)).map(prediction=>[prediction.matchId,prediction]));
    const matches=[...matchById.values()].filter(match=>data.championsWorkspace||match.id.endsWith(`-md-${code}`)).sort((left,right)=>`${left.date}T${left.kickoff||"00:00"}`.localeCompare(`${right.date}T${right.kickoff||"00:00"}`));
    const panels=matches.map(match=>{
      const home=teamById.get(match.homeTeam)?.name||match.homeTeam,away=teamById.get(match.awayTeam)?.name||match.awayTeam,prediction=predictionsByMatch.get(match.id),combo=prediction?.combinations?.find(item=>item.tier==="Safe"),comboLegs=combo?.legs||[],seen=new Set(),markets=[];
      const catalog=catalogByMatch.get(match.id),shared=sharedForecastsForMatch(data.marketCatalog,match.id,match),entries=data.lineupManaged?shared.map(leg=>({leg,sourceSection:leg.catalogOrigin||"catalogo-mercati"})):data.championsWorkspace?(catalog?.selections||[]).filter(leg=>leg.suggestionAnalysis?.suggested&&(!data.matchday||data.matchday!==3||leg.approvedPreliminary||leg.qualifiedSelection||leg.catalogOrigin==="champions-md03-individual-model")).map(leg=>({leg,sourceSection:leg.catalogOrigin||"archivio-champions"})):catalog?.selections?.length?shared.map(leg=>({leg,sourceSection:leg.catalogOrigin||"catalogo-mercati"})):[...(modelByMatch.get(match.id)||[]),...comboLegs.filter(hasVerifiedPlayableQuote).map(leg=>({leg,sourceSection:"mycombo-partita"}))];
      uniqueForecastContracts(entries.filter(entry=>meetsMinimumPublicOdds(entry.leg)),entry=>entry.leg).forEach(entry=>{if(entry.leg.selectionId&&!seen.has(entry.leg.selectionId)){seen.add(entry.leg.selectionId);markets.push(entry)}});markets.sort((left,right)=>Number(left.leg.suggestionAnalysis.rank)-Number(right.leg.suggestionAnalysis.rank));
      let selectedCount=markets.length;
      if(compactForecasts&&data.championsWorkspace&&data.matchday!==3&&!data.lineupManaged)for(const leg of manualChampionsLegs(catalog?.selections||[],match)){
        if(!seen.has(leg.selectionId)){seen.add(leg.selectionId);markets.push({leg,sourceSection:'catalogo-manuale-champions'});}
      }
      const uniqueMarkets=uniqueForecastContracts(markets,entry=>entry.leg);
      markets.splice(0,markets.length,...uniqueMarkets);
      selectedCount=markets.filter(entry=>entries.includes(entry)).length;
      if(compactForecasts)markets.sort((a,b)=>presentationRank(a.leg)-presentationRank(b.leg));
      const fixture=`${home} - ${away}`,marketList=markets.length?`<div class="betting-market-columns" aria-hidden="true"><span>Mercato</span><span>Probabilità</span><span>Quota Sisal</span><span>EV</span><span></span></div><ol class="betting-market-list">${data.championsWorkspace?championsGroupedRows(markets,fixture,match):markets.map((entry,index)=>isUnquotedIndividualForecast(entry.leg)?unquotedForecastRow(entry,index):selectableMarketRow(entry,index,fixture,match)).join("")}</ol>`:`<p class="betting-market-empty">Nessun pronostico selezionato per questa partita.</p>`;
      return `<details class="betting-match-panel" data-match-panel data-match-id="${esc(match.id)}"><summary><span><small>${esc(dateOnly(match.date))} · ${esc(match.kickoff||"Orario N/D")}</small><strong>${esc(home)} - ${esc(away)}</strong></span><span class="betting-match-count">${selectedCount} pronostici selezionati</span><span class="betting-match-toggle" aria-hidden="true">＋</span></summary><div class="betting-match-body">${marketList}${data.championsWorkspace?`<a class="betting-match-reading-link" href="${esc(match.readingUrl)}">Apri la lettura della partita →</a>`:""}</div></details>`;
    }).join("");
    return `<section class="betting-matchday-shell" aria-label="Pronostici delle partite"><header class="betting-matchday-heading"><div class="betting-matchday-actions"><button type="button" data-match-open-all>Apri tutte</button><button type="button" data-match-close-all>Chiudi tutte</button></div></header><div class="betting-match-list">${panels}</div></section>`;
  }

  function archiveRoundContent(data,matchById,{showLegend=false}={}){
    const qualified=data.slips.filter(slip=>slip.qualityStatus==="qualificata"),others=data.slips.filter(slip=>slip.qualityStatus!=="qualificata");
    const selected=qualified.length?`<div class="betting-slip-grid betting-slip-grid-qualified">${qualified.map(slip=>slipCard(slip,matchById)).join("")}</div>`:`<div class="betting-nd-compact"><strong>Nessuna schedina qualificata</strong><span>Il controllo prudenziale non forza proposte: restano disponibili le letture editoriali e di laboratorio.</span></div>`;
    const legend=showLegend?`<div class="betting-result-legend" aria-label="Legenda esiti"><span class="betting-result-legend--won"><b aria-hidden="true">✓</b> Esatto</span><span class="betting-result-legend--lost"><b aria-hidden="true">×</b> Sbagliato</span><span class="betting-result-legend--void"><b aria-hidden="true">—</b> Annullata</span><small>Se il calciatore non parte titolare, la selezione è esclusa dalle giocate e dal rendimento.</small></div>`:"";
    const coverage=data.coverage?`<p class="betting-coverage"><strong>${data.coverage.qualifiedProfiles} proposte qualificate</strong> su ${data.coverage.profilesEvaluated} profili valutati · ${data.coverage.unavailableProfiles} profili N/D.</p>`:"";
    return `<div class="betting-stage"><header class="betting-intro"><div><p class="eyebrow">Controllo prudenziale</p><h3>Selezionate dal modello</h3></div><p>${esc(data.selectionRule||"Entrano qui soltanto schedine con EV non negativo e nessuna gamba sotto −10% di EV individuale.")}</p></header>${coverage}${legend}${selected}${others.length?`<header class="betting-section-heading"><div><p class="eyebrow">Letture editoriali e laboratorio</p><h3>Scenari non qualificati</h3></div><p>Restano visibili per confronto, con rischio ed EV dichiarati.</p></header><div class="betting-slip-grid">${others.map(slip=>slipCard(slip,matchById)).join("")}</div>`:""}<footer class="betting-method"><strong>Come leggere i numeri</strong><p>${esc(data.methodology)}</p><p>Quote ${esc(data.provider)} aggiornate al ${esc(dateOnly(data.oddsRetrievedAt))}. <a href="${esc(data.sourceUrl)}" target="_blank" rel="noreferrer">Fonte quote</a>. Gioca responsabilmente: pagina editoriale, nessun esito è certo.</p></footer></div>`;
  }

  function myComboRoundContent(predictions,matchById,teamById,matchday,champions=false){
    const code=String(matchday).padStart(2,"0");
    const entries=predictions.filter(prediction=>champions||prediction.matchId.endsWith(`-md-${code}`)).map(prediction=>({prediction,combo:(()=>{const combo=prediction.combinations?.find(item=>item.tier==="Safe");return combo?{...combo,legs:combo.legs.filter(meetsMinimumPublicOdds)}:null})(),match:matchById.get(prediction.matchId)})).filter(item=>item.match&&item.combo?.legs?.length).sort((left,right)=>`${left.match.date}T${left.match.kickoff||"00:00"}`.localeCompare(`${right.match.date}T${right.match.kickoff||"00:00"}`));
    if(matchday===5){
      const cards=entries.map(({combo,match})=>{const home=teamById.get(match.homeTeam)?.name||match.homeTeam,away=teamById.get(match.awayTeam)?.name||match.awayTeam,results=combo.legs.map(leg=>settleLeg({...leg,fixture:`${home} - ${away}`},match)),won=results.filter(result=>result.status==="won").length,decided=results.filter(result=>["won","lost","void"].includes(result.status)).length,pending=results.length-decided,legs=combo.legs.map((leg,index)=>{const result=results[index],settled=["won","lost","void"].includes(result.status),status=settled?result.status:"unavailable";return `<li class="betting-leg--${status}" data-settlement="${status}"><button type="button" class="betting-mycombo-pick" data-mycombo-pick aria-pressed="false" disabled><span class="betting-mycombo-pick-copy"><strong>${esc(leg.market)}</strong><span>${esc(publicForecastLabel(leg))}</span><span class="betting-leg-result">${esc(settled?result.label:"Da verificare")}</span></span><b>${odds(leg.odds)}</b></button></li>`}).join("");return `<article class="betting-slip betting-mycombo-card" data-match-id="${esc(match.id)}" data-finished="true"><header><div><p>MyCombo · risultati</p><h2>${esc(home)} - ${esc(away)}</h2><small>Finale ${match.score?.home??"N/D"}-${match.score?.away??"N/D"} · verde = esito preso</small></div></header><div class="betting-slip-metrics"><div class="betting-slip-total"><span>Esiti presi</span><strong>${won}</strong><small>${decided} esiti verificati</small></div><div><span>Da verificare</span><strong>${pending}/${results.length}</strong></div></div><ol class="betting-mycombo-options">${legs}</ol></article>`}).join("");
      return `<section class="betting-mycombo-round" aria-labelledby="betting-mycombo-md05-title"><header class="betting-section-heading"><div><p class="eyebrow">Una per ogni partita</p><h3 id="betting-mycombo-md05-title">MyCombo · 10 esiti per gara</h3></div><p>Snapshot archiviate e risultati verificabili.</p></header><div class="betting-slip-grid">${cards}</div></section>`;
    }
    const legRow=(leg,index,match,finished,forceDisabled=false)=>{const home=teamById.get(match.homeTeam)?.name||match.homeTeam,away=teamById.get(match.awayTeam)?.name||match.awayTeam,result=champions&&leg.auditDisplayOnly&&leg.settlement?leg.settlement:settleLeg({...leg,fixture:`${home} - ${away}`},match),settled=finished&&["won","lost","void"].includes(result.status),status=finished?(settled?result.status:"unavailable"):"pending",classification=leg.betSelection?.operational?.classification,reliability=leg.betSelection?.operational?.reliability?.level||"Non valutabile",playable=leg.betSelection?.operational?.playability?.status!=="NOT_PLAYABLE",selection=!leg.auditDisplayOnly&&!forceDisabled&&playable&&classification!=="ESCLUSO"?registerSelection(leg,{fixture:`${home} - ${away}`,sourceSection:"mycombo-partita"}):null,badge=finished?`<span class="betting-leg-result">${esc(settled?result.label:"Da verificare")}</span>`:"";return `<li${finished?` class="betting-leg--${status}" data-settlement="${status}"`:""}><button type="button" class="betting-mycombo-pick" data-mycombo-pick${selection?` data-personal-pick="${esc(selection.selectionId)}"`:""} aria-pressed="false"${finished||!selection?" disabled":""}><span class="betting-mycombo-pick-copy"><strong>${esc(publicForecastLabel(leg))}</strong><span>${esc(leg.market)} · ${esc(classification||"Non valutabile")} · Affidabilità ${esc(reliability)}</span>${badge}</span><b>${odds(leg.odds)}</b></button></li>`};
    const cards=entries.map(({combo,match})=>{
      const home=teamById.get(match.homeTeam)?.name||match.homeTeam,away=teamById.get(match.awayTeam)?.name||match.awayTeam,finished=match.status==="finished";
      const main=combo.legs.filter(leg=>["PRINCIPALE","INTERESSANTE","OUTSIDER"].includes(leg.betSelection?.operational?.classification)&&leg.betSelection?.operational?.playability?.status!=="NOT_PLAYABLE");
      const watch=combo.legs.filter(leg=>leg.betSelection?.operational?.classification==="WATCH"&&leg.betSelection?.operational?.playability?.status!=="NOT_PLAYABLE");
      const review=combo.legs.filter(leg=>!main.includes(leg)&&!watch.includes(leg));
      const mainRows=main.length?`<div class="betting-mycombo-group"><h4>Proposte</h4><ol class="betting-mycombo-options">${visualOrder(main).map((leg,index)=>legRow(leg,index,match,finished)).join("")}</ol></div>`:"";
      const watchRows=watch.length?`<details class="betting-mycombo-watch"><summary>${champions?"Alternative con probabilità · non approvate":"WATCH"}</summary><ol class="betting-mycombo-options">${visualOrder(watch).map((leg,index)=>legRow(leg,index,match,finished)).join("")}</ol></details>`:"";
      const reviewRows=review.length?`<details class="betting-mycombo-review"><summary>Non valutabili</summary><ol class="betting-mycombo-options">${visualOrder(review).map((leg,index)=>legRow(leg,index,match,finished,true)).join("")}</ol></details>`:"";
      return `<details class="betting-mycombo-card" data-match-id="${esc(match.id)}"${finished?' data-finished="true"':""}><summary><span><small>${esc(dateOnly(match.date))} · ${esc(match.kickoff||"Orario N/D")}</small><strong>${esc(home)} - ${esc(away)}</strong></span><span aria-hidden="true">＋</span></summary><div class="betting-mycombo-body">${mainRows}${watchRows}${reviewRows}</div></details>`;
    }).join("");
    return `<section class="betting-mycombo-round" aria-labelledby="betting-mycombo-md${code}-title"><header class="betting-section-heading"><h3 id="betting-mycombo-md${code}-title">MyCombo per partita</h3><div class="betting-mycombo-actions"><button type="button" data-mycombo-open-all>Apri tutte</button><button type="button" data-mycombo-close-all>Chiudi tutte</button></div></header><div class="betting-mycombo-list">${cards}</div></section>`;
  }

  function bindMyComboInteractions(matchday){
    const storageKey=`serie-a-2026-27:mycombo-open:v1:md${String(matchday).padStart(2,"0")}`,details=[...document.querySelectorAll(".betting-mycombo-card")];
    let saved=[];try{saved=JSON.parse(localStorage.getItem(storageKey)||"[]")}catch(_error){saved=[]}
    details.forEach(detail=>{detail.open=saved.includes(detail.dataset.matchId);detail.addEventListener("toggle",()=>{try{localStorage.setItem(storageKey,JSON.stringify(details.filter(item=>item.open).map(item=>item.dataset.matchId)))}catch(_error){}})});
    document.querySelector("[data-mycombo-open-all]")?.addEventListener("click",()=>details.forEach(detail=>{detail.open=true}));
    document.querySelector("[data-mycombo-close-all]")?.addEventListener("click",()=>details.forEach(detail=>{detail.open=false}));
    updatePersonalSelectionControls(personalStore?.getSnapshot());
  }

  function bindMatchdayInteractions(matchday){
    const storageKey=`serie-a-2026-27:match-open:v1:md${String(matchday).padStart(2,"0")}`,panels=[...document.querySelectorAll("[data-match-panel]")];
    let saved=[];try{saved=JSON.parse(localStorage.getItem(storageKey)||"[]")}catch(_error){saved=[]}
    const persist=()=>{try{localStorage.setItem(storageKey,JSON.stringify(panels.filter(panel=>panel.open).map(panel=>panel.dataset.matchId)))}catch(_error){}};
    panels.forEach(panel=>{
      panel.open=saved.includes(panel.dataset.matchId);
      panel.addEventListener("toggle",persist);
    });
    document.querySelector("[data-match-open-all]")?.addEventListener("click",()=>panels.forEach(panel=>{panel.open=true}));
    document.querySelector("[data-match-close-all]")?.addEventListener("click",()=>panels.forEach(panel=>{panel.open=false}));
    updatePersonalSelectionControls(personalStore?.getSnapshot());
  }

  const personalContextLabel=context=>context?.label||`${context?.competition||"Competizione"} · ${context?.season||"stagione N/D"} · giornata ${context?.matchday??"N/D"}`;

  function updatePersonalSelectionControls(snapshot){
    const selected=new Set((snapshot?.selections||[]).map(selection=>selection.selectionId));
    document.querySelectorAll("[data-personal-pick]").forEach(button=>{
      const active=selected.has(button.dataset.personalPick);
      button.setAttribute("aria-pressed",String(active));
      button.classList.toggle("is-selected",active);
      if(button.dataset.selectionLabel)button.setAttribute("aria-label",`${active?"Rimuovi dalla":"Aggiungi alla"} schedina: ${button.dataset.selectionLabel}`);
      if(button.classList.contains("betting-personal-pick")){
        const label=button.querySelector("span:last-child");
        if(label&&!button.disabled)label.textContent=active?"Aggiunta":"Aggiungi";
      }

    });
    document.querySelectorAll(".betting-mycombo-card").forEach(card=>{
      const count=[...card.querySelectorAll("[data-personal-pick]")].filter(button=>button.getAttribute("aria-pressed")==="true").length;
      const output=card.querySelector("[data-mycombo-active]");
      if(output)output.textContent=String(count);
    });
    document.querySelectorAll("[data-personal-count]").forEach(output=>output.textContent=String(snapshot?.selections?.length||0));
  }

  function personalBetslipMarkup(){
    return `<div class="personal-betslip-root" data-personal-root><button type="button" class="personal-betslip-trigger" data-personal-open aria-controls="personal-betslip-panel" aria-expanded="false"><span>La mia schedina</span><b data-personal-count>0</b></button><aside id="personal-betslip-panel" class="personal-betslip-panel" role="dialog" aria-modal="false" aria-labelledby="personal-betslip-title" hidden><header><div><h2 id="personal-betslip-title" tabindex="-1">La mia schedina</h2></div><button type="button" class="personal-betslip-close" data-personal-close aria-label="Chiudi la mia schedina">×</button></header><p class="personal-betslip-context" data-personal-context></p><p class="personal-betslip-notice" data-personal-notice aria-live="polite"></p><div class="personal-betslip-content" data-personal-content></div><footer><button type="button" class="personal-betslip-clear" data-personal-clear>Svuota</button></footer></aside></div>`;
  }

  function issueLabel(issue){
    const labels={EXACT_DUPLICATE:"Duplicato",LOGICAL_OVERLAP:"Correlazione o sovrapposizione",LOGICAL_IMPLICATION:"Implicazione logica",SCENARIO_INCOMPATIBILITY:"Incompatibilità logica",MARKET_CONTRADICTION:"Incompatibilità logica",BOOKMAKER_COMBINABILITY_UNKNOWN:"Combinabilità bookmaker non verificata",MISSING_VERIFIED_QUOTE:"Quota non verificata",AVAILABILITY_NOT_CONFIRMED:"Disponibilità non confermata",MODEL_BOOKMAKER_INCOMPATIBLE:"Mercato incompatibile",MISSING_FROM_CURRENT_DATA:"Non più nei dati correnti",UNDER_NOT_PLAYABLE:"Under non giocabile",INDIVIDUAL_FOUL_NOT_PLAYABLE:"Falli individuali non giocabili",CORNER_PERIOD_NOT_PLAYABLE:"Corner per tempo non giocabile"};
    return labels[issue.type]||"Verifica richiesta";
  }

  function renderPersonalBetslip(snapshot){
    const root=document.querySelector("[data-personal-root]");
    if(!root)return;
    const context=root.querySelector("[data-personal-context]");
    const content=root.querySelector("[data-personal-content]");
    const notice=root.querySelector("[data-personal-notice]");
    const panel=root.querySelector(".personal-betslip-panel"),footer=panel.querySelector("footer"),selections=snapshot?.selections||[],assessment=snapshot?.assessment||{theoreticalCombinedOdds:null,theoreticalExcludedCount:0};
    context.textContent=snapshot?.context?personalContextLabel(snapshot.context):"Apri una giornata per iniziare o riprendere la schedina.";
    notice.textContent=personalNotice||snapshot?.storageError||"";
    notice.hidden=!notice.textContent;
    const rows=selections.map(selection=>{
      const quote=selection.betSelection?.quote||{};
      const semantics=selection.betSelection?.market?.bookmakerSemantics||{};
      const quoteText=quote.decimal!=null&&quote.decimal!==""&&Number.isFinite(Number(quote.decimal))?odds(quote.decimal):"—";
      const snapshotText=quote.verifiedAt?dateOnly(quote.verifiedAt):"N/D";
      const duoContract=semantics.duo===true?`<span class="personal-betslip-contract">Contratto DUO: giocatore + eventuale sostituto${semantics.postsAndCrossbarIncluded?"; pali e traverse inclusi":""}. Probabilità DUO ed EV: N/D.</span>`:"";
      const flags=[];
      if(selection.quoteChanged)flags.push(`Quota aggiornata${selection.previousQuote?` da ${odds(selection.previousQuote)}`:""}`);
      return `<li class="personal-betslip-item"><div><small>${esc(selection.fixture||"Partita N/D")}</small><strong>${esc(selection.label||"Selezione N/D")}</strong><span>${esc(selection.market||selection.betSelection?.market?.name||"Mercato N/D")} · quota ${quoteText} · snapshot ${esc(snapshotText)}</span>${duoContract}${flags.map(flag=>`<em>${esc(flag)}</em>`).join("")}</div><button type="button" class="personal-betslip-remove" data-personal-remove="${esc(selection.selectionId)}" aria-label="Rimuovi selezione" title="Rimuovi selezione"><span aria-hidden="true">×</span></button></li>`;
    }).join("");
    const relationshipIssues=(assessment.issues||[]).filter(issue=>["MARKET_CONTRADICTION","SCENARIO_INCOMPATIBILITY","LOGICAL_OVERLAP","LOGICAL_IMPLICATION","BOOKMAKER_COMBINABILITY_UNKNOWN"].includes(issue.type)),uniqueRelationshipIssues=[...new Map(relationshipIssues.map(issue=>[`${issue.type}:${(issue.selectionIds||[]).slice().sort().join("|")}`,issue])).values()],analysis=!assessment.pendingModelQuote&&selections.length>1&&uniqueRelationshipIssues.length?`<section class="personal-betslip-analysis" aria-label="Relazioni tra selezioni"><strong>Relazioni tra selezioni</strong><ul>${uniqueRelationshipIssues.map(issue=>`<li data-issue-type="${esc(issue.type)}"><b>${esc(issueLabel(issue))}</b><span>${esc(issue.message)}</span></li>`).join("")}</ul><small>Nessuna probabilità combinata viene stimata. La combinabilità commerciale resta separata.</small></section>`:"";
    const partial=Number(assessment.theoreticalExcludedCount)||0,totalValue=assessment.theoreticalCombinedOdds==null?"—":odds(assessment.theoreticalCombinedOdds),total=`<div class="personal-betslip-total"><span>Quota combinata teorica</span><strong>${totalValue}</strong><small>${assessment.pendingModelQuote?"":partial?`Totale parziale: ${partial} ${partial===1?"selezione non inclusa":"selezioni non incluse"} perché senza quota valida o non giocabili.`:"Prodotto matematico delle quote selezionate; non conferma la combinabilità Sisal."}</small></div>`,emptyTotal='<div class="personal-betslip-total personal-betslip-total--empty"><span>Quota combinata teorica</span><strong>—</strong></div>';
    content.innerHTML=selections.length?`<ol class="personal-betslip-list">${rows}</ol>${analysis}${total}`:`<div class="personal-betslip-empty"><span class="personal-betslip-empty-icon" aria-hidden="true">＋</span><strong>Nessuna selezione</strong><span>Aggiungi una giocata per iniziare</span></div>${emptyTotal}`;
    panel.classList.toggle("is-empty",!selections.length);
    footer.hidden=!selections.length;
    root.querySelector("[data-personal-clear]").disabled=!selections.length;
    updatePersonalSelectionControls(snapshot);
  }

  function setPersonalNotice(message){
    personalNotice=message;
    if(personalNoticeTimer)clearTimeout(personalNoticeTimer);
    renderPersonalBetslip(personalStore?.getSnapshot());
    if(message)personalNoticeTimer=setTimeout(()=>{personalNotice="";renderPersonalBetslip(personalStore?.getSnapshot())},2200);
  }

  function mountPersonalBetslip(){
    personalUnsubscribe?.();
    if(personalDocumentClick)document.removeEventListener("click",personalDocumentClick);
    if(personalDocumentKeydown)document.removeEventListener("keydown",personalDocumentKeydown);
    personalMediaCleanup?.();
    document.querySelector("[data-personal-root]")?.remove();
    const host=document.querySelector("[data-personal-host]");
    if(!host)return;
    host.innerHTML=personalBetslipMarkup();
    const root=document.querySelector("[data-personal-root]"),panel=root.querySelector(".personal-betslip-panel"),trigger=root.querySelector("[data-personal-open]");
    const desktop=window.matchMedia("(min-width:1180px)");let previousFocus=null,mobileOpen=false;
    const syncMode=()=>{if(desktop.matches){panel.hidden=false;panel.dataset.open="true";panel.setAttribute("role","region");panel.setAttribute("aria-modal","false");trigger.setAttribute("aria-expanded","true")}else{panel.setAttribute("role","dialog");panel.setAttribute("aria-modal","true");if(!mobileOpen){delete panel.dataset.open;panel.hidden=true;trigger.setAttribute("aria-expanded","false")}}};
    const open=()=>{if(desktop.matches)return;previousFocus=document.activeElement;mobileOpen=true;panel.hidden=false;requestAnimationFrame(()=>panel.dataset.open="true");trigger.setAttribute("aria-expanded","true");panel.querySelector("[data-personal-close]").focus()};
    const close=()=>{if(desktop.matches)return;mobileOpen=false;delete panel.dataset.open;trigger.setAttribute("aria-expanded","false");setTimeout(()=>{if(!mobileOpen&&!desktop.matches)panel.hidden=true},180);(previousFocus?.isConnected?previousFocus:trigger).focus()};
    desktop.addEventListener("change",syncMode);personalMediaCleanup=()=>desktop.removeEventListener("change",syncMode);syncMode();
    root.addEventListener("click",async event=>{
      const openButton=event.target.closest("[data-personal-open]"),closeButton=event.target.closest("[data-personal-close]"),removeButton=event.target.closest("[data-personal-remove]"),clearButton=event.target.closest("[data-personal-clear]");
      if(openButton){open();return}if(closeButton){close();return}
      if(removeButton){personalStore.remove(removeButton.dataset.personalRemove);setPersonalNotice("Selezione rimossa.");return}
      if(clearButton&&window.confirm("Vuoi svuotare la schedina personale di questa giornata?")){const result=personalStore.clear();setPersonalNotice(`Schedina svuotata: ${result.removed||0} selezioni rimosse.`);return}
    });
    const togglePersonalPick=pick=>{
      if(pick&&!pick.disabled){
        const id=pick.dataset.personalPick,snapshot=personalStore.getSnapshot(),active=snapshot.selections.some(selection=>selection.selectionId===id);
        const result=active?personalStore.remove(id):personalStore.add(selectionRegistry.get(id));
        const notices={ADDED:"Selezione aggiunta.",REMOVED:"Selezione rimossa.",DUPLICATE:"Selezione già presente.",UNDER_NOT_PLAYABLE:"Gli Under sono esclusi dalle proposte giocabili dalla sesta giornata.",INDIVIDUAL_FOUL_NOT_PLAYABLE:"I falli individuali sono esclusi dalle proposte giocabili dalla sesta giornata.",CORNER_PERIOD_NOT_PLAYABLE:"I corner riferiti a singoli tempi sono esclusi dalle proposte giocabili dalla sesta giornata.",UNVERIFIED_IDENTITY:"Selezione non aggiunta: identificazione bookmaker non verificata.",CONTEXT_MISMATCH:"Selezione non aggiunta: giornata o competizione non coerente."};
        setPersonalNotice(notices[result.status]||"Operazione non disponibile.");
      }
    };
    personalDocumentClick=event=>{
      const pick=event.target.closest("[data-personal-pick]");
      if(pick)togglePersonalPick(pick);
      const addSlip=event.target.closest("[data-personal-add-slip]");
      if(addSlip&&!addSlip.disabled){
        const result=personalStore.addMany(slipRegistry.get(addSlip.dataset.personalAddSlip)||[]);
        setPersonalNotice(`${result.added} aggiunte${result.duplicates?` · ${result.duplicates} già presenti`:""}${result.rejected.length?` · ${result.rejected.length} non aggiunte`:""}.`);
      }
    };
    personalDocumentKeydown=event=>{const pick=event.target.closest('[data-selection-row][data-personal-pick]');if(pick&&(event.key==="Enter"||event.key===" ")){event.preventDefault();togglePersonalPick(pick)}};
    document.addEventListener("click",personalDocumentClick);
    document.addEventListener("keydown",personalDocumentKeydown);
    panel.addEventListener("keydown",event=>{
      if(event.key==="Escape"){event.preventDefault();close();return}
      if(event.key!=="Tab")return;
      const focusable=[...panel.querySelectorAll('button:not([disabled]),a[href],[tabindex]:not([tabindex="-1"])')];
      if(!focusable.length)return;
      const first=focusable[0],last=focusable.at(-1);
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus()}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus()}
    });
    personalUnsubscribe=personalStore.subscribe(renderPersonalBetslip);
    renderPersonalBetslip(personalStore.getSnapshot());
  }

  function initializePersonalBetslip(context){
    personalStore=personalStore||createPersonalBetslipStore();
    if(context){personalStore.setContext(context);personalStore.reconcile([...selectionRegistry.values()])}
    mountPersonalBetslip();
  }

  function archiveStats(data,matchById,resolve=leg=>settleLeg(leg,matchById.get(leg.matchId))){
    const legs=data.matchday>=6
      ?(data.marketCatalog?.matches||[]).flatMap(match=>sharedForecastsForMatch(data.marketCatalog,match.matchId,matchById?.get(match.matchId))).filter(hasVerifiedPlayableQuote)
      :data.slips.flatMap(slip=>slip.legs);
    return archiveContractStats(legs,resolve);
  }
  const ordinalWord=number=>number===1?"prima":number===2?"seconda":number===3?"terza":number===4?"quarta":`${number}ª`;
  function archiveCard(data,number,matchById){
    const stats=archiveStats(data,matchById);
    const finished=stats.archiveStake>0;
    const detail=`<span class="betting-archive-performance"><span><small>Successo</small><strong>${metric(finished?stats.archiveSuccessPct:null,pct,"%")}</strong></span><span><small>Guadagno</small><strong>${finished&&stats.archiveProfitPct>0?"+":""}${metric(finished?stats.archiveProfitPct:null,pct,"%")}</strong></span></span>`;
    const palette=["#123e85","#9b1c31","#0f766e","#7c3aed","#b45309","#0369a1"];
    const colors={[number]:palette[(number-1)%palette.length]};
    return `<a class="betting-archive-card team-directory-card team-flip-card" href="schedina.html?giornata=${number}" aria-label="Apri le schedine della ${ordinalWord(number)} giornata" style="--team-primary:${colors[number]};--team-secondary:#06152b"><span class="team-flip-inner"><span class="team-flip-face team-flip-front betting-archive-card-front"><span class="betting-archive-number">${number}</span></span><span class="team-flip-face team-flip-back betting-archive-card-back"><strong>${number}ª giornata</strong>${detail}</span></span></a>`;
  }

  function championsArchiveCard(data,number=1){
    const selections=(data.slips?data.slips.flatMap(slip=>slip.legs):data.fixtures.flatMap(fixture=>fixture.selections||[])).filter(leg=>number!==3||hasVerifiedPlayableQuote(leg));
    const stats=archiveStats({matchday:number,slips:[{legs:selections}]},null,leg=>leg.settlement||{status:"pending"});
    const verified=null; // Public economics always follow the visible filtered contracts.
    const wins=verified?verified.green:stats.archiveWins;
    const total=verified?verified.considered:stats.archiveStake;
    const decided=verified?verified.green+verified.red:stats.archiveStake;
    const success=decided?wins/decided*100:null;
    const profit=verified?verified.roiPct:total?stats.archiveProfitPct:null;
    const performance=`<span class="betting-archive-performance"><span><small>Successo</small><strong>${metric(success,pct,"%")}</strong></span><span><small>Guadagno</small><strong>${profit>0?"+":""}${metric(profit,pct,"%")}</strong></span></span>`;
    return `<a class="betting-archive-card betting-archive-card--champions team-directory-card team-flip-card" data-champions-matchday="${number}" href="schedina.html?competizione=champions&amp;giornata=${number}" aria-label="Apri le schedine Champions League della ${ordinalWord(number)} giornata" style="--team-primary:#0756c9;--team-secondary:#02183f"><span class="team-flip-inner"><span class="team-flip-face team-flip-front betting-archive-card-front betting-champions-front" style="color:#fff"><span class="betting-archive-number">CL${number}</span></span><span class="team-flip-face team-flip-back betting-archive-card-back"><strong>${number}ª giornata</strong>${performance}</span></span></a>`;
  }

  function championsSlipCard(slip){
    const cardHeuristic=slip.legs.some(leg=>leg.marketFamily==="Ammoniti"||leg.probabilitySemantics);
    const families=slip.marketFamilies.map(esc).join(" · ");
    const weak=slip.weakestLeg?`<p class="betting-weakest">Gamba più fragile: <strong>${esc(slip.weakestLeg.label)}</strong> · ${cardHeuristic?"EV euristico non validato":"EV"} ${slip.weakestLeg.expectedValuePct>0?"+":""}${pct(slip.weakestLeg.expectedValuePct)}%</p>`:"";
    return `<article class="betting-slip betting-slip--champions betting-slip--${esc(slip.id)}" data-quality="${esc(slip.qualityStatus)}"><header><div><p>${esc(slip.eyebrow)}</p><h2>${esc(slip.name)}</h2><small>${families}</small></div></header><div class="betting-slip-metrics"><div class="betting-slip-total"><span>Quota totale</span><strong>${metric(slip.combinedOdds,odds)}</strong><small>${slip.legs.length} giocate · solo riferimento</small></div><div><span>${cardHeuristic?"Indice euristico non calibrato":"Probabilità"}</span><strong>${metric(slip.jointModelProbabilityPct,pct,"%")}</strong></div><div><span>${cardHeuristic?"Quota derivata euristica":"Quota equa"}</span><strong>${metric(slip.fairOdds,odds)}</strong></div><div><span>${cardHeuristic?"EV euristico non validato":"EV stimato"}</span><strong>${metric(slip.expectedValuePct,pct,"%")}</strong></div></div><p class="betting-coverage">Esito schedina: ${slip.settlement?.status==="lost"?"Persa":slip.settlement?.status==="won"?"Vinta":"Da verificare"}</p><ol>${slip.legs.filter(meetsMinimumPublicOdds).map(leg=>`<li class="betting-leg--${esc(leg.settlement?.status||"pending")}" data-settlement="${esc(leg.settlement?.status||"pending")}"><div><strong>${esc(leg.fixture)}</strong><span>${esc(publicForecastLabel(leg))} <small>· ${esc(leg.evidenceLabel)}</small></span><span class="betting-leg-result" title="${esc(leg.settlement?.reason||"")}">${esc(leg.settlement?.label||"Da verificare")}</span></div><b>${odds(leg.odds)}</b></li>`).join("")}</ol>${weak}</article>`;
  }

  function championsContent(data){
    const legs=data.slips.flatMap(s=>s.legs).filter(meetsMinimumPublicOdds);
    data={...data,summary:{...data.summary,legs:legs.length,distinctFixtures:new Set(legs.map(l=>l.matchId)).size},settlementSummary:{
      won:legs.filter(l=>l.settlement?.status==='won').length,lost:legs.filter(l=>l.settlement?.status==='lost').length,
      pending:legs.filter(l=>!['won','lost','void'].includes(l.settlement?.status)).length}};
    return `<div class="betting-stage betting-champions-stage"><header class="betting-intro"><div><p class="eyebrow">Champions League · 1ª giornata</p><h3>${data.slips.length} schedine costruite dal modello</h3></div><p>Tiri, gol e assist, multigol, due poker ammoniti e tre schedine giornaliere. Quote e proiezioni originali archiviate.</p></header><p class="betting-coverage">${data.summary.legs} selezioni complessive su ${data.summary.distinctFixtures} gare. Quota minima per selezione: 1.10.</p><p class="betting-coverage">${data.settlementSummary?.won??0} vinte · ${data.settlementSummary?.lost??0} perse · ${data.settlementSummary?.pending??data.summary.legs} da verificare. ${esc(data.settlementNote||"")}</p><div class="betting-slip-grid">${data.slips.map(championsSlipCard).join("")}</div><footer class="betting-method"><strong>Criterio Champions</strong><p>${esc(data.selectionRule)}</p><p>${esc(data.methodology)}</p><p>Quote ${esc(data.provider)} aggiornate al ${esc(dateOnly(data.oddsRetrievedAt))}. Gioca responsabilmente.</p></footer></div>`;
  }

  function championsMd02Content(data){
    const selections=data.fixtures.flatMap(fixture=>fixture.selections||[]).filter(meetsMinimumPublicOdds);
    const stats=archiveStats({matchday:2,slips:[{legs:selections}]},null,leg=>leg.settlement||{status:"pending"});
    const losses=stats.archiveStake-stats.archiveWins;
    const economic=stats.archiveStake
      ?`${stats.archiveWins} esatti · ${losses} sbagliati${stats.archiveVoids?` · ${stats.archiveVoids} annullati`:""} · ${stats.archivePending} da verificare. Puntato ${odds(stats.archiveStake)} € · ritorno ${odds(stats.archiveGrossReturn)} € · netto ${stats.archiveNetProfit>0?"+":""}${odds(stats.archiveNetProfit)} € · ROI parziale ${stats.archiveProfitPct>0?"+":""}${pct(stats.archiveProfitPct)}%.`
      :`${stats.archivePending} pronostici da verificare. ROI e profitto/perdita restano N/D finché non sono disponibili esiti ufficiali.`;
    const panels=data.fixtures.map((fixture,index)=>{
      const legs=(fixture.selections||[]).filter(meetsMinimumPublicOdds);
      const marketList=legs.length?`<div class="betting-market-columns" aria-hidden="true"><span></span><span>Probabilità</span><span>Quota Sisal</span><span>EV</span><span></span></div><ol class="betting-market-list">${legs.map((leg,rowIndex)=>selectableMarketRow({leg,sourceSection:leg.marketScope==="player"?"champions-md02-individuale":"champions-md02-verdetto",showContractNote:false},rowIndex,leg.fixture,fixture)).join("")}</ol>`:`<p class="betting-market-empty">Il forecast esiste, ma non è stata trovata una quota Sisal esatta: nessuna selezione è stata forzata.</p>`;
      return `<details class="betting-match-panel" data-match-panel data-match-id="${esc(fixture.fixtureId)}"${index===0?" open":""}><summary><span><small>${esc(dateOnly(fixture.date))} · ${esc(fixture.kickoff||"Orario N/D")}</small><strong>${esc(fixture.homeTeam)} - ${esc(fixture.awayTeam)}</strong></span><span class="betting-match-count">${legs.length} ${legs.length===1?"pronostico selezionato":"pronostici selezionati"}</span><span class="betting-match-toggle" aria-hidden="true">＋</span></summary><div class="betting-match-body">${marketList}<a class="betting-match-reading-link" href="${esc(fixture.readingUrl)}">Apri la lettura della partita →</a></div></details>`;
    }).join("");
    return `<section class="betting-essential betting-champions-md02-summary" aria-labelledby="champions-md02-summary-title"><h3 id="champions-md02-summary-title">In sintesi</h3><p class="betting-coverage"><strong>${data.summary.fixtures} partite · ${data.summary.predictions} pronostici</strong> · ${data.isAuditArchive?"Archivio originale · sola consultazione":`${data.summary.clickableSelections} selezioni con quota Sisal valida`}.</p><p>${esc(data.selectionRule)}</p><p><strong>Rendimento parziale:</strong> ${esc(economic)} Grigi esclusi dai calcoli; 1 € per selezione verificata.</p>${data.filteredAuditSummary?`<p>Filtro titolari: ${data.filteredAuditSummary.won} vinte · ${data.filteredAuditSummary.lost} perse · ROI parziale ${pct(data.filteredAuditSummary.roiPct)}%. I 4 contratti esclusi restano visibili soltanto nell’archivio.</p>`:""}<div class="betting-result-legend" aria-label="Legenda esiti audit"><span class="betting-result-legend--won">Verde · vinto</span><span class="betting-result-legend--lost">Rosso · perso</span><span class="betting-result-legend--pending">Grigio · da verificare</span><span class="betting-result-legend--void">Neutro · annullato</span></div></section><section class="betting-matchday-shell betting-champions-md02-markets" aria-label="Pronostici Champions della seconda giornata"><header class="betting-matchday-heading"><div class="betting-matchday-actions"><button type="button" data-match-open-all>Apri tutte</button><button type="button" data-match-close-all>Chiudi tutte</button></div></header><div class="betting-match-list">${panels}</div><footer class="betting-method"><strong>Criterio Champions</strong><p>${esc(data.methodology)}</p><p>${esc(data.settlementPolicy)}</p></footer></section>`;
  }

  function championsGroupedRows(entries,fixture,match){
    if(compactForecasts)return visualOrder(entries,entry=>entry.leg).map((entry,index)=>entry.leg.catalogOrigin==='champions-md03-individual-model'?unquotedForecastRow(entry,index):selectableMarketRow(entry,index,fixture,match)).join('');
    const groups=new Map();
    entries.forEach(entry=>{const family=entry.leg.marketFamily||entry.leg.betSelection.market.family||"Altri mercati";if(!groups.has(family))groups.set(family,[]);groups.get(family).push(entry)});
    return [...groups].map(([family,rows])=>`<li class="betting-market-family-heading"><h4>${esc(family)}</h4></li>${rows.map((entry,index)=>entry.leg.catalogOrigin==='champions-md03-individual-model'?unquotedForecastRow(entry,index):selectableMarketRow(entry,index,fixture,match)).join("")}`).join("");
  }

  function prepareChampionsWorkspace(workspace){
    currentContext={competition:"champions",season:workspace.season,matchday:workspace.matchday,...(workspace.lineupManaged?{forecastPolicy:"SERIE_A_CURRENT"}:{}),label:`Champions League · ${workspace.matchday}ª giornata`};
    selectionRegistry.clear();slipRegistry.clear();
    workspace.all.filter(leg=>!leg.auditDisplayOnly&&(workspace.matchday!==3||leg.suggestionAnalysis?.suggested)).forEach(leg=>registerSelection(leg,{sourceSection:leg.approvedPreliminary?"singola-approvata":"catalogo-champions"}));
  }

  function championsWorkspaceMarkup(workspace,fixtureId=null){
    if(workspace.matchday===3||workspace.lineupManaged)compactForecasts=true;
    prepareChampionsWorkspace(workspace);
    const visible=workspace.fixtures.filter(f=>!fixtureId||f.id===fixtureId),matches=new Map(visible.map(f=>[f.id,f])),teams=new Map();
    const count=workspace.all.filter(leg=>leg.suggestionAnalysis?.suggested).length;
    // Both competitions use the same rows, match panels, combo renderer and personal controller.
    return `<section class="betting-round-page betting-round-page--workspace betting-round-page--champions" data-champions-workspace="${workspace.matchday}">${fixtureId&&workspace.matchday===3?'<header class="rd-section-heading"><span class="rd-section-number">03</span><h2>Pronostici e MyCombo</h2></header>':""}<header class="betting-round-heading"><p class="eyebrow">Champions League · ${esc(workspace.season)}</p><h2>${workspace.matchday}ª giornata${fixtureId?" · pronostici":""}</h2></header><div class="betting-workspace"><div class="betting-workspace-content">${matchdayWorkspaceContent(workspace,[],matches,teams,workspace.matchday)}</div><aside class="betting-personal-column" data-personal-host aria-label="Costruttore della schedina personale"></aside></div></section>`;
  }

  function mountChampionsWorkspace(workspace){
    if(!document.querySelector('[data-personal-host]'))return null;
    initializePersonalBetslip(currentContext);
    bindMatchdayInteractions(`champions-${workspace.matchday}`);
    bindMyComboInteractions(`champions-${workspace.matchday}`);
    return personalStore;
  }

  // Build-time presentation only: reuse the original card renderer and settlement.
  async function buildArchiveMarkup(){
    compactForecasts=true;
    recordedOutcomes=(await load("card-settlement-records.json")).records;
    const [champions,championsMd02Operational,md1,md2,md3,md4,md5,md6,md7,md8,md9,md10,md11,matches,audit]=await Promise.all([load("schedina-champions-md01.json"),load("schedina-champions-md02.json"),load("schedina.json"),load("schedina-md02.json"),load("schedina-md03.json"),load("schedina-md04.json"),load("schedina-md05.json"),load("schedina-md06.json"),load("schedina-md07.json"),load("schedina-md08.json"),load("schedina-md09.json"),load("schedina-md10.json"),load("schedina-md11.json"),load("matches.json"),load("champions-md02-audit-display.json")]);
    const championsMd02=championsAuditDisplay(championsMd02Operational,audit);
    const matchById=new Map((Array.isArray(matches)?matches:matches.matches||[]).map(match=>[match.id,match]));
    const {settleMd3}=await import("./champions-md3-approved.mjs?v=20261022-assets-v1");
    const md3Workspace=await loadChampionsWorkspaceMd3Derived(load,3);
    const championsMd03={...settleMd3({...md3Workspace.source,slips:[{legs:md3Workspace.all.filter(leg=>leg.suggestionAnalysis.suggested).map(leg=>({...leg,fixtureId:leg.matchId}))}]},{fixtures:md3Workspace.fixtures}),availableForecasts:md3Workspace.all.filter(leg=>leg.suggestionAnalysis.suggested).length};
    const championsCalendar=await load('champions-league-2026-27.json');
    const firstDate=fixtures=>fixtures.map(f=>f.date).filter(Boolean).sort()[0]||'';
    const cards=[md1,md2,md3,md4,md5,md6,md7,md8,md9,md10,md11].map((data,index)=>{
      const number=index+1;
      return {date:firstDate([...matchById.values()].filter(m=>m.matchday===number)),html:archiveCard(data,number,matchById)};
    });
    const md4Workspace=await loadChampionsWorkspaceMd3Derived(load,4);
    const championsMd04={...md4Workspace.source,slips:[{legs:md4Workspace.all.filter(leg=>leg.suggestionAnalysis?.suggested)}]};
    for(const [index,data] of [champions,championsMd02,championsMd03,championsMd04].entries()){
      const number=index+1;
      cards.push({date:firstDate(championsCalendar.fixtures.filter(f=>f.matchday===number)),html:championsArchiveCard(data,number)});
    }
    cards.sort((a,b)=>b.date.localeCompare(a.date));
    return hero("","Schedina","Le schedine e le MyCombo sono raccolte separatamente giornata per giornata.")+`<section class="betting-archive" aria-label="Giornate Schedina"><div class="betting-archive-list team-directory-grid team-flip-grid">${cards.map(card=>card.html).join("")}</div></section>`;
  }

  async function render(){
    compactForecasts=true;
    selectionRegistry.clear();slipRegistry.clear();currentContext=null;personalNotice="";
    deps.beginView?.();
    const params=new URLSearchParams(location.search);
    const matchday=params.get("giornata"),competition=params.get("competizione");
    if(competition==="champions"){
      const number=Number(matchday||1);
      if(![1,2,3,4].includes(number))throw new Error("Giornata Champions non disponibile");
      const [workspace,outcomes]=await Promise.all([number===3?load("schedina-champions-md03-ui.json").then(async data=>(await import('./champions-md3-browser-workspace.mjs?v=20261022-assets-v1')).restoreMd3Workspace(data)):loadChampionsWorkspaceMd3Derived(load,number),load("card-settlement-records.json")]);
      recordedOutcomes=outcomes.records;
      document.querySelector("#app").innerHTML=hero(`UEFA Champions League · ${number}ª giornata`,"Schedine",number>=3?"Pronostici preliminari per le partite con entrambi gli undici probabili. Formazioni e panchine restano da confermare.":"Pronostici e risultati originali archiviati, in sola consultazione.")+`<nav class="betting-round-back"><a href="schedina.html">← Tutte le giornate</a><a href="champions-league.html">Letture Champions →</a></nav>`+championsWorkspaceMarkup(workspace);
      mountChampionsWorkspace(workspace);
      return;
    }
    if(["1","2","3","4","5","6","7","8","9","10","11"].includes(matchday)){
      const number=Number(matchday),file=number===1?"schedina.json":`schedina-md${String(number).padStart(2,"0")}.json`;
      const [data,matches,outcomes]=await Promise.all([load(file),load("matches.json"),load("card-settlement-records.json")]);
      recordedOutcomes=outcomes.records;
      const matchById=new Map((Array.isArray(matches)?matches:matches.matches||[]).map(match=>[match.id,match]));
      const needsPredictions=number===5||(number>=6&&[...matchById.values()].filter(m=>m.id.endsWith(`-md-${String(number).padStart(2,"0")}`)).some(m=>!data.marketCatalog?.matches?.find(c=>c.matchId===m.id)?.selections?.length));
      const [teams,predictionData]=await Promise.all([number>=5?load("teams.json"):Promise.resolve([]),needsPredictions?load(`predictions-md${String(number).padStart(2,"0")}.json`):Promise.resolve({predictions:[]})]);
      const teamById=new Map((Array.isArray(teams)?teams:teams.teams||[]).map(team=>[team.id,team]));
      const ordinal=`${number}ª`;
      if(number>=6)currentContext={competition:"serie-a",season:"2026-27",matchday:number,label:`Serie A · ${ordinal} giornata`};
      const description=number>=6?"Mercato, esito, probabilità, quota Sisal ed EV dei pronostici selezionati.":`Tutte le schedine della ${ordinalWord(number)} giornata, con quote, probabilità, quota equa ed EV consultabili.`;
      const myCombo=number===5?myComboRoundContent(predictionData.predictions||[],matchById,teamById,number):"";
      if(number>=6){
        const matchdayContent=matchdayWorkspaceContent(data,predictionData.predictions||[],matchById,teamById,number);
        document.querySelector("#app").innerHTML=hero(`Serie A · ${ordinal} giornata`,"Schedine",description)+`<nav class="betting-round-back" aria-label="Navigazione archivio schedine"><a href="schedina.html">← Tutte le giornate</a></nav><section class="betting-round-page betting-round-page--workspace" aria-labelledby="betting-round-${String(number).padStart(2,"0")}-title"><header class="betting-round-heading"><p class="eyebrow">Serie A · 2026/27</p><h2 id="betting-round-${String(number).padStart(2,"0")}-title">${ordinal} giornata</h2></header><div class="betting-workspace"><div class="betting-workspace-content">${matchdayContent}</div><aside class="betting-personal-column" data-personal-host aria-label="Costruttore della schedina personale"></aside></div></section>`;
      }else{
        document.querySelector("#app").innerHTML=hero(`Archivio · ${ordinal} giornata`,"Schedine",description)+`<nav class="betting-round-back" aria-label="Navigazione archivio schedine"><a href="schedina.html">← Tutte le giornate</a></nav><section class="betting-round-page" aria-labelledby="betting-round-${String(number).padStart(2,"0")}-title"><header class="betting-round-heading"><p class="eyebrow">Serie A · 2026/27</p><h2 id="betting-round-${String(number).padStart(2,"0")}-title">${ordinal} giornata</h2></header>${myCombo}${archiveRoundContent(data,matchById,{showLegend:number===1})}</section>`;
      }
      if(currentContext)initializePersonalBetslip(currentContext);
      if(number===5)bindMyComboInteractions(number);
      if(number>=6)bindMatchdayInteractions(number);
      return;
    }
    document.querySelector("#app").innerHTML=(await loadGenerated("schedina-index-2026-27.json?presentation=20261109-md11-results")).html;
    // First touch reveals the existing reverse face; second touch follows its link.
    const cl3Card=document.querySelector('[data-champions-matchday="3"]');
    cl3Card?.addEventListener('click',event=>{
      if(matchMedia('(min-width:761px) and (hover:none)').matches&&!cl3Card.hasAttribute('data-touch-revealed')){
        event.preventDefault();cl3Card.setAttribute('data-touch-revealed','');
        cl3Card.querySelector('.team-flip-inner').style.setProperty('transform','rotateY(180deg)','important');
      }
    });

  }
  return {render,championsWorkspaceMarkup,mountChampionsWorkspace,buildArchiveMarkup};
}
