"use strict";

const fs = require("fs");
const path = require("path");
const { isSisalMyComboMarketName } = require("./mycombo-market-policy");
const { isPlayableSelection } = require("./betting-market-policy");

const root = path.resolve(__dirname, "..");
const index = process.argv.indexOf("--matchday");
const matchday = index >= 0 ? Number(process.argv[index + 1]) : 1;
if (!Number.isInteger(matchday) || matchday < 1 || matchday > 38) throw new Error("--matchday deve essere compreso tra 1 e 38.");
const requestedMatchIndex = process.argv.indexOf("--match");
const requestedMatchId = requestedMatchIndex >= 0 ? process.argv[requestedMatchIndex + 1] : null;
if (requestedMatchIndex >= 0 && !requestedMatchId) throw new Error("--match richiede un matchId.");

const filename = `mycombo-serie-a-2026-27-md-${String(matchday).padStart(2, "0")}.json`;
const sourcePath = path.join(root, "data/sources", filename);
const predictionsPath = path.join(root, "data/normalized/predictions.json");
if (!fs.existsSync(sourcePath)) throw new Error(`Fonte MyCombo assente: ${filename}`);

const source = JSON.parse(fs.readFileSync(sourcePath, "utf8"));
const predictions = JSON.parse(fs.readFileSync(predictionsPath, "utf8")).predictions;
const predictionByMatch = new Map(predictions.map(prediction => [prediction.matchId, prediction]));
const matches = JSON.parse(fs.readFileSync(path.join(root, "data/normalized/matches.json"), "utf8"));
const matchById = new Map(matches.map(match => [match.id, match]));
const clean = value => String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
const excludedMarketKeys = new Set((source.constraints?.excludedMarketNames || []).map(clean));
const excludedMarketFragments = (source.constraints?.excludedMarketNameFragments || []).map(clean);
const isExcludedMarket = leg => {
  const key = clean(String(leg?.overlapKey || "").replace(/^market-/, ""));
  return excludedMarketKeys.has(key) || excludedMarketFragments.some(fragment => key.includes(fragment));
};
let valid = 0;
let unavailable = 0;

for (const [matchId, portfolios] of Object.entries(source.matches || {})) {
  if (requestedMatchId && matchId !== requestedMatchId) continue;
  if (matchById.get(matchId)?.status === "finished") continue;
  const prediction = predictionByMatch.get(matchId);
  if (!prediction) throw new Error(`Pronostico non trovato: ${matchId}`);
  for (const portfolio of portfolios) {
    const limits = source.constraints?.tierLimits?.[portfolio.tier];
    if (!limits) throw new Error(`Intervallo gambe mancante: ${matchId}/${portfolio.tier}`);
    const combo = prediction.combinations?.find(item => item.tier === portfolio.tier);
    if (portfolio.status === "N/D") {
      if (portfolio.legs?.length || !portfolio.reason) throw new Error(`${matchId}/${portfolio.tier}: profilo N/D non valido`);
      if (!combo || combo.qualityStatus !== "nd" || combo.legs?.length || !combo.unavailableReason) throw new Error(`${matchId}/${portfolio.tier}: N/D non propagato nel pronostico`);
      unavailable += 1;
      continue;
    }
    if (!portfolio.legs?.length || portfolio.legs.length < limits.minimum || portfolio.legs.length > limits.maximum) {
      throw new Error(`${matchId}/${portfolio.tier}: ${portfolio.legs?.length || 0} gambe fuori dall'intervallo ${limits.minimum}-${limits.maximum}`);
    }
    if (!combo?.legs?.length || combo.qualityStatus === "nd") throw new Error(`${matchId}/${portfolio.tier}: portafoglio non disponibile nel pronostico rigenerato`);
    if (matchday >= 6 && (portfolio.legs.some(leg => !isPlayableSelection(leg, { matchday })) || combo.legs.some(leg => !isPlayableSelection(leg, { matchday })))) throw new Error(`${matchId}/${portfolio.tier}: selezione vietata dalla policy giocabile MD6+`);
    if (portfolio.legs.some(isExcludedMarket) || combo.legs.some(isExcludedMarket)) throw new Error(`${matchId}/${portfolio.tier}: mercato vietato presente nella MyCombo aperta`);
    if (combo.legs.some(leg => !isSisalMyComboMarketName(leg.market))) throw new Error(`${matchId}/${portfolio.tier}: mercato fuori dalla whitelist MyCombo Sisal`);
    const minimumOdds = source.constraints.minLegOddsInclusive;
    const maximumOdds = source.constraints.maxLegOddsInclusive;
    if (combo.legs.some(leg => leg.odds < minimumOdds || leg.odds > maximumOdds)) throw new Error(`${matchId}/${portfolio.tier}: quota singola fuori dal range ${minimumOdds}-${maximumOdds}`);
    if (new Set(combo.legs.map(leg => leg.overlapKey)).size !== combo.legs.length) throw new Error(`${matchId}/${portfolio.tier}: famiglia di mercato ripetuta`);
    const semanticKeys = combo.legs.flatMap(leg => leg.semanticKeys || []);
    if (new Set(semanticKeys).size !== semanticKeys.length) throw new Error(`${matchId}/${portfolio.tier}: scenario di base ripetuto o annidato`);
    valid += 1;
  }
}

if (requestedMatchId && !Object.hasOwn(source.matches || {}, requestedMatchId)) throw new Error(`MyCombo non trovata: ${requestedMatchId}`);
console.log(`OK MyCombo giornata ${matchday}${requestedMatchId ? ` · ${requestedMatchId}` : ""}: ${valid} portafogli validati · ${unavailable} N/D motivati`);
