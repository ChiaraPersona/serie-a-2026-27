"use strict";

const finite = value => value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value));
const clean = value => String(value || "")
  .replace(/[Øø]/g, "o")
  .replace(/[Łł]/g, "l")
  .replace(/[Đð]/g, "d")
  .replace(/[Þþ]/g, "th")
  .replace(/ß/g, "ss")
  .replace(/[Ææ]/g, "ae")
  .replace(/[Œœ]/g, "oe")
  .normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
const round = (value, digits = 2) => Number(Number(value).toFixed(digits));
const stabilityRank = value => ({ low: 1, medium: 2, high: 3 }[String(value || "").toLowerCase()] || 0);
const reliabilityLabel = value => ({ high: "Alta", medium: "Media", low: "Bassa" }[String(value || "").toLowerCase()] || "Non valutabile");
const playerKey = player => String(player?.playerId || player?.name || "");

function chooseShotsThreshold(player) {
  const probabilities = player?.shotProbabilities || {};
  if (finite(probabilities.over25) && Number(probabilities.over25) >= 0.4) return { count: 3, probability: Number(probabilities.over25), probabilityKey: "over25" };
  if (finite(probabilities.over15) && Number(probabilities.over15) >= 0.42) return { count: 2, probability: Number(probabilities.over15), probabilityKey: "over15" };
  if (finite(probabilities.over05) && Number(probabilities.over05) >= 0.58) return { count: 1, probability: Number(probabilities.over05), probabilityKey: "over05" };
  return null;
}

function chooseSotThreshold(player) {
  const probabilities = player?.shotOnTargetProbabilities || {};
  if (finite(probabilities.over15) && Number(probabilities.over15) >= 0.28) return { count: 2, probability: Number(probabilities.over15), probabilityKey: "over15" };
  if (finite(probabilities.over05) && Number(probabilities.over05) >= 0.4) return { count: 1, probability: Number(probabilities.over05), probabilityKey: "over05" };
  return null;
}

function candidatePool(shooters) {
  const allPlayers = new Map((shooters?.allPlayers || []).map(player => [playerKey(player), player]));
  const sources = new Map();
  const add = (label, players) => {
    for (const row of players || []) {
      const key = playerKey(row);
      if (!key) continue;
      const current = sources.get(key) || new Set();
      current.add(label);
      sources.set(key, current);
      if (!allPlayers.has(key)) allPlayers.set(key, row);
    }
  };
  add("primary-shots", shooters?.totalShots);
  add("primary-sot", shooters?.shotsOnTarget);
  add("qualified-shots-outsider", (shooters?.outsiders || []).filter(player => player.qualifiedOutsider === true));
  add("qualified-sot-outsider", (shooters?.sotOutsiders || []).filter(player => player.qualifiedSotOutsider === true));
  return [...sources].map(([key, labels]) => ({ player: allPlayers.get(key), sources: [...labels] }));
}

function lineupEligibility(player, matchId, probableLineups, officialLineups) {
  const official = (officialLineups?.fixtures || []).find(fixture => fixture.matchId === matchId);
  if (official) {
    const starter = official.teams.flatMap(team => team.players || []).find(row => row.playerId === player.playerId);
    return { eligible: Boolean(starter), status: starter ? "official-starter" : "official-nonstarter", source: official.provider || officialLineups.provider || "official", sourceUpdatedAt: official.retrievedAt || officialLineups.retrievedAt || null, playerId: player.playerId, playerName: player.name };
  }
  const probable = (probableLineups?.teams || []).flatMap(team => team.players || []).find(row => row.playerId === player.playerId);
  return {
    eligible: probable?.lineupStatus === "starter",
    status: probable?.lineupStatus === "starter" ? "probable-starter" : probable?.lineupStatus === "reserve" ? "reserve" : "unknown",
    source: probableLineups?.provider || null,
    sourceUpdatedAt: probableLineups?.importedAt || null,
    playerId: player.playerId,
    playerName: player.name,
  };
}

function evaluateCandidate(player, metric, sources, lineup) {
  const expectedMinutes = finite(player?.expectedMinutes) ? Number(player.expectedMinutes) : null;
  const isPrimary = sources.includes(metric === "shots" ? "primary-shots" : "primary-sot");
  const isOutsider = sources.includes(metric === "shots" ? "qualified-shots-outsider" : "qualified-sot-outsider");
  const threshold = metric === "shots" ? chooseShotsThreshold(player) : chooseSotThreshold(player);
  const reasons = [];
  if (!player?.playerId) reasons.push("PLAYER_ID_MISSING");
  if (!lineup.eligible) reasons.push(`LINEUP_${String(lineup.status).toUpperCase().replace(/-/g, "_")}`);
  if (!threshold) reasons.push("MODEL_THRESHOLD_NOT_SUPPORTED");
  if (metric === "shots") {
    const outsiderStrong = isOutsider
      && expectedMinutes >= 70
      && Number(player?.shotProbabilities?.over05) >= 0.55
      && (player.outsiderConfidence === "high" || Number(player.outsiderScore) >= 52);
    const primaryStrong = isPrimary
      && expectedMinutes >= 55
      && (stabilityRank(player?.playerBaselineStability?.level) >= 2 || Number(player?.projectedShots) >= 2);
    if (!primaryStrong && !outsiderStrong) reasons.push("READING_SUPPORT_BELOW_SHOTS_STANDARD");
  } else {
    const outsiderStrong = isOutsider
      && expectedMinutes >= 70
      && Number(player?.shotOnTargetProbabilities?.over05) >= 0.3
      && (player.sotOutsiderConfidence === "high" || Number(player.sotOutsiderScore) >= 44);
    const primaryStrong = isPrimary
      && expectedMinutes >= 60
      && (stabilityRank(player?.playerSotBaselineStability?.level) >= 2 || Number(player?.shotOnTargetProbabilities?.over05) >= 0.55)
      && (Number(player?.shotOnTargetProbabilities?.over15) >= 0.28 || Number(player?.shotOnTargetProbabilities?.over05) >= 0.4);
    if (!primaryStrong && !outsiderStrong) reasons.push("READING_SUPPORT_BELOW_SOT_STANDARD");
  }
  return { eligible: reasons.length === 0, reasons, threshold, expectedMinutes, isPrimary, isOutsider };
}

function providerSubject(market) {
  return clean(String(market?.variantName || "").split(/\s+U\/O\s+/i)[0]);
}

function marketUniquelyMatchesPlayer(market, player, matchPlayers) {
  const subjectTokens = providerSubject(market).split(" ").filter(Boolean);
  const candidates = (matchPlayers || []).filter(candidate => {
    const nameTokens = clean(candidate?.name).split(" ").filter(Boolean);
    const surname = nameTokens.at(-1);
    return surname?.length > 1 && subjectTokens.includes(surname);
  });
  if (candidates.length === 1) return candidates[0].playerId === player.playerId;
  const exactCandidates = candidates.filter(candidate => {
    const nameTokens = clean(candidate?.name).split(" ").filter(Boolean);
    const givenTokens = nameTokens.slice(0, -1).filter(token => token.length > 1);
    return givenTokens.some(token => subjectTokens.includes(token))
      || (givenTokens[0] && subjectTokens.some(token => token.length === 1 && givenTokens[0].startsWith(token)));
  });
  return exactCandidates.length === 1 && exactCandidates[0].playerId === player.playerId;
}

function buildProviderPlayerMap(predictions, odds) {
  const eventByMatch = new Map((odds?.events || []).map(event => [event.canonicalMatchId, event]));
  const map = new Map();
  for (const prediction of predictions || []) {
    const event = eventByMatch.get(prediction.matchId);
    const marketById = new Map((event?.markets || []).map(market => [String(market.providerMarketId), market]));
    const matchPlayers = prediction.shooters?.allPlayers || [];
    for (const player of prediction.shooters?.allPlayers || []) for (const quote of Object.values(player.markets || {}).filter(Boolean)) {
      const market = marketById.get(String(quote.providerMarketId));
      if (!market || !marketUniquelyMatchesPlayer(market, player, matchPlayers)) continue;
      for (const providerPlayerId of market?.providerPlayerIds || []) {
        const key = `${prediction.matchId}:${providerPlayerId}`;
        const previous = map.get(key);
        if (!previous) map.set(key, { playerId: player.playerId, playerName: player.name, teamId: player.teamId });
        else if (previous.playerId !== player.playerId) map.set(key, null);
      }
    }
  }
  return map;
}

function isCompatibleIndividualMarket(market, metric) {
  const descriptor = `${market?.marketName || ""} ${market?.variantName || ""}`.toUpperCase();
  if (market?.marketScope !== "player") return false;
  if (/DUO|SOST(?:ITUT)?|ENTRAMBI I TEMPI|NEI 2 TEMPI|PALI|TRAVERSE/.test(descriptor)) return false;
  return metric === "shots"
    ? /TIRI TOTALI/.test(descriptor) && !/TIRI IN PORTA/.test(descriptor)
    : /TIRI IN PORTA/.test(descriptor);
}

function isSupportedDuoMarket(market, metric) {
  const descriptor = `${market?.marketName || ""} ${market?.variantName || ""}`.toUpperCase();
  if (market?.marketScope !== "player" || /ENTRAMBI I TEMPI|NEI 2 TEMPI/.test(descriptor)) return false;
  if (metric === "shots") return String(market?.marketCode) === "28507"
    && /TIRI TOTALI/.test(descriptor) && !/TIRI IN PORTA/.test(descriptor)
    && /DUO|SOST|INC TS/.test(descriptor);
  return String(market?.marketCode) === "28506"
    && /TIRI IN PORTA/.test(descriptor) && /DUO|SOST|INC TS/.test(descriptor)
    ;
}

function compatibleQuote({ odds, prediction, player, metric, threshold, providerPlayerMap }) {
  const event = (odds?.events || []).find(row => row.canonicalMatchId === prediction.matchId);
  if (!event) return null;
  const bookmakerThreshold = threshold.count - 0.5;
  const candidates = [];
  for (const market of event.markets || []) {
    if (!isSupportedDuoMarket(market, metric) || Number(market.threshold) !== bookmakerThreshold || market.status !== "open") continue;
    if ((market.providerPlayerIds || []).length !== 1) continue;
    const identities = [...new Set((market.providerPlayerIds || []).map(id => providerPlayerMap.get(`${prediction.matchId}:${id}`)?.playerId).filter(Boolean))];
    if (identities.length !== 1 || identities[0] !== player.playerId) continue;
    for (const selection of market.selections || []) {
      if (!/^(OVER|SI)$/.test(String(selection.name || "").toUpperCase()) || selection.status !== "open" || !finite(selection.odds) || Number(selection.odds) < 1) continue;
      candidates.push({ event, market, selection });
    }
  }
  return candidates.length === 1 ? candidates[0] : null;
}

function playerForecastLeg({ prediction, player, metric, threshold, lineup, quoteRow, odds, sources, fixture }) {
  const probabilityPct = round(threshold.probability * 100, 2);
  const quoted = Boolean(quoteRow);
  const quote = quoted ? Number(quoteRow.selection.odds) : null;
  const marketFamily = metric === "shots" ? "Tiri totali DUO" : "Tiri in porta DUO";
  const duoDescription = metric === "shots"
    ? `${player.name} e suo eventuale sostituto ${threshold.count}+ tiri`
    : `${player.name} e suo eventuale sostituto ${threshold.count}+ tiri in porta (pali e traverse inclusi)`;
  const selectionId = `forecast:v2:${prediction.matchId}:${player.playerId}:${metric}:${threshold.count}`;
  const reliabilitySource = metric === "shots" ? player.playerBaselineStability : player.playerSotBaselineStability;
  const providerMarketId = quoted ? String(quoteRow.market.providerMarketId) : null;
  const providerSelectionId = quoted ? String(quoteRow.selection.providerSelectionId) : null;
  const quoteSource = quoted ? {
    provider: odds.provider,
    url: odds.sourceUrl,
    snapshotPath: odds.normalizedPath || "data/normalized/odds/sisal/serie-a.json",
    rawFile: quoteRow.event.rawFile || odds.rawFile,
    acquisition: odds.acquisition,
  } : null;
  return {
    matchId: prediction.matchId,
    fixture,
    startsAt: quoteRow?.event?.startsAt || null,
    market: metric === "shots" ? "TIRI TOTALI GIOCATORE (DUO)" : "TIRI IN PORTA GIOCATORE (DUO, PALI/TRAVERSE INCLUSI)",
    variant: duoDescription,
    marketScope: "player",
    marketFamily,
    threshold: threshold.count - 0.5,
    selection: "OVER",
    label: duoDescription,
    odds: quote,
    modelProbabilityPct: null,
    individualModelProbabilityPct: probabilityPct,
    fairOdds: null,
    expectedValuePct: null,
    evidenceLabel: `${prediction.engineName || 'Prediction Engine V2'} ${prediction.engineVersion || "N/D"} sul singolo · contratto Sisal DUO`,
    providerMarketId,
    providerSelectionId,
    marketUpdatedAt: quoteRow?.market?.updatedAt || null,
    compatibility: quoted ? "BOOKMAKER_CONTRACT_VERIFIED_MODEL_PROBABILITY_UNAVAILABLE" : "QUOTA_NON_DISPONIBILE",
    evStatus: "DUO_PROBABILITY_NOT_VALIDATED",
    overlapKey: `player-forecast:${prediction.matchId}:${player.playerId}:${metric}`,
    semanticKeys: [`prediction-v2-player:${prediction.matchId}:${player.playerId}:${metric}`],
    selectionId,
    playerId: player.playerId,
    playerName: player.name,
    teamId: player.teamId,
    lineupEligibility: lineup,
    catalogOrigin: "prediction-v2-player-forecast",
    betSelection: {
      schemaVersion: 1,
      selectionId,
      identity: {
        status: quoted ? "VERIFIED_PROVIDER_IDS" : "NO_COMPATIBLE_PROVIDER_CONTRACT",
        matchId: prediction.matchId,
        provider: quoted ? odds.provider : null,
        providerMarketId,
        providerSelectionId,
      },
      market: {
        name: metric === "shots" ? "TIRI TOTALI GIOCATORE (DUO)" : "TIRI IN PORTA GIOCATORE (DUO, PALI/TRAVERSE INCLUSI)",
        variant: duoDescription,
        scope: "player",
        family: marketFamily,
        threshold: threshold.count - 0.5,
        selection: "OVER",
        subject: { type: "named-player-with-substitute", id: player.playerId, name: player.name, teamId: player.teamId },
        bookmakerSemantics: quoted ? {
          marketName: quoteRow.market.marketName,
          variantName: quoteRow.market.variantName,
          selectionName: quoteRow.selection.name,
          marketCode: String(quoteRow.market.marketCode),
          providerPlayerId: String(quoteRow.market.providerPlayerIds[0]),
          duo: true,
          substituteIncluded: true,
          postsAndCrossbarIncluded: metric === "sot" && /PALI/.test(`${quoteRow.market.marketName} ${quoteRow.market.variantName}`) && /TRAVERSE/.test(`${quoteRow.market.marketName} ${quoteRow.market.variantName}`),
          extraTimeIncluded: false,
          subjectType: "named-player-and-substitute",
        } : null,
      },
      quote: {
        decimal: quote,
        verifiedAt: quoted ? (quoteRow.event.retrievedAt || odds.retrievedAt) : null,
        marketUpdatedAt: quoteRow?.market?.updatedAt || null,
        availability: quoted ? "AVAILABLE_AT_SNAPSHOT" : "UNAVAILABLE",
        providerStatus: quoted ? quoteRow.selection.status : null,
        source: quoteSource,
      },
      operational: {
        classification: sources.some(source => source.includes("outsider")) ? "OUTSIDER" : "INTERESSANTE",
        classificationReason: "Profilo presente nella lettura V2; giocabilità fondata sul contratto Sisal DUO verificato, non su un EV DUO.",
        reliability: { level: reliabilityLabel(reliabilitySource?.level), reason: reliabilitySource?.evidence?.join("; ") || "Stabilità V2 non disponibile." },
        playability: quoted ? { status: "PLAYABLE", code: null, reason: null } : { status: "NOT_PLAYABLE", code: "QUOTE_UNAVAILABLE", reason: "Nessun contratto Sisal DUO riconciliato nello snapshot." },
      },
      evaluation: {
        modelProbabilityPct: null,
        fairOdds: null,
        expectedValuePct: null,
        status: "DUO_PROBABILITY_UNAVAILABLE",
        kind: "SISAL_DUO_PLAYER_THRESHOLD",
        prudentProbabilityPct: null,
        conservativeExpectedValuePct: null,
        probabilitySemantics: "DUO_CONTRACT_UNAVAILABLE",
        fairOddsBasis: null,
        expectedValueBasis: null,
        individualReference: {
          modelProbabilityPct: probabilityPct,
          probabilitySemantics: "INDIVIDUAL_PLAYER_V2",
          modelTarget: `player:${player.playerId}:${metric}:${threshold.count}+`,
          appliedToDuo: false,
        },
        provenance: {
          source: `predictions.shooters.allPlayers.${metric === "shots" ? "shotProbabilities" : "shotOnTargetProbabilities"}.${threshold.probabilityKey}`,
          modelVersion: prediction.engineVersion || null,
          playerMarketModelVersion: prediction.playerMarketModelVersion || null,
          predictionGeneratedAt: prediction.generatedAt || null,
          modelTarget: `player:${player.playerId}:${metric}:${threshold.count}+`,
        },
      },
      compatibility: {
        status: quoted ? "BOOKMAKER_CONTRACT_VERIFIED_MODEL_PROBABILITY_UNAVAILABLE" : "NO_COMPATIBLE_QUOTE",
        reason: quoted ? "Contratto Sisal DUO riconciliato per partita, provider player ID, codice mercato e soglia; la probabilità V2 individuale non è applicata al DUO." : "Nessun contratto Sisal DUO riconciliato per partita, provider player ID, codice mercato e soglia.",
        modelTarget: `player:${player.playerId}:${metric}:${threshold.count}+`,
        bookmakerTarget: quoted ? `${quoteRow.market.marketName} · ${quoteRow.market.variantName}` : null,
      },
      overlap: { overlapKey: `player-forecast:${prediction.matchId}:${player.playerId}:${metric}`, semanticKeys: [`prediction-v2-player:${prediction.matchId}:${player.playerId}:${metric}`] },
      warnings: quoted ? ["DUO_PROBABILITY_NOT_VALIDATED", "INDIVIDUAL_V2_NOT_APPLIED_TO_DUO"] : ["QUOTE_UNAVAILABLE", "DUO_PROBABILITY_NOT_VALIDATED"],
      risks: [],
    },
    forecastEvidence: {
      sources,
      role: player.role || null,
      detailedRole: player.detailedRole || null,
      expectedMinutes: finite(player.expectedMinutes) ? Number(player.expectedMinutes) : null,
      projectedShots: finite(player.projectedShots) ? Number(player.projectedShots) : null,
      projectedShotsOnTarget: finite(player.projectedShotsOnTarget) ? Number(player.projectedShotsOnTarget) : null,
      stability: reliabilitySource?.level || null,
      matchupEvidence: player.matchupEvidence || [],
      outsiderScore: metric === "shots" ? player.outsiderScore : player.sotOutsiderScore,
      outsiderConfidence: metric === "shots" ? player.outsiderConfidence : player.sotOutsiderConfidence,
      individualModelProbabilityPct: probabilityPct,
      individualModelTarget: `player:${player.playerId}:${metric}:${threshold.count}+`,
      appliedToDuo: false,
    },
    suggestionAnalysis: {
      version: 3,
      suggested: quoted,
      rank: null,
      family: metric,
      familyLabel: metric === "shots" ? "Tiri totali" : "Tiri in porta",
      criteria: "APPROVED_BASELINE_PLUS_STRUCTURED_READING_V2_NO_EV_GATE",
      reasons: quoted ? [] : ["QUOTE_UNAVAILABLE"],
      conservativeExpectedValuePct: null,
      canonicalThresholdIdentity: `${metric}:player:${player.playerId}:over`,
      resultThesisIdentity: null,
      rankingMode: "reading-v2-structured",
      rankingTuple: null,
      heuristicDisclosure: "Soglia letta dalla previsione individuale V2; quota riferita al contratto Sisal DUO. Probabilità DUO ed EV non disponibili.",
      quoteAvailability: quoted ? "AVAILABLE_AT_SNAPSHOT" : "UNAVAILABLE",
      baselineApproved: false,
    },
  };
}

function applyApprovedBaseline(catalogMatches, approvedSuggestionRankById) {
  if (approvedSuggestionRankById === null || approvedSuggestionRankById === undefined) return catalogMatches;
  const approved = approvedSuggestionRankById instanceof Map ? approvedSuggestionRankById : new Map(Object.entries(approvedSuggestionRankById || {}));
  return catalogMatches.map(match => {
    const selected = match.selections.filter(leg => approved.has(leg.selectionId)).sort((left, right) => Number(approved.get(left.selectionId)) - Number(approved.get(right.selectionId)) || String(left.selectionId).localeCompare(String(right.selectionId)));
    const rank = new Map(selected.map((leg, index) => [leg.selectionId, index + 1]));
    const selections = match.selections.map(leg => ({
      ...leg,
      suggestionAnalysis: {
        ...leg.suggestionAnalysis,
        suggested: rank.has(leg.selectionId),
        rank: rank.get(leg.selectionId) || null,
        baselineApproved: rank.has(leg.selectionId),
        reasons: rank.has(leg.selectionId) ? [] : leg.suggestionAnalysis?.reasons || ["NOT_IN_APPROVED_BASELINE"],
      },
    }));
    return { ...match, selections, suggestions: selected.map(leg => leg.selectionId), suggestionSummary: { ...match.suggestionSummary, total: selected.length } };
  });
}

function integratePlayerForecasts({ catalogMatches, predictions, odds, probableLineups, officialLineups, approvedSuggestionRankById, verifiedProviderPlayerMap = null }) {
  const baselineMatches = applyApprovedBaseline(catalogMatches, approvedSuggestionRankById);
  const providerPlayerMap = verifiedProviderPlayerMap || buildProviderPlayerMap(predictions, odds);
  const predictionByMatch = new Map((predictions || []).map(prediction => [prediction.matchId, prediction]));
  const excluded = [];
  const added = [];
  const matches = baselineMatches.map(match => {
    const prediction = predictionByMatch.get(match.matchId);
    if (!prediction?.shooters) return match;
    const fixture = match.selections[0]?.fixture || `${match.homeTeam} – ${match.awayTeam}`;
    const additions = [];
    for (const { player, sources } of candidatePool(prediction.shooters)) for (const metric of ["shots", "sot"]) {
      const relevant = sources.includes(metric === "shots" ? "primary-shots" : "primary-sot") || sources.includes(metric === "shots" ? "qualified-shots-outsider" : "qualified-sot-outsider");
      if (!relevant) continue;
      const lineup = lineupEligibility(player, prediction.matchId, probableLineups, officialLineups);
      const assessment = evaluateCandidate(player, metric, sources, lineup);
      if (!assessment.eligible) {
        excluded.push({ matchId: prediction.matchId, playerId: player.playerId || null, playerName: player.name || null, metric, sources, reasons: assessment.reasons });
        continue;
      }
      const quoteRow = compatibleQuote({ odds, prediction, player, metric, threshold: assessment.threshold, providerPlayerMap });
      const leg = playerForecastLeg({ prediction, player, metric, threshold: assessment.threshold, lineup, quoteRow, odds, sources, fixture });
      additions.push(leg);
      added.push(leg);
    }
    additions.sort((left, right) => (left.suggestionAnalysis.family === right.suggestionAnalysis.family ? 0 : left.suggestionAnalysis.family === "shots" ? -1 : 1)
      || Number(right.individualModelProbabilityPct) - Number(left.individualModelProbabilityPct)
      || String(left.playerName).localeCompare(String(right.playerName), "it"));
    const baseline = match.selections.filter(leg => leg.suggestionAnalysis?.suggested).sort((left, right) => Number(left.suggestionAnalysis.rank) - Number(right.suggestionAnalysis.rank));
    const selectedAdditions = additions.filter(leg => leg.suggestionAnalysis.suggested);
    const ranks = new Map([...baseline, ...selectedAdditions].map((leg, index) => [leg.selectionId, index + 1]));
    const selections = [...match.selections.map(leg => ranks.has(leg.selectionId) ? { ...leg, suggestionAnalysis: { ...leg.suggestionAnalysis, rank: ranks.get(leg.selectionId) } } : leg), ...additions.map(leg => ({ ...leg, suggestionAnalysis: { ...leg.suggestionAnalysis, rank: ranks.get(leg.selectionId) } }))];
    const suggestions = [...baseline, ...selectedAdditions].map(leg => leg.selectionId);
    const byFamily = suggestions.map(id => selections.find(leg => leg.selectionId === id)).reduce((counts, leg) => { const family = leg.suggestionAnalysis.family; counts[family] = (counts[family] || 0) + 1; return counts; }, {});
    return { ...match, selections, total: selections.length, evaluated: selections.filter(leg => finite(leg.betSelection?.evaluation?.modelProbabilityPct)).length, notModelled: selections.filter(leg => !finite(leg.betSelection?.evaluation?.modelProbabilityPct)).length, suggestions, suggestionSummary: { total: suggestions.length, byFamily } };
  });
  return {
    matches,
    summary: {
      source: "data/normalized/predictions.json#predictions[].shooters",
      readingsConsumer: "js/pages/readings.js",
      sharedStructuredData: true,
      added: added.length,
      shots: added.filter(leg => leg.suggestionAnalysis.family === "shots").length,
      sot: added.filter(leg => leg.suggestionAnalysis.family === "sot").length,
      quoted: added.filter(leg => leg.betSelection.quote.availability === "AVAILABLE_AT_SNAPSHOT").length,
      unquoted: added.filter(leg => leg.betSelection.quote.availability === "UNAVAILABLE").length,
      duoPromoted: added.filter(leg => leg.betSelection.market.bookmakerSemantics?.duo === true).length,
      excluded,
      quotedSelectionIds: added.filter(leg => leg.betSelection.quote.availability === "AVAILABLE_AT_SNAPSHOT").map(leg => leg.selectionId),
    },
  };
}

module.exports = {
  buildProviderPlayerMap,
  compatibleQuote,
  playerForecastLeg,
  chooseShotsThreshold,
  chooseSotThreshold,
  candidatePool,
  evaluateCandidate,
  isCompatibleIndividualMarket,
  isSupportedDuoMarket,
  integratePlayerForecasts,
  applyApprovedBaseline,
};
