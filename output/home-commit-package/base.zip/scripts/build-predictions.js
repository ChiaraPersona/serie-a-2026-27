"use strict";

const { readJsonFile: storageReadJson } = require('./sisal/dataset-store.cjs');
const fs = require("fs");
const path = require("path");
const { ENGINE_VERSION, PLAYER_MARKET_MODEL_VERSION, WEIGHTS, predictMatch, volumeMetric } = require("./predictions/engine");
const { currentTeamVolume, withDisciplineHistory } = require('./predictions/current-sot-volume.cjs');
const { currentGoalInputs } = require('./predictions/current-goal-inputs.cjs');
const { DECISION_LAYER_VERSION, PROFILE_LIMITS, enrichPrediction } = require("./predictions/decision-layer");
const { loadPlayerIdentities } = require("./player-identity");
const { aggregateDisciplinaryFeatures,historicalDisciplinaryFeatures } = require("./disciplinary-features");
const { buildProfiles } = require("./build-team-matchup-profiles");
const { compareCanonicalMatches } = require("./predictions/future-readiness");

const root = path.resolve(__dirname, "..");
const {buildCompetitionContext}=require('./predictions/competition-context.cjs');
const competitionHistory=require('./build-serie-a-team-history.cjs').build();
const read = relative => storageReadJson(path.join(root, relative));
const matches = read("data/normalized/matches.json");
const readings = read("data/normalized/readings.json");
const standings = read("data/normalized/standings-2025-26.json");
const styles = read("data/normalized/team-style-profiles.json");
const discipline = read("data/normalized/team-referee-profiles.json");
const historicalMatches = read("data/normalized/referee-matches/2025-26/serie-a.json").matches;
const objectives = read("data/team-objectives.json");
const teams = read("data/teams/index.json").teams;
const odds = read("data/normalized/odds/sisal/serie-a.json");
const headToHead = read("data/generated/head-to-head/first-leg-2026-27.json");
const understatXg = read("data/normalized/understat-serie-a-xg.json");
const volumeProfiles = read("data/normalized/team-volume-profiles-2025-26.json");
const teamMatchupProfiles = read("data/normalized/team-matchup-profiles-2026-27.json");
const refereeAggregates = read("data/generated/referee-stats/2025-26/aggregates.json");
const officialLineups = read("data/sources/official-lineups-2026-27.json");
const predictionArchiveFiles = fs.readdirSync(path.join(root, "data", "sources"))
  .filter(filename => /^prediction-archive-md\d{1,2}-2026-27\.json$/.test(filename))
  .sort();
const predictionArchive = {
  predictions: predictionArchiveFiles.flatMap(filename => read(`data/sources/${filename}`).predictions || [])
};
const myComboFiles = fs.readdirSync(path.join(root, "data/sources"))
  .filter(filename => /^mycombo-serie-a-2026-27-md-\d{2}\.json$/.test(filename))
  .sort();
const myComboSources = process.env.SERIE_A_DISABLE_MYCOMBO === "1"
  ? []
  : myComboFiles.map(filename => ({ filename, ...read(`data/sources/${filename}`) }));
const myComboSource = {
  constraints: myComboSources.at(-1)?.constraints || {},
  matches: Object.assign({}, ...myComboSources.map(source => source.matches || {}))
};
const selectionAssessmentFiles = fs.readdirSync(path.join(root, "data/sources"))
  .filter(filename => /^betting-selection-assessments-md\d{2}\.json$/.test(filename))
  .sort();
const selectionAssessmentsByMatch = new Map();
for (const filename of selectionAssessmentFiles) {
  for (const assessment of read(`data/sources/${filename}`).assessments || []) {
    if (!assessment.matchId || !assessment.selectionId) continue;
    const bySelection = selectionAssessmentsByMatch.get(assessment.matchId) || {};
    const previous = bySelection[assessment.selectionId];
    if (previous && JSON.stringify(previous) !== JSON.stringify(assessment)) {
      throw new Error(`${filename}: valutazione conflittuale per ${assessment.selectionId}`);
    }
    bySelection[assessment.selectionId] = assessment;
    selectionAssessmentsByMatch.set(assessment.matchId, bySelection);
  }
}
const backtestPath = path.join(root, "data/generated/prediction-backtest-2025-26.json");
const backtest = fs.existsSync(backtestPath) ? storageReadJson(backtestPath) : null;
const multiSeasonBacktestPath = path.join(root, "data/generated/prediction-backtest-multiseason.json");
const multiSeasonBacktest = fs.existsSync(multiSeasonBacktestPath) ? storageReadJson(multiSeasonBacktestPath) : null;
const openingBacktestPath = path.join(root, "data/generated/prediction-backtest-opening-rounds.json");
const openingBacktest = fs.existsSync(openingBacktestPath) ? storageReadJson(openingBacktestPath) : null;
const generatedAt = new Date().toISOString();
const previewMatchday = Number(process.env.SERIE_A_PREDICTION_PREVIEW_MATCHDAY);
const previewMode = Number.isInteger(previewMatchday) && previewMatchday > 0;
const cardResearch = process.argv.includes("--inspect-card-ranking");
if (cardResearch && !previewMode) throw new Error("La ricerca ammoniti richiede una giornata in anteprima");
const cardRankings = [];
const requestedMatchId = process.env.SERIE_A_PREDICTION_MATCH_ID || null;
if (requestedMatchId && !matches.some(match => match.id === requestedMatchId)) throw new Error(`Fixture sconosciuta: ${requestedMatchId}`);

const byId = items => new Map(items.map(item => [item.teamId || item.team || item.matchId || item.canonicalMatchId, item]));
const playerKey = value => String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
const readingByMatch = byId(readings);
const styleByTeam = byId(styles.profiles);
const disciplineByTeam = byId(discipline.profiles);
const objectiveByTeam = byId(objectives.teams);
const oddsByMatch = byId(odds.events);
const headToHeadByMatch = new Map(headToHead.fixtures.map(fixture => [fixture.fixtureId, fixture]));
const pairKey = (homeTeam, awayTeam) => [homeTeam, awayTeam].sort().join("|");
const headToHeadByPair = new Map(headToHead.fixtures.map(fixture => [pairKey(fixture.homeTeamId, fixture.awayTeamId), fixture]));
const homeByTeam = byId(standings.homeRows);
const awayByTeam = byId(standings.awayRows);
const teamById = new Map(teams.map(team => [team.id, team]));
const squadsByTeam = new Map(teams.map(team => [team.id, read(`data/generated/team-pages/${team.id}-squad.json`)]));
const roleDiscipline = new Map();
if (cardResearch) {
  const seen = new Set();
  for (const squad of squadsByTeam.values()) for (const player of squad.players) {
    const totals = player.previousSeason?.totals;
    if (!player.id || seen.has(player.id) || !Number.isFinite(totals?.yellowCards) || !(totals.foulsCommitted > 0)) continue;
    seen.add(player.id);
    const role = roleDiscipline.get(player.role) ?? { yellows: 0, fouls: 0 };
    role.yellows += totals.yellowCards;
    role.fouls += totals.foulsCommitted;
    roleDiscipline.set(player.role, role);
  }
}
const identityRegistry = loadPlayerIdentities(root);
for (const identity of identityRegistry.payload.players) {
  const squad = squadsByTeam.get(identity.teamId);
  if (!squad) continue;
  const player = squad.players.find(entry => entry.id === identity.playerId);
  if (player) player.identityAliases = identity.aliases;
  else squad.players.push({ id: identity.playerId, name: identity.canonicalName, role: null, detailedRole: null, identityAliases: identity.aliases });
}
const probableLineupSource = require("./probable-lineups").loadLatestProbableLineups(root);
for (const fixture of officialLineups.fixtures) for (const team of fixture.teams) for (const entry of [...(team.players || []),...(team.substitutes || [])]) {
  const player = squadsByTeam.get(team.teamId)?.players.find(p=>p.id===entry.playerId);
  if (player) player.identityAliases=[...new Set([...(player.identityAliases || []),entry.sourceName,entry.currentName].filter(Boolean))];
}
for (const team of probableLineupSource.teams) for (const entry of team.players) {
  if (!entry.playerId) continue;
  const player = squadsByTeam.get(team.teamId)?.players.find(player => player.id === entry.playerId);
  if (player) player.identityAliases = [...new Set([...(player.identityAliases || []), entry.sourceName, entry.currentName].filter(Boolean))];
}
const volumeByTeam = byId(volumeProfiles.profiles);
const currentVolumePriors = withDisciplineHistory(volumeProfiles.profiles, historicalMatches);
const teamMatchupSnapshots = new Map();
const teamMatchupsForTarget = match => {
  const key = `md-${match.matchday}`;
  if (!teamMatchupSnapshots.has(key)) {
    const snapshot = Number(match.matchday) <= 1
      ? { schemaVersion: 2, dataCutoff: { mode: "as-of-matchday", asOfMatchdayExclusive: match.matchday, completedMatchesUsed: 0 }, profiles: [] }
      : buildProfiles({ asOfMatchday: match.matchday });
    teamMatchupSnapshots.set(key, { snapshot, byTeam: byId(snapshot.profiles) });
  }
  return teamMatchupSnapshots.get(key);
};
const refereeRows = refereeAggregates.referees.filter(row => row.competition === "serie-a" && row.stage === "regular-season");
const refereeBySlug = new Map(refereeRows.map(row => [row.refereeSlug, row]));
const refereeLeagueAverage = {
  yellowCardsPerMatch: refereeRows.reduce((total, row) => total + row.yellowCards, 0) / refereeRows.reduce((total, row) => total + row.matches, 0),
  foulsPerMatch: refereeRows.reduce((total, row) => total + row.fouls, 0) / refereeRows.reduce((total, row) => total + row.matches, 0)
};
const standingsByTeam = new Map(standings.rows.map(row => [row.team, row]));
const meanStandingPoints = standings.rows.reduce((total, row) => total + row.points, 0) / standings.rows.length;
const understatTeamIds = {
  "AC Milan": "milan", Inter: "inter", "Parma Calcio 1913": "parma", Roma: "roma", Verona: "verona"
};
const canonicalTeamId = name => understatTeamIds[name] || String(name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const xgMatches = understatXg.matches.filter(match => match.season === "2025-26").map(match => ({
  ...match,
  homeTeamId: canonicalTeamId(match.homeTeam.name),
  awayTeamId: canonicalTeamId(match.awayTeam.name)
}));
const xgLeagueSummary = {
  homeXgPerMatch: xgMatches.reduce((total, match) => total + match.xg.home, 0) / xgMatches.length,
  awayXgPerMatch: xgMatches.reduce((total, match) => total + match.xg.away, 0) / xgMatches.length
};

function xgProfile(teamId) {
  const rows = xgMatches.filter(match => match.homeTeamId === teamId || match.awayTeamId === teamId);
  if (!rows.length) return null;
  const rate = (selected, type) => selected.reduce((total, match) => {
    const atHome = match.homeTeamId === teamId;
    return total + (type === "for" ? (atHome ? match.xg.home : match.xg.away) : (atHome ? match.xg.away : match.xg.home));
  }, 0) / selected.length;
  const home = rows.filter(match => match.homeTeamId === teamId);
  const away = rows.filter(match => match.awayTeamId === teamId);
  const recent = [...rows].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 8);
  return {
    teamId,
    season: "2025-26",
    matches: rows.length,
    home: { matches: home.length, for: rate(home, "for"), against: rate(home, "against") },
    away: { matches: away.length, for: rate(away, "for"), against: rate(away, "against") },
    overall: { for: rate(rows, "for"), against: rate(rows, "against") },
    recent: { matches: recent.length, for: rate(recent, "for"), against: rate(recent, "against") },
    source: understatXg.source
  };
}
const xgProfiles = new Map(teams.map(team => [team.id, xgProfile(team.id)]));

function recentForm(teamId, targetMatch) {
  const currentSeason = matches
    .filter(match => match.competition === "serie-a" && match.season === "2026-27" && match.status === "finished" && match.score && match.matchday < targetMatch.matchday && (match.homeTeam === teamId || match.awayTeam === teamId))
    .sort((a, b) => b.matchday - a.matchday)
    .map(match => ({
      date: match.date,
      atHome: match.homeTeam === teamId,
      opponent: match.homeTeam === teamId ? match.awayTeam : match.homeTeam,
      goalsFor: match.homeTeam === teamId ? match.score.home : match.score.away,
      goalsAgainst: match.homeTeam === teamId ? match.score.away : match.score.home,
      season: "2026-27"
    }));
  const historical = historicalMatches.filter(match => match.homeTeam.slug === teamId || match.awayTeam.slug === teamId)
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .map(match => {
      const atHome = match.homeTeam.slug === teamId;
      return {
        date: match.date,
        atHome,
        opponent: atHome ? match.awayTeam.slug : match.homeTeam.slug,
        goalsFor: atHome ? match.score.home : match.score.away,
        goalsAgainst: atHome ? match.score.away : match.score.home,
        season: "2025-26"
      };
    });
  const rows = [...currentSeason, ...historical].slice(0, 8);
  if (!rows.length) return null;
  let weightTotal = 0, goalsFor = 0, goalsAgainst = 0;
  rows.forEach((match, index) => {
    const opponentStrength = (standingsByTeam.get(match.opponent)?.points || meanStandingPoints) / meanStandingPoints;
    const weight = 0.82 ** index;
    weightTotal += weight;
    goalsFor += match.goalsFor * (opponentStrength ** 0.25) * weight;
    goalsAgainst += match.goalsAgainst / (opponentStrength ** 0.25) * weight;
  });
  return { matches: rows.length, goalsFor: goalsFor / weightTotal, goalsAgainst: goalsAgainst / weightTotal, decay: 0.82, opponentAdjusted: true, currentSeasonMatches: currentSeason.length };
}

const currentPlayerPerformanceCache = new Map();
function currentPlayerPerformance(teamId, targetMatch) {
  const cacheKey = `${teamId}:${targetMatch.matchday}`;
  if (currentPlayerPerformanceCache.has(cacheKey)) return currentPlayerPerformanceCache.get(cacheKey);
  const rows = matches.filter(match =>
    match.competition === "serie-a" &&
    match.season === "2026-27" &&
    match.status === "finished" &&
    match.matchday < targetMatch.matchday &&
    (match.homeTeam === teamId || match.awayTeam === teamId)
  ).sort(compareCanonicalMatches);
  const aggregate = {};
  for (const match of rows) {
    const side = match.homeTeam === teamId ? "home" : "away";
    for (const player of match.playerStats?.[side] || []) {
      if (!(player.minutes > 0)) continue;
      const key = player.playerId || playerKey(player.player);
      const current = aggregate[key] || { appearances: 0, minutes: 0, foulsCommitted: 0, foulsCommittedCoverage: 0, foulsWon: 0, foulsWonCoverage: 0, shots: 0, shotsCoverage: 0, shotsSequence: [], shotsOnTarget: 0, shotsOnTargetCoverage: 0, shotsOnTargetSequence: [], expectedGoals: 0, expectedGoalsCoverage: 0, starterAppearances: 0, starterMinutes: 0, minutesSequence: [], starterSequence: [], lastAppearanceMatchday: null };
      current.appearances += 1;
      current.minutes += player.minutes;
      if (player.foulsCommitted != null) { current.foulsCommitted += player.foulsCommitted; current.foulsCommittedCoverage += 1; }
      if (player.foulsWon != null) { current.foulsWon += player.foulsWon; current.foulsWonCoverage += 1; }
      if (player.shots != null) { current.shots += player.shots; current.shotsCoverage += 1; current.shotsSequence.push(player.shots); }
      if (player.shotsOnTarget != null) { current.shotsOnTarget += player.shotsOnTarget; current.shotsOnTargetCoverage += 1; current.shotsOnTargetSequence.push(player.shotsOnTarget); }
      if (player.expectedGoals != null) { current.expectedGoals += player.expectedGoals; current.expectedGoalsCoverage += 1; }
      if (player.starter) {
        current.starterAppearances += 1;
        current.starterMinutes += player.minutes;
      }
      current.lastAppearanceMatchday = match.matchday;
      aggregate[key] = current;
      aggregate[playerKey(player.player)] = current;
    }
  }
  const recentMatches = rows.slice(-5);
  const uniquePlayers = [...new Set(Object.values(aggregate))];
  for (const current of uniquePlayers) {
    const identityKeys = Object.entries(aggregate).filter(([, value]) => value === current).map(([key]) => key);
    current.minutesSequence = recentMatches.map(match => {
      const side = match.homeTeam === teamId ? "home" : "away";
      const stat = (match.playerStats?.[side] || []).find(player => identityKeys.includes(player.playerId) || identityKeys.includes(playerKey(player.player)));
      return Number(stat?.minutes || 0);
    });
    current.starterSequence = recentMatches.map(match => {
      const side = match.homeTeam === teamId ? "home" : "away";
      const stat = (match.playerStats?.[side] || []).find(player => identityKeys.includes(player.playerId) || identityKeys.includes(playerKey(player.player)));
      return Boolean(stat?.starter);
    });
    current.recentTeamMatches = recentMatches.length;
    current.recentAppearances = current.minutesSequence.filter(value => value > 0).length;
    current.recentStarts = current.starterSequence.filter(Boolean).length;
    current.recentAverageMinutes = recentMatches.length ? current.minutesSequence.reduce((total, value) => total + value, 0) / recentMatches.length : null;
    current.expectedGoalsPer90 = current.expectedGoalsCoverage && current.minutes ? current.expectedGoals * 90 / current.minutes : null;
    current.expectedGoalsPerShot = current.expectedGoalsCoverage && current.shots > 0 ? current.expectedGoals / current.shots : null;
  }
  aggregate.__meta = { teamId, asOfMatchdayExclusive: targetMatch.matchday, matchesUsed: rows.length, recentMatchIds: recentMatches.map(match => match.id) };
  for (const feature of aggregateDisciplinaryFeatures(matches,teamId,{asOfMatchdayExclusive:targetMatch.matchday,targetMatchId:targetMatch.id})) {
    const current = aggregate[feature.playerId] || aggregate[playerKey(feature.playerName)];
    if (current) current.disciplinaryFeatures = feature;
  }
  currentPlayerPerformanceCache.set(cacheKey, aggregate);
  return aggregate;
}

const nextScheduledMatchday = matches
  .filter(match => match.competition === "serie-a" && match.season === "2026-27" && match.status !== "finished")
  .reduce((minimum, match) => Math.min(minimum, match.matchday), Infinity);
const leagueTargetMatches = matches
  .filter(match => match.competition === "serie-a" && match.season === "2026-27" && (previewMode ? match.matchday === previewMatchday : oddsByMatch.has(match.id) || match.matchday === nextScheduledMatchday))
  .sort((a, b) => a.matchday - b.matchday || a.id.localeCompare(b.id));
const targetMatches = requestedMatchId ? leagueTargetMatches.filter(match => match.id === requestedMatchId) : leagueTargetMatches;
const predictionMatches = matches;

const officialReferenceByTeam = new Map(officialLineups.fixtures
  .flatMap(fixture => fixture.teams.map(lineup => [lineup.teamId, {
    formation: lineup.formation,
    players: lineup.players.map(player => player.currentName || player.sourceName),
    context: `Riferimento dalla formazione ufficiale della ${fixture.matchday}ª giornata`,
    status: "reference",
    referenceMatchId: fixture.matchId,
    updatedAt: fixture.date,
    source: { provider: officialLineups.provider || "Distinta ufficiale", scope: `Formazione ufficiale ${fixture.label}`, retrievedAt: fixture.date }
  }])));
const officialLineupByMatchTeam = new Map(officialLineups.fixtures.flatMap(fixture => fixture.teams.map(lineup => [
  `${fixture.matchId}:${lineup.teamId}`,
  {
    formation: lineup.formation,
    players: lineup.players.map(player => player.currentName || player.sourceName),
    context: `Formazione ufficiale della ${fixture.matchday}ª giornata`,
    status: "official",
    matchId: fixture.matchId,
    updatedAt: fixture.retrievedAt || fixture.date,
    source: {
      provider: fixture.provider || officialLineups.provider || "Distinta ufficiale",
      scope: `Formazione ufficiale ${fixture.label}`,
      url: fixture.sourceUrl || officialLineups.sourceUrl || null,
      retrievedAt: fixture.retrievedAt || fixture.date
    }
  }
])));
const teamForMatch = (team, match) => {
  const fixtureOfficial = officialLineupByMatchTeam.get(`${match.id}:${team?.id}`);
  if (fixtureOfficial) return { ...team, probableLineup: fixtureOfficial };
  if (team?.probableLineup?.status !== "official" || team.probableLineup.matchId === match.id) return team;
  return { ...team, probableLineup: team.projectedLineup || officialReferenceByTeam.get(team.id) || null };
};
// Official positional data are fixture inputs, never persistent roster changes.
const squadForMatch = (teamId, match) => {
  const squad = squadsByTeam.get(teamId);
  const lineup = officialLineups.fixtures.find(fixture => fixture.matchId === match.id)?.teams.find(team => team.teamId === teamId);
  if (!lineup?.players.some(player => player.role || player.detailedRole)) return squad;
  const positions = new Map(lineup.players.map(player => [player.playerId, player]));
  return { ...squad, players: squad.players.map(player => {
    const position = positions.get(player.id);
    return position ? { ...player, role: position.role || player.role, detailedRole: position.detailedRole || player.detailedRole } : player;
  }) };
};

const generatedPredictions = targetMatches.map(match => {
  const matchupSnapshot = teamMatchupsForTarget(match);
  const teamMatchupByTeam = matchupSnapshot.byTeam;
  const homeTeam = teamForMatch(teamById.get(match.homeTeam), match);
  const awayTeam = teamForMatch(teamById.get(match.awayTeam), match);
  const goalInputs = teamId => currentGoalInputs({ matches, historicalMatches, teamId, targetMatch: match, profile: styleByTeam.get(teamId), historicalXg: xgProfiles.get(teamId), xgLeagueSummary });
  const currentHome = match.status === 'scheduled' ? goalInputs(match.homeTeam) : null;
  const currentAway = match.status === 'scheduled' ? goalInputs(match.awayTeam) : null;
  const venueInput = (historical, current, venue) => current?.venueRates ? { ...historical, currentGoalRates: { for: current.venueRates[venue].for.mean, against: current.venueRates[venue].against.mean } } : historical;
  const predictionGeneratedAt = generatedAt;
  const prediction = predictMatch({
    xgotContext: require('./predictions/xgot-operational.cjs').contextFor({ homeTeamId: match.homeTeam, awayTeamId: match.awayTeam,
      date: match.date, generatedAt: predictionGeneratedAt, eligible: match.status === 'scheduled' && require('./predictions/snapshot-core.js').toKickoffUtc(match) > Date.parse(predictionGeneratedAt) }),
    competitionContext:buildCompetitionContext(competitionHistory,match),
    match,
    reading: readingByMatch.get(match.id),
    homeVenue: venueInput(homeByTeam.get(match.homeTeam), currentHome, 'home'),
    awayVenue: venueInput(awayByTeam.get(match.awayTeam), currentAway, 'away'),
    homeProfile: currentHome?.profile || styleByTeam.get(match.homeTeam),
    awayProfile: currentAway?.profile || styleByTeam.get(match.awayTeam),
    homeRecent: recentForm(match.homeTeam, match),
    awayRecent: recentForm(match.awayTeam, match),
    homeXgProfile: currentHome?.xg || xgProfiles.get(match.homeTeam),
    awayXgProfile: currentAway?.xg || xgProfiles.get(match.awayTeam),
    xgLeagueSummary,
    homeDiscipline: disciplineByTeam.get(match.homeTeam),
    awayDiscipline: disciplineByTeam.get(match.awayTeam),
    homeVolume: match.status === 'scheduled' ? currentTeamVolume({ matches, historicalProfiles: currentVolumePriors, teamId: match.homeTeam, targetMatch: match }) : volumeByTeam.get(match.homeTeam),
    awayVolume: match.status === 'scheduled' ? currentTeamVolume({ matches, historicalProfiles: currentVolumePriors, teamId: match.awayTeam, targetMatch: match }) : volumeByTeam.get(match.awayTeam),
    homeObjective: objectiveByTeam.get(match.homeTeam),
    awayObjective: objectiveByTeam.get(match.awayTeam),
    headToHead: headToHeadByMatch.get(match.id) || headToHeadByPair.get(pairKey(match.homeTeam, match.awayTeam)),
    homeTeam,
    awayTeam,
    homeSquad: squadForMatch(match.homeTeam, match),
    awaySquad: squadForMatch(match.awayTeam, match),
    homeCurrentDiscipline: currentPlayerPerformance(match.homeTeam, match),
    awayCurrentDiscipline: currentPlayerPerformance(match.awayTeam, match),
    homeCurrentPlayers: currentPlayerPerformance(match.homeTeam, match),
    awayCurrentPlayers: currentPlayerPerformance(match.awayTeam, match),
    homeTeamMatchupProfile: teamMatchupByTeam.get(match.homeTeam) || null,
    awayTeamMatchupProfile: teamMatchupByTeam.get(match.awayTeam) || null,
    refereeProfile: refereeBySlug.get(match.refereeAssignment?.referee?.slug) || null,
    refereeLeagueAverage,
    leagueSummary: standings.summary,
    oddsEvent: oddsByMatch.get(match.id),
    oddsRetrievedAt: oddsByMatch.get(match.id)?.retrievedAt || null,
    oddsSourceUrl: odds.sourceUrl,
    myComboConfig: myComboSource.matches[match.id]
      ? {
        constraints: myComboSource.constraints,
        portfolios: myComboSource.matches[match.id],
        selectionAssessments: selectionAssessmentsByMatch.get(match.id) || {},
        quoteSource: {
          provider: odds.provider,
          retrievedAt: odds.retrievedAt,
          sourceUrl: odds.sourceUrl,
          snapshotPath: "data/normalized/odds/sisal/serie-a.json",
          rawFile: odds.rawFile,
          acquisition: odds.acquisition,
        },
      }
      : null,
    generatedAt: predictionGeneratedAt
  }, cardResearch ? (candidates, selected) => {
    const lineupInfo = team => {
      const lineup = team.probableLineup;
      return { teamId: team.id, status: lineup?.status, matchId: lineup?.matchId ?? null, updatedAt: lineup?.updatedAt ?? null, size: lineup?.players?.length ?? 0 };
    };
    const compact = ({playerId, name, teamId, role, riskScore, expectedMinutes, duelResearch}) => {
      const previous = squadsByTeam.get(teamId)?.players.find(player => player.id === playerId)?.previousSeason?.totals;
      const recent = currentPlayerPerformance(teamId, match)[playerId]?.disciplinaryFeatures;
      const prior = roleDiscipline.get(role);
      let yellows = 0, fouls = 0;
      if (Number.isFinite(previous?.yellowCards) && Number.isFinite(previous?.foulsCommitted) && previous.minutes > 0) {
        yellows += previous.yellowCards;
        fouls += previous.foulsCommitted;
      }
      if (Number.isFinite(recent?.yellowPer90) && Number.isFinite(recent?.foulsCommittedPer90)) {
        yellows += recent.ordinaryYellows;
        fouls += recent.foulsCommitted;
      }
      const roleRate = prior?.yellows > 0 ? prior.yellows / prior.fouls : null;
      const relative = roleRate && fouls > 0 ? (yellows + 30 * roleRate) / (fouls + 30) / roleRate : null;
      const propensity = { yellows, fouls, roleRate, factor: relative == null ? 1 : 1 + 0.2 * Math.max(-0.5, Math.min(0.5, relative - 1)) };
      return {playerId, name, teamId, role, riskScore, expectedMinutes, duelResearch, propensity};
    };
    const cardVolume = teamId => currentTeamVolume({ matches, historicalProfiles: currentVolumePriors, teamId, targetMatch: match, metrics: ["yellowCards", "fouls"] });
    const homeCards = cardVolume(match.homeTeam), awayCards = cardVolume(match.awayTeam);
    const expectedCount = (own, opponent, venue, metric) => {
      const prior = own?.venues?.[venue]?.[metric]?.for;
      return prior ? volumeMetric(null, null, own, opponent, venue, metric, 1, prior).central : null;
    };
    cardRankings.push({
      matchId: match.id, lineups: [lineupInfo(homeTeam), lineupInfo(awayTeam)], candidates: candidates.map(compact), selected: selected.map(compact),
      cardContext: {
        home: expectedCount(homeCards, awayCards, "home", "yellowCards"), away: expectedCount(awayCards, homeCards, "away", "yellowCards"), refereeFactor: candidates[0]?.refereeFactor ?? 1,
        teamFouls: {
          [match.homeTeam]: expectedCount(homeCards, awayCards, "home", "fouls"),
          [match.awayTeam]: expectedCount(awayCards, homeCards, "away", "fouls")
        }
      }
    });
  } : undefined);
  prediction.cardDataContract = {schemaVersion:1,targetVersion:"card-targets-v1",modelState:"DATA_ONLY_LEGACY_HEURISTIC",calibratedProbability:null,teamEstimateTarget: currentHome?.diagnostics && currentAway?.diagnostics ? "CURRENT_REGULARIZED_YELLOW_CARD_COUNTS_NOT_ALL_DISCIPLINARY_EVENTS" : "HISTORICAL_YELLOW_CARD_BASELINE_FIXED_DISPERSION_NOT_ALL_DISCIPLINARY_EVENTS"};
  for (const candidate of prediction.likelyBooked || []) {
    if (match.refereeAssignment?.referee?.slug && candidate.refereeFactorSource === "NO_DESIGNATION_AVAILABLE") candidate.refereeFactorSource = "DESIGNATED_REFEREE_EVIDENCE_UNAVAILABLE";
    const player = squadsByTeam.get(candidate.teamId)?.players.find(p => p.id === candidate.playerId);
    const exposure = prediction.shooters?.allPlayers?.find(p => p.playerId === candidate.playerId && p.teamId === candidate.teamId);
    const current = currentPlayerPerformance(candidate.teamId,match)[candidate.playerId];
    candidate.cardResearchFeatures = {
      historicalDisciplinarySample: historicalDisciplinaryFeatures(player),
      currentDisciplinarySample: current?.disciplinaryFeatures ?? null,
      expectedMinutes: exposure?.expectedMinutes ?? null,
      expectedMinutesReliability: exposure?.expectedMinutesReliability ?? null,
      startingProbability: exposure?.startingProbability ?? null,
      probableXIState: (candidate.teamId === match.homeTeam ? homeTeam : awayTeam)?.probableLineup?.status ?? "unknown",
      substitutionRisk: exposure?.substitutionRisk ?? null,
      exposureSource:"Player Market V2 serialized output; reference only, not used in riskScore",
      cutoff:{asOfMatchdayExclusive:match.matchday,targetMatchIdExcluded:match.id},
      usedInLegacyRiskScore:false
    };
  }
  prediction.futureDataDiagnostics = {
    dataCutoff: { matchdayExclusive: match.matchday, targetMatchIdExcluded: match.id, completedOnly: true },
    home: {
      teamId: match.homeTeam,
      currentMatchesUsed: teamMatchupByTeam.get(match.homeTeam)?.sampleSize ?? 0,
      historicalWeight: teamMatchupByTeam.get(match.homeTeam)?.offense?.teamShotVolume?.shrinkage?.historicalWeight ?? null,
      currentWeight: teamMatchupByTeam.get(match.homeTeam)?.offense?.teamShotVolume?.shrinkage?.currentWeight ?? null,
      sampleMaturity: teamMatchupByTeam.get(match.homeTeam)?.confidence?.maturityWeight ?? null,
      teamProfileConfidence: teamMatchupByTeam.get(match.homeTeam)?.confidence?.overall || "unknown"
    },
    away: {
      teamId: match.awayTeam,
      currentMatchesUsed: teamMatchupByTeam.get(match.awayTeam)?.sampleSize ?? 0,
      historicalWeight: teamMatchupByTeam.get(match.awayTeam)?.offense?.teamShotVolume?.shrinkage?.historicalWeight ?? null,
      currentWeight: teamMatchupByTeam.get(match.awayTeam)?.offense?.teamShotVolume?.shrinkage?.currentWeight ?? null,
      sampleMaturity: teamMatchupByTeam.get(match.awayTeam)?.confidence?.maturityWeight ?? null,
      teamProfileConfidence: teamMatchupByTeam.get(match.awayTeam)?.confidence?.overall || "unknown"
    },
    profileSnapshotSchemaVersion: matchupSnapshot.snapshot.schemaVersion,
    opponentInteractionApplied: prediction.teamProjections.some(team => Math.abs(team.opponentMatchupInteraction?.shotsAdjustmentPct || 0) > 0 || Math.abs(team.opponentMatchupInteraction?.shotsOnTargetAdjustmentPct || 0) > 0)
  };
  const validation = backtest?.headToHead?.outOfSample?.selected;
  const withoutHeadToHead = backtest?.headToHead?.outOfSample?.withoutHeadToHead;
  return validation ? {
    ...prediction,
    modelValidation: {
      ...(prediction.expectedGoals.components.currentGoalBaselines ? { currentTeamAdaptation: { status: 'USER_AUTHORIZED_PROSPECTIVE_VALIDATION_PENDING', statisticallyValidated: false, note: 'Historical metrics below describe the prior core, not validation of the current-season input adaptation.', version: 1 } } : {}),
      ...(prediction.expectedGoals.components.xgot ? { xgot: { applied: prediction.expectedGoals.components.xgot.applied,
        status: prediction.expectedGoals.components.xgot.status, statisticallyValidated: false } } : {}),
      season: backtest.season,
      method: backtest.methodology.type,
      matches: validation.metrics.matches,
      oneXTwoLogLoss: validation.metrics.oneXTwoLogLoss,
      oneXTwoBrier: validation.metrics.oneXTwoBrier,
      oneXTwoAccuracyPct: validation.metrics.oneXTwoAccuracyPct,
      exactTopThreeHitPct: validation.metrics.exactTopThreeHitPct,
      improvementVsWithoutHeadToHeadPct: validation.improvementVsWithoutHeadToHeadPct,
      withoutHeadToHead,
      headToHeadConfiguration: validation.configuration,
      scope: `${backtest.methodology.modelScope} Il correttivo H2H e ricostruito senza usare incontri successivi alla gara stimata.`,
      multiSeason: multiSeasonBacktest ? {
        method: multiSeasonBacktest.methodology.type,
        matches: multiSeasonBacktest.archive.outOfSamplePredictions,
        testSeasons: multiSeasonBacktest.methodology.testSeasons,
        selectedScoreModel: "poisson",
        poisson: multiSeasonBacktest.variants.poisson.aggregate,
        empirical: multiSeasonBacktest.variants.empirical.aggregate,
        xgBlend25: multiSeasonBacktest.variants["xg-blend-25"].aggregate,
        dixonColesRecommendation: multiSeasonBacktest.decision.recommendation,
        calibrationRecommendation: multiSeasonBacktest.decision.calibrationRecommendation
      } : null,
      openingRounds: openingBacktest ? {
        method: openingBacktest.methodology.type,
        validationMatches: openingBacktest.samples.validation,
        firstRoundMatches: openingBacktest.samples.firstRoundValidation,
        configuration: openingBacktest.regularized.configuration,
        validation: openingBacktest.regularized.validation,
        firstRound: openingBacktest.regularized.firstRound,
        improvementVsCurrentPct: openingBacktest.regularizedImprovementVsCurrentPct,
        recommendation: openingBacktest.recommendation
      } : null
    }
  } : prediction;
});

const withoutMvpCandidate = prediction => {
  const { mvpCandidate, ...rest } = prediction;
  return rest;
};
const archivedPredictions = predictionArchive.predictions.map(withoutMvpCandidate);
const archivedPredictionByMatch = new Map(archivedPredictions.map(prediction => [prediction.matchId, prediction]));
const generatedCurrent = generatedPredictions.filter(prediction => !archivedPredictionByMatch.has(prediction.matchId));
const basePredictions = previewMode
  ? generatedPredictions
  : [...archivedPredictions, ...generatedCurrent].sort((left, right) => {
      const leftMatch = predictionMatches.find(match => match.id === left.matchId);
      const rightMatch = predictionMatches.find(match => match.id === right.matchId);
      return (leftMatch?.matchday || 99) - (rightMatch?.matchday || 99) || left.matchId.localeCompare(right.matchId);
    });
const predictions = basePredictions.map(enrichPrediction);
const capSaturation = generatedPredictions.flatMap(prediction => prediction.teamProjections || []).reduce((summary, projection) => {
  summary.teamProjections += 1;
  for (const metric of ["shots", "shotsOnTarget", "corners"]) {
    if (projection.ownOffensiveInteraction?.capDiagnostics?.[metric]?.capHit) summary.hits[metric] += 1;
  }
  return summary;
}, { teamProjections: 0, hits: { shots: 0, shotsOnTarget: 0, corners: 0 } });
capSaturation.frequencyPct = Object.fromEntries(Object.entries(capSaturation.hits).map(([metric, hits]) => [metric, capSaturation.teamProjections ? Math.round(hits / capSaturation.teamProjections * 1000) / 10 : 0]));

const output = {
  schemaVersion: 1,
  competition: "serie-a",
  competitions: ["serie-a"],
  season: "2026-27",
  ...(previewMode ? { mode: "exploratory-preview", matchday: previewMatchday, publicationStatus: "not-published" } : {}),
  generatedAt,
  diagnostics: {
    capSaturation: {
      scope: "current-generated-team-projections",
      ...capSaturation
    }
  },
  engine: {
    version: ENGINE_VERSION,
    xgot: read('data/sources/xgot-operational-policy.json'),
    playerMarketModelVersion: PLAYER_MARKET_MODEL_VERSION,
    teamMatchupProfileVersion: teamMatchupProfiles.schemaVersion,
    principle: "Un'unica matrice dei punteggi indipendente dalle quote genera 1X2, gol e mercati collegati.",
    weights: WEIGHTS,
    surpriseFactor: "Apertura della gara, probabilita dell'esito sfavorito, divergenza mercato-dati e incompletezza prepartita. Non determina da solo il verdetto.",
    spatialModel: "Valuta separatamente sviluppo a sinistra, al centro e a destra e lo incrocia con le vulnerabilita avversarie.",
    playerMarketModel: {
      version: PLAYER_MARKET_MODEL_VERSION,
      formula: "baseline individuale regolarizzata per ruolo x fattore matchup [0,82; 1,18] x minuti attesi/90 x scaling squadra riconciliato",
      probabilities: "Poisson sulle proiezioni individuali V2; SOT deriva dallo storico SOT/90 e viene vincolato ai tiri dello stesso giocatore.",
      expectedMinutes: "Media da titolare storica depurata con 22 minuti per presenza dalla panchina, prior di ruolo e massimo peso storico 76%; forma 2026/27 massimo 50%.",
      cardRisk: "Disciplina storica e corrente, ruolo, carico canale, duello diretto quando identificabile e fattore arbitro regredito sulla media di lega.",
      compatibility: "I campi projectedShotsV1 e projectedShotsOnTargetV1 conservano la stima precedente per confronto."
    },
    goalModel: "Forze relative casa/trasferta e complessive, ultime otto gare corrette per avversario, xG Understat al 25% quando sono coperti entrambi i club, probabile XI, divisione di provenienza, matrice Poisson e correttivo H2H limitato al 5% per lato.",
    scoreSelectionModel: "Il risultato esatto centrale arrotonda separatamente i gol attesi delle due squadre; la moda assoluta e gli altri punteggi probabili restano alternative distinte.",
    decisionLayer: {
      version: DECISION_LAYER_VERSION,
      order: "probabilita -> scenari -> correlazioni -> rischio portafoglio -> selezione -> verifica post-partita",
      probabilityPolicy: "Gli scenari e il rischio non ricalibrano le probabilita e non entrano nei gol attesi.",
      correlationMethod: "Dipendenza binaria fra mercati calcolata sulla matrice dei punteggi.",
      profileLimits: PROFILE_LIMITS,
      performanceDashboard: "data/generated/prediction-performance-dashboard.json"
    },
    scoreModel: {
      type: "poisson",
      calibration: "none",
      reason: "La correzione empirica per singolo punteggio e stata rimossa: nel walk-forward su quattro stagioni peggiora lo score log-loss rispetto a Poisson.",
      validationReport: "data/generated/prediction-backtest-multiseason.json"
    },
    xgModel: {
      provider: understatXg.provider,
      season: "2025-26",
      weightWhenAvailable: 0.25,
      coveredTeams: [...xgProfiles.values()].filter(Boolean).length,
      totalTeams: teams.length,
      fallback: "Poisson sui gol quando una delle due squadre non ha storico xG di Serie A.",
      validationReport: "data/generated/prediction-backtest-multiseason.json"
    },
    promotedTeamModel: {
      attackFactor: 0.51,
      defenceWeaknessFactor: 1.29,
      method: "Carry-over regolarizzato Serie B-Serie A, selezionato su dieci stagioni e validato sulle tre successive.",
      validationReport: "data/generated/prediction-backtest-opening-rounds.json"
    },
    validation: backtest ? {
      season: backtest.season,
      method: backtest.methodology.type,
      outOfSampleMatches: backtest.outOfSample.configuredV4Core.metrics.matches,
      configuredCore: backtest.outOfSample.configuredV4Core,
      baseline: backtest.outOfSample.baseline,
      headToHeadStatus: backtest.headToHead.status,
      headToHead: backtest.headToHead.outOfSample.selected,
      scope: backtest.methodology.modelScope,
      multiSeason: multiSeasonBacktest ? {
        method: multiSeasonBacktest.methodology.type,
        testSeasons: multiSeasonBacktest.methodology.testSeasons,
        outOfSampleMatches: multiSeasonBacktest.archive.outOfSamplePredictions,
        poisson: multiSeasonBacktest.variants.poisson.aggregate,
        empirical: multiSeasonBacktest.variants.empirical.aggregate,
        dixonColes: multiSeasonBacktest.variants["dixon-coles"].aggregate,
        xgBlend25: multiSeasonBacktest.variants["xg-blend-25"].aggregate,
        decision: multiSeasonBacktest.decision
      } : null,
      openingRounds: openingBacktest,
      uncertainty: multiSeasonBacktest ? {
        variants: Object.keys(multiSeasonBacktest.decision.uncertaintyComparison || {}),
        recommendation: multiSeasonBacktest.decision.uncertaintyRecommendation,
        decision: "La miscela di lambda non viene adottata se non migliora simultaneamente log-loss 1X2 e score log-loss con bootstrap favorevole."
      } : null
    } : null,
    volumeModel: {
      provider: volumeProfiles.source.provider,
      season: volumeProfiles.season,
      coverage: volumeProfiles.coverage,
      teamWeight: 0.45,
      opponentAllowedWeight: 0.35,
      recentWeight: 0.2,
      recentMatches: 8,
      recentDecay: 0.82,
      venueSplit: true,
      interval: "p20-p80 storico; per il totale varianze squadra trattate come indipendenti",
      fallback: "Profilo WhoScored, precisione della probabile formazione e stile offensivo quando manca lo storico Serie A della squadra.",
      currentSotBaseline: { version: 1, scope: 'Serie A scheduled fixtures with prior completed current-season observations', historicalPriorEquivalentMatches: 12, missingComparableHistoryPriorEquivalentMatches: 4, recentSeason: 'current', ownResidualBoost: false, opponentResidualBoost: false, validationStatus: 'user-authorized-adaptation-preliminary-baseline-replay', report: 'docs/reports/team-sot-baseline-audit-2026-11-06.md', prospectiveCalibration: false },
      currentTeamBaseline: { version: 1, metrics: ['totalShots', 'shotsOnTarget', 'wonCorners', 'fouls', 'yellowCards', 'goals', 'expectedGoals'], historicalPriorEquivalentMatches: 12, missingComparableHistoryPriorEquivalentMatches: 4, recentSeason: 'current', residualVolumeBoosts: false, exactScores: 'same-Poisson-matrix-as-expected-goals-and-1X2', validationStatus: 'user-authorized-adaptation-prospective-validation-pending' }
    },
    playerVolumeModel: "Tiri e tiri in porta dei titolari: frequenze per 90 minuti 2025/26 regolarizzate verso una prior di ruolo, poi scalate sul volume previsto della squadra; i falli/90 restano visibili come base disciplinare e i dati mancanti usano una baseline dichiarata.",
    limitations: [`Quote Sisal datate per singolo evento; ultimo aggiornamento disponibile ${String(odds.retrievedAt).slice(0, 10)}. Le gare senza snapshot vengono pronosticate senza confronto mercato.`, "La forma recente della seconda giornata include il risultato concluso della prima e completa il campione con le gare 2025/26, sempre con taglio temporale per giornata.", "Gli xG Understat 2025/26 coprono 17 squadre su 20; negli incontri con una neopromossa non coperta resta attivo il fallback sui gol.", "Le indisponibilita derivano dal monitor editoriale aggiornato e i casi da valutare non sono trasformati in assenze certe; arbitri e meteo saranno integrati soltanto quando verificati.", "Per la seconda giornata le formazioni ufficiali della prima sono usate soltanto come riferimento tecnico, non come distinte confermate.", "Il backtest pluristagionale non include probabili XI, indisponibili e tattica per assenza di snapshot storici.", "Il correttivo H2H e limitato al 5% per lato: il vantaggio fuori campione e positivo ma modesto, quindi non deve dominare il pronostico."]
  },
  sources: [
    { label: "Lega Serie A - programma prime cinque giornate", url: "https://www.legaseriea.it/serie-a/news/date-orari-e-programmazione-tv-delle-prime-cinque-giornate" },
    { label: "Sisal - quote Serie A", url: odds.sourceUrl },
    ...myComboSources.map(source => ({ label: `MyCombo editoriali - ${source.filename} · selezioni Sisal ${source.updatedAt}`, url: `data/sources/${source.filename}` })),
    { label: `${teams.find(team => team.probableLineup?.source)?.probableLineup.source.provider || "Fonte editoriale"} - probabili formazioni 20 squadre`, url: teams.find(team => team.probableLineup?.source?.url)?.probableLineup.source.url },
    { label: "ESPN - ultimi cinque scontri diretti", url: "data/generated/head-to-head/first-leg-2026-27.json" },
    { label: `${volumeProfiles.source.provider} - tiri, tiri in porta e corner ${volumeProfiles.season}`, url: "data/normalized/team-volume-profiles-2025-26.json" }
  ],
  predictions
};

const outputPath = process.env.SERIE_A_PREDICTION_OUTPUT ? path.resolve(root, process.env.SERIE_A_PREDICTION_OUTPUT) : previewMode
  ? path.join(root, "data/generated", `prediction-preview-md${String(previewMatchday).padStart(2, "0")}-2026-27.json`)
  : path.join(root, "data/normalized/predictions.json");
if (cardResearch) {
  console.log(JSON.stringify({ generatedAt, engineVersion: ENGINE_VERSION, fixtures: cardRankings }));
} else {
  fs.writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`);
  console.log(`OK pronostici preliminari: ${predictions.length} · motore ${ENGINE_VERSION} · ${path.relative(root, outputPath)}`);
}
