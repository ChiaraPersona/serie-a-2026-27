const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert/strict');
const {chromium}=require('C:/Users/utente/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root=path.resolve(__dirname,'..'),id='udinese-milan-2026-27-md-08',dir='output/udinese-milan-md08-official',types={'.html':'text/html','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.css':'text/css','.svg':'image/svg+xml','.webp':'image/webp'};
const expected=JSON.parse(fs.readFileSync(dir+'/tests.json')).shared;
const server=http.createServer((req,res)=>{const f=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));if(!f.startsWith(root+path.sep))return res.writeHead(403).end();fs.readFile(f,(e,b)=>{res.writeHead(e?404:200,{'Content-Type':types[path.extname(f)]||'application/octet-stream'});res.end(e?'Missing':b)})});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({channel:'msedge',headless:true}),errors=[],results=[];try{for(const width of [1440,390]){
 const page=await browser.newPage({viewport:{width,height:1000}});page.on('pageerror',e=>errors.push(e.message));await page.route('https://fonts.googleapis.com/**',r=>r.abort());await page.route('https://fonts.gstatic.com/**',r=>r.abort());
 const origin='http://127.0.0.1:'+server.address().port;
 await page.goto(origin+'/lettura.html?match='+id);await page.waitForSelector('.rd-shell');
 const state=await page.evaluate(()=>({text:document.querySelector('.rd-shell').innerText,official:[...document.querySelectorAll('.rd-lineup-head')].map(n=>n.innerText),forecasts:document.querySelectorAll('[data-forecast-id]').length,overflow:document.documentElement.scrollWidth>innerWidth}));
 assert(!state.overflow);assert(state.text.includes('Davis'));assert(state.text.includes('Maignan'));assert(!state.text.includes('Probabili scelte, da riconfermare'));assert.equal(state.forecasts,expected);
 await page.locator('[data-player-lineup-filter="bench"]').click();await page.locator('[data-player-lineup-filter="starter"]').click();
 await page.screenshot({path:dir+'/lettura-'+width+'.png',fullPage:true});
 await page.goto(origin+'/schedina.html?giornata=8');await page.waitForSelector('[data-match-panel]');const panel=page.locator('[data-match-id="'+id+'"]');await page.locator('[data-match-open-all]').click();assert.equal(await panel.locator('[data-selection-row]').count(),expected);assert(!await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth));
 const pick=panel.locator('[data-personal-pick]').first();await pick.click();assert.equal(await pick.getAttribute('aria-pressed'),'true');const selectionId=await pick.getAttribute('data-personal-pick');await page.reload();await page.waitForSelector('[data-match-panel]');await page.locator('[data-match-open-all]').click();assert.equal(await page.locator('[data-personal-pick="'+selectionId+'"]').first().getAttribute('aria-pressed'),'true');
 await page.screenshot({path:dir+'/schedina-'+width+'.png',fullPage:true});results.push({width,officialLineups:true,shared:expected,savedSelectionRestored:true,overflow:false});await page.close();
 }assert.deepEqual(errors,[]);fs.writeFileSync(dir+'/browser.json',JSON.stringify({results,errors},null,2));console.log(results)}finally{await browser.close();server.close()}})().catch(e=>{console.error(e);server.close();process.exitCode=1});

